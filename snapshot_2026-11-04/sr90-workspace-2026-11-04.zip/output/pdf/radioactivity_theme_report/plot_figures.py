from pathlib import Path
import json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
P=Path(__file__).resolve().parent
t=pd.read_csv(P/'data/pooled_measurements.csv'); s=json.loads((P/'data/analysis_summary.json').read_text())
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':8,'axes.labelsize':8,'xtick.labelsize':7.5,'ytick.labelsize':7.5,'legend.fontsize':7,'pdf.fonttype':42,'axes.spines.top':False,'axes.spines.right':False,'axes.linewidth':.7})
blue='#12618a'; orange='#b34724'; gray='#606b76'; green='#328267'
d=t.d_m.to_numpy(); c=t.raw_rate_cps.to_numpy(); cc=t.corrected_rate_cps.to_numpy(); se=t.corrected_rate_se.to_numpy(); sd=.0005/np.sqrt(3)
fig,ax=plt.subplots(figsize=(3.45,2.45),layout='constrained')
rawse=np.sqrt((d*d*np.sqrt(t.total_counts.to_numpy())/t.total_time_s.to_numpy())**2+(2*d*c*sd)**2)
r=d+.021; corse=np.sqrt((r*r*se)**2+(2*r*cc*sd)**2)
ax.errorbar(d*100,t.u_recorded,yerr=rawse,fmt='o',ms=2.8, lw=.7,elinewidth=.6,color=gray,label=r'Recorded: $C_{\rm obs}d^2$')
ax.errorbar(d*100,t.u_offset21,yerr=corse,fmt='s',ms=2.7,lw=.7,elinewidth=.6,color=blue,label=r'Corrected: $C(d+21\,\mathrm{mm})^2$')
ax.set_xscale('log');ax.set_xticks([1,2.5,10,30,85],labels=['1','2.5','10','30','85']);ax.set(xlabel='Recorded separation $d$ (cm)',ylabel=r'Rate $\times$ distance$^2$ (m$^2$ s$^{-1}$)',ylim=(0,27));ax.grid(alpha=.18);ax.legend(frameon=False,loc='upper right',handlelength=1.1)
for ext in ('pdf','png'):fig.savefig(P/'images'/f'theme_distance.{ext}',dpi=300)
plt.close(fig)
fig,ax=plt.subplots(figsize=(3.45,2.55),layout='constrained')
for key,col,marker,shift in [('G0',gray,'o',-.15),('G1',green,'^',0),('G2',orange,'s',.15)]:
 rows=s['models'][key]['near']; x=np.array([q['d_cm'] for q in rows]); y=np.array([q['ratio'] for q in rows]); err=np.array([q['se'] for q in rows]); ax.errorbar(x+shift,y,yerr=err,fmt=marker,color=col,ms=3.5,capsize=1.7,elinewidth=.8,label=key,zorder=3)
ax.axhline(1,color='#252a2d',lw=.9,ls='--');ax.text(10.3,1.015,'agreement',ha='right',fontsize=7,color='#252a2d')
ax.set(xlim=(0,11),ylim=(.53,1.10),xlabel='Recorded separation $d$ (cm)',ylabel='Measured rate / Geant4 prediction');ax.set_xticks([1,2.5,5,7.5,10],labels=['1','2.5','5','7.5','10']);ax.grid(alpha=.18);ax.legend(frameon=False,ncol=3,loc='lower right',handletextpad=.4,columnspacing=1)
for ext in ('pdf','png'):fig.savefig(P/'images'/f'theme_comparison.{ext}',dpi=300)
plt.close(fig)
