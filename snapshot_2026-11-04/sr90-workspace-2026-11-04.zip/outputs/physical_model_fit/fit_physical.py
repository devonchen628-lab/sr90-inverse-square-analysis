from pathlib import Path
import numpy as np,pandas as pd,matplotlib.pyplot as plt,json
from scipy.special import roots_legendre
from scipy.optimize import least_squares
from scipy.integrate import cumulative_trapezoid
P=Path(__file__).resolve().parent;ROOT=P.parent;D=pd.read_csv(ROOT/'progressive_corrections/progressive_correction_values.csv');cov=np.load(ROOT/'progressive_corrections/air_corrected_covariance.npz');d=D.d_cm.to_numpy()/100;N=D.counts.to_numpy();t=D.time_s.to_numpy();L=.01;rs=.005;delta=.015;tau=2e-6
z,w=roots_legendre(24);w=w/2;phi=2*np.pi*(np.arange(48)+.5)/48;x=rs*np.sqrt((z+1)/2)[:,None]*np.cos(phi);y=rs*np.sqrt((z+1)/2)[:,None]*np.sin(phi);x1=-L/2-x;x2=L/2-x;y1=-L/2-y;y2=L/2-y
def omega(r):
 def f(a,b,v):return np.arctan2(a*b,v*np.sqrt(v*v+a*a+b*b))
 return np.array([np.sum(w[:,None]*(f(x2,y2,v)-f(x1,y2,v)-f(x2,y1,v)+f(x1,y1,v)))/48 for v in np.atleast_1d(r)])
# Sammy-style allowed beta spectra and approximate range-energy relation; no Fermi correction.
def spectrum(endpoint):
 E=np.linspace(0,endpoint,10000);m=.511;mom=np.sqrt(E*(E+2*m));s=mom*(E+m)*(endpoint-E)**2;cum=cumulative_trapezoid(s,E,initial=0);return E,cum/cum[-1]
elo,flo=spectrum(.54);ehi,fhi=spectrum(2.27)
def component(r_m):
 areal=.001204*(r_m*100);cut=np.sqrt(np.maximum(0,((1+areal/.11)**2-1)/22.4));return (1-np.interp(cut,elo,flo)),(1-np.interp(cut,ehi,fhi))
def forward(ds,K,mix):
 lo,hi=component(ds+delta);trans=mix*lo+(1-mix)*hi;true=K*omega(ds+delta)/L**2*trans;obs=true/(1+tau*true);return obs,trans
# Poisson deviance objective fits actual counts in their measurement times.
def resid(beta):
 pred,_=forward(d,*beta);mu=np.maximum(pred*t,1e-100);dev=2*(mu-N+N*np.log(N/mu));return np.sign(N-mu)*np.sqrt(np.maximum(dev,0))
opt=least_squares(resid,[16,.17],bounds=([.01,0],[100,1]),xtol=1e-11,ftol=1e-11,gtol=1e-11);K,mix=opt.x
# The MC-air corrected points share covariance; use GLS for a constant.
mask=np.isfinite(D.air_corrected);y=D.loc[mask,'air_corrected'].to_numpy();C=cov['total_conditional'];one=np.ones(len(y));onesolve=np.linalg.solve(C,one);constant=(onesolve@y)/(onesolve@one);sigma=np.sqrt(1/(onesolve@one));chisq=(y-constant)@np.linalg.solve(C,y-constant)
xx=np.linspace(d.min(),d.max(),800);rpred,T=forward(xx,K,mix);rsep=xx+delta;blue=rpred*xx**2;orange=rpred*rsep**2;true=rpred/(1-tau*rpred);green=true*L**2/omega(rsep)
fig,ax=plt.subplots(figsize=(9.3,5.8),layout='constrained');plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42})
sets=[('1. Raw data','raw_Rd2','raw_se','#557b96','o'),('2. Distance corrected','distance_corrected','distance_corrected_se','#d58a23','s'),('3. Geometry + dead time','geometry_deadtime_corrected','geometry_deadtime_se','#16846e','^'),('4. + relative Geant4 air correction','air_corrected','air_corrected_se','#b44c70','D')]
for label,yc,ec,col,mark in sets:
 v=D[yc].to_numpy();e=D[ec].to_numpy();sel=np.isfinite(v);ax.errorbar(D.d_cm[sel],v[sel],yerr=e[sel],fmt=mark,ms=3.5,capsize=1.5,elinewidth=.7,color=col,alpha=.46,label='_nolegend_')
for vals,col,label in [(blue,'#557b96','Raw: physical forward fit'),(orange,'#d58a23','Distance corrected: transformed fit'),(green,'#16846e','Geometry + dead time: transformed fit')]:ax.plot(xx*100,vals,color=col,lw=2,label=label)
ax.plot([30,85],[constant,constant],color='#b44c70',lw=2,label='Air corrected: GLS constant (30–85 cm)')
ax.set(xlabel='Rail distance $d$ (cm)',ylabel=r'Rate × distance² (m$^2$ s$^{-1}$)',title='Physical-model fit and stepwise data corrections',xlim=(0,88),ylim=(0,None));ax.grid(alpha=.15);ax.legend(frameon=False,fontsize=8.2,loc='lower right')
fig.savefig(P/'physical_model_fit.png',dpi=300,bbox_inches='tight');fig.savefig(P/'physical_model_fit.pdf',bbox_inches='tight')
# Diagnostics are conditional; distance uncertainty, geometry and beta-model uncertainties omitted in Poisson fit.
info={'model':'Sampler-style approximate allowed beta spectra, range-energy air transmission, source radius5mm square-detector integration, fixed offset15mm, nonparalyzable fixed deadtime2us','K_fit':K,'low_energy_effective_weight':mix,'fit_likelihood':'Poisson deviance on 32 observed counts, total times; distance/offset systematic excluded','deviance':float(sum(resid(opt.x)**2)),'nominal_dof':len(d)-2,'gls_air_corrected_mean':float(constant),'conditional_mean_se':float(sigma),'gls_chi2_conditional':float(chisq),'n_air_points':len(y),'warning':'The first three curves transform the same single raw-data fit; the fourth is a separate GLS constant fit to air-corrected data. Analytical air model for first curves and Geant4 correction for fourth are distinct. Error correlations from common offset, source size, tau and model assumptions are not included; fitted parameters and f_low are not independently calibrated.'}
(P/'fit_summary.json').write_text(json.dumps(info,indent=2));print(json.dumps(info,indent=2))
