from pathlib import Path
import json,numpy as np,pandas as pd,matplotlib.pyplot as plt
from scipy.special import roots_legendre
O=Path(__file__).resolve().parent;ROOT=O.parent;res=ROOT/'sr90_research/results';far=ROOT/'far_field_15mm_aligned'
raw=pd.read_csv(res/'raw_observations.csv');df=pd.read_csv(res/'last_three.csv');near=df[(df.d_m>=.01-1e-9)&(df.d_m<=.2+1e-9)].copy().reset_index(drop=True)
ref=raw[(raw.d_m>=.2-1e-9)&(raw.d_m<=.3+1e-9)].copy();d=near.d_m.to_numpy();n=near.counts.to_numpy();rate=near.rate_cps.to_numpy();L=.01;rs=.005;delta=.015;sd=.0005
z,w=roots_legendre(24);phi=2*np.pi*(np.arange(48)+.5)/48;x=rs*np.sqrt((z+1)/2)[:,None]*np.cos(phi);y=rs*np.sqrt((z+1)/2)[:,None]*np.sin(phi);w=w/2
x1=-L/2-x;x2=L/2-x;y1=-L/2-y;y2=L/2-y
def h(ds,dl):
 def f(a,b,r):return np.arctan2(a*b,r*np.sqrt(r*r+a*a+b*b))
 return np.array([np.sum(w[:,None]*(f(x2,y2,r)-f(x1,y2,r)-f(x2,y1,r)+f(x1,y1,r)))/48/L**2 for r in np.atleast_1d(ds)+dl])
def fit(dl):return ref.counts.sum()/np.sum(ref.time_s.to_numpy()*h(ref.d_m.to_numpy(),dl))
def hd(ds,dl):return (h(ds+1e-6,dl)-h(ds-1e-6,dl))/2e-6
K=fit(delta);model=K*h(d,delta)*d*d;rat=near.raw_u.to_numpy()/model;rn=rat-1;Nref=ref.counts.sum();inref=((d>=.2-1e-9)&(d<=.3+1e-9)).astype(float)
# Poisson covariance of log(rate_i / K); reference N includes the 20-cm selected counts.
cnt=np.diag(1/n)+(1-inref[:,None]-inref[None,:])/Nref
Cn=np.outer(rat,rat)*cnt
# sigma_d is shared by observations at the same rail position; include its effect
# on both the fitted K and the data/model ratio at a common measured d.
unique=np.unique(np.r_[d,ref.d_m.to_numpy()]);D=np.sum(ref.time_s*h(ref.d_m,delta));J=np.zeros((len(d),len(unique)))
for j,dj in enumerate(unique):
 total_time=ref.loc[np.isclose(ref.d_m,dj,atol=1e-10),'time_s'].sum();hk=hd(np.array([dj]),delta)[0];shared=total_time*hk/D
 J[:,j]=rat*(shared-np.isclose(d,dj,atol=1e-10)*hk/h(np.array([dj]),delta)[0])
Cn+=sd**2*(J@J.T);sn=np.sqrt(np.diag(Cn))
# Illustrative geometry scenarios; recalibrate K in same 20–30 cm region.
scenarios={}
for off in [.014,.016]:
 kk=fit(off);scenarios[off]=near.raw_u.to_numpy()/(kk*h(d,off)*d*d)-1
nearout=pd.DataFrame({'d_cm':d*100,'data_Cd2':near.raw_u,'data_Cd2_Book2_unc':near.book2_u_se,'G2_Cd2':model,'residual_pct':rn*100,'conditional_residual_unc_pct':sn*100,'z_conditional':rn/sn,'residual_pct_offset14mm':scenarios[.014]*100,'residual_pct_offset16mm':scenarios[.016]*100})
nearout.to_csv(O/'near_residuals.csv',index=False)
# Air ratios and experimental ratios use the same 30 cm reference within each set.
ex=pd.read_csv(far/'experimental_relative.csv');sim=pd.read_csv(far/'simulation_relative.csv');assert np.allclose(ex.d_cm,sim.d_cm)
co=np.load(far/'normalized_covariances.npz');Ce=co['experimental'];Cs=co['air_mc'];X=ex.relative_u.to_numpy();Y=sim.air_relative.to_numpy();rf=X/Y-1
# Differential covariance, assumes independently generated experiment and Monte Carlo.
Cf=Ce/np.outer(Y,Y)+Cs*np.outer(X/Y**2,X/Y**2);sf=np.sqrt(np.maximum(0,np.diag(Cf)))
fout=pd.DataFrame({'d_cm':ex.d_cm,'exp_ratio':X,'air_ratio':Y,'residual_pct':100*rf,'conditional_residual_unc_pct':100*sf,'z_conditional':np.divide(rf,sf,out=np.full_like(rf,np.nan),where=sf>0)})
fout.to_csv(O/'far_residuals.csv',index=False);np.savez_compressed(O/'residual_covariances.npz',near=Cn,far=Cf,near_d_cm=d*100,far_d_cm=ex.d_cm)
# Compare offsets as single common scenarios, not independently chosen per point.
cs=np.vstack([scenarios[.014],scenarios[.016]])
v=rf[1:]
info={'nominal_offset_mm':15,'source_radius_mm_assumed':5,'normalization_reference_cm':[20,30],'K':K,'near_points':len(rn),'far_points_excluding_reference':len(v), 'near_covariance':'Poisson counts, K shared estimated from all 20–30cm observations including correlation with 20cm selected triplet, plus 0.5mm per-distinct-distance uncertainty including d in model and K; conditions on fixed offset and radius', 'far_covariance':'experimental Book2 numerator and shared denominator; Geant4 air covariance from whole-batch bootstrap; fixed model geometry and experiment-simulation independence; distance perturbation of the simulated model is not propagated', 'warning':'Pointwise errors conditional on Poisson/count model, 0.5mm distance standard error, fixed geometry and simulation; repeatability, offset, source radius and other model systematics not quantified. No global significance asserted: 8 air MC batches cannot robustly estimate a 19-dimensional MC covariance.'}
(O/'summary.json').write_text(json.dumps(info,indent=2))
plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42})
fig,(ax,bx)=plt.subplots(1,2,figsize=(10.5,4),layout='constrained')
ax.errorbar(d*100,rn*100,yerr=sn*100,fmt='o',capsize=2.5,ms=4.5,color='#225779',label='Data vs G2; conditional error')
ax.axhline(0,color='#555555',lw=1);ax.set(xlabel='Rail distance $d$ (cm)',ylabel='(Data − model) / model (%)',title='Near field: nominal geometry',xlim=(0,21))
bx.errorbar(ex.d_cm.iloc[1:],rf[1:]*100,yerr=sf[1:]*100,fmt='o',capsize=2.5,ms=4.5,color='#c25b33',label='Data vs air; conditional error')
bx.axhline(0,color='#555555',lw=1);bx.set(xlabel='Rail distance $d$ (cm)',title='Far field: normalized to 30 cm',xlim=(30,87));
for a in [ax,bx]:a.grid(alpha=.18)
fig.savefig(O/'near_far_residuals.png',dpi=280,bbox_inches='tight');fig.savefig(O/'near_far_residuals.pdf',bbox_inches='tight')
print(json.dumps(info,indent=2));print('\nNear');print(nearout[['d_cm','residual_pct','conditional_residual_unc_pct','z_conditional','residual_pct_offset14mm','residual_pct_offset16mm']].to_string(index=False));print('\nFar');print(fout[['d_cm','residual_pct','conditional_residual_unc_pct','z_conditional']].to_string(index=False))
