from pathlib import Path
import json,numpy as np,pandas as pd,matplotlib.pyplot as plt
P=Path(__file__).resolve().parent;root=P.parent;df=pd.read_csv(root/'radioactivity_evidence_chain/pointwise_analysis.csv');C=np.load(root/'radioactivity_evidence_chain/corrected_covariance.npz')['conditional'];s=json.loads((P/'summary.json').read_text());k=s['fit_A']['K'];mu=s['fit_A']['mu_per_m'];delta=.015;mean=s['fit_B']['mean_conditional'];sig=s['fit_B']['mean_unc_conditional'];d=np.linspace(.005,.85,1000);fit=k*(d/(d+delta))**2*np.exp(-mu*(d+delta))
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42});fig,ax=plt.subplots(figsize=(8.5,5.3),layout='constrained')
ax.errorbar(df.d_cm,df.raw_Rd2,yerr=df.raw_unc,fmt='o',ms=3.6,capsize=1.5,elinewidth=.6,color='#8c969d',label='Raw $Rd^2$')
ax.errorbar(df.d_cm,df.geometry_corrected,yerr=df.geometry_unc,fmt='s',ms=3.4,capsize=1.5,elinewidth=.6,color='#d28323',label='Geometry corrected')
ax.errorbar(df.d_cm,df.fully_corrected,yerr=np.sqrt(np.diag(C)),fmt='^',ms=3.5,capsize=1.5,elinewidth=.65,color='#008574',label='Geometry + dead time + air')
ax.plot(d*100,fit,color='#245c87',lw=2,label='Raw data: phenomenological fit')
ax.axhline(mean,color='#176550',ls='--',lw=1.7,label='Corrected data: GLS constant')
ax.set(xlabel='Rail distance $d$ (cm)',ylabel=r'Rate × effective area (m$^2$ s$^{-1}$)',title='Measured data, corrections and fitted models',xlim=(0,88),ylim=(0,None));ax.grid(alpha=.15);ax.legend(frameon=False,fontsize=8.2,loc='lower right')
fig.savefig(P/'panel_b_with_fits.png',dpi=300,bbox_inches='tight');fig.savefig(P/'panel_b_with_fits.pdf',bbox_inches='tight')
