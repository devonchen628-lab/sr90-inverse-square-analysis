from pathlib import Path
import json,numpy as np,pandas as pd,matplotlib.pyplot as plt
from scipy.special import roots_legendre
from scipy.stats import chi2
P=Path(__file__).resolve().parent;root=P.parent;previous=root/'radioactivity_evidence_chain';df=pd.read_csv(previous/'pointwise_analysis.csv');Cfull=np.load(previous/'corrected_covariance.npz')['conditional'];ff=json.loads((root/'poisson_forward_model/fit_summary.json').read_text())
d=df.d_cm.to_numpy()/100;n=df.counts.to_numpy();t=df.time_s.to_numpy();R=n/t;sd=.0005;delta=.015;tau=2e-6;L=.01;rs=.011;K=ff['K_m2_per_s'];mu=ff['mu_per_m']
z,w=roots_legendre(32);w=w/2;phi=2*np.pi*(np.arange(64)+.5)/64;x=rs*np.sqrt((z+1)/2)[:,None]*np.cos(phi);y=rs*np.sqrt((z+1)/2)[:,None]*np.sin(phi);x1=-L/2-x;x2=L/2-x;y1=-L/2-y;y2=L/2-y
def h(ds):
 def f(a,b,r):return np.arctan2(a*b,r*np.sqrt(r*r+a*a+b*b))
 return np.array([np.sum(w[:,None]*(f(x2,y2,r)-f(x1,y2,r)-f(x2,y1,r)+f(x1,y1,r)))/64/L**2 for r in np.atleast_1d(ds)+delta])
h0=h(d);hp=(h(d+1e-6)-h(d-1e-6))/(2e-6);sr=np.sqrt(n)/t;Rdt=R/(1-tau*R);gdt=Rdt/h0;gdtse=np.sqrt((sr/(1-tau*R)**2/h0)**2+(gdt*hp/h0*sd)**2)
stages=[('Raw Rd2',df.raw_Rd2.to_numpy(),np.diag(df.raw_unc.to_numpy()**2)),('Geometry corrected',df.geometry_corrected.to_numpy(),np.diag(df.geometry_unc.to_numpy()**2)),('Geometry + dead time',gdt,np.diag(gdtse**2)),('Model corrected + air',df.fully_corrected.to_numpy(),Cfull)]
rows=[]
for label,y,C in stages:
 one=np.ones(len(y));wgt=np.linalg.solve(C,one);mean=wgt@y/(one@wgt);se=np.sqrt(1/(one@wgt));q=(y-mean)@np.linalg.solve(C,y-mean);nu=len(y)-1
 rows.append({'stage':label,'N_points':len(y),'mean_conditional':mean,'mean_unc_conditional':se,'chi2_conditional':q,'dof_nominal':nu,'reduced_chi2_conditional':q/nu,'formal_nominal_log10_p':chi2.logsf(q,nu)/np.log(10),'notes':'conditional only; shared offset and model assumptions omitted; p not validated; data-derived covariance' if 'air' in label else 'conditional counting and independent 0.5 mm rail only; shared geometry and repeatability omitted'})
pd.DataFrame(rows).to_csv(P/'conditional_constancy_diagnostics.csv',index=False)
full=stages[-1][1];fullse=np.sqrt(np.diag(Cfull));last=rows[-1];K0=last['mean_conditional'];K0se=last['mean_unc_conditional'];
# A single raw-data forward model; physical parameters are fixed offset and fitted K,mu.
grid=np.linspace(.005,.85,1000);fg=K*(grid/(grid+delta))**2*np.exp(-mu*(grid+delta))
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42})
fig,(ax,bx,cx)=plt.subplots(3,1,figsize=(7.2,8.3),sharex=True,gridspec_kw={'height_ratios':[1,1.1,1]},layout='constrained')
ax.errorbar(df.d_cm,df.raw_Rd2,xerr=.05,yerr=df.raw_unc,fmt='o',color='#30383c',ms=3.2,capsize=1.4,elinewidth=.6,label='Raw measurements (Book2)');ax.plot(grid*100,fg,color='#165a81',lw=1.8,label='Offset + effective exponential fit');ax.set(title='(a) Raw data and phenomenological fit',ylabel=r'$Rd^2$ (m$^2$ s$^{-1}$)',ylim=(0,None));ax.legend(frameon=False,fontsize=7.2,loc='lower right')
bx.errorbar(df.d_cm,df.raw_Rd2,yerr=df.raw_unc,fmt='o',ms=2.7,capsize=1,elinewidth=.5,color='#9ba5ab',label='Raw');bx.errorbar(df.d_cm,df.geometry_corrected,yerr=df.geometry_unc,fmt='s',ms=2.7,capsize=1,elinewidth=.5,color='#d58b26',label='Geometry corrected');bx.errorbar(df.d_cm,full,yerr=fullse,fmt='^',ms=2.7,capsize=1,elinewidth=.5,color='#008671',label='Geometry + dead time + air');bx.set(title='(b) Successive model-dependent corrections',ylabel=r'Rate × effective area (m$^2$ s$^{-1}$)');bx.legend(frameon=False,fontsize=7,ncol=1,loc='lower right')
cx.errorbar(df.d_cm,full,yerr=fullse,fmt='o',ms=3,capsize=1.4,elinewidth=.6,color='#176550',label='Corrected estimates');cx.axhline(K0,color='#176550',lw=1.5,label='GLS constant (conditional)');cx.axhspan(K0-K0se,K0+K0se,color='#176550',alpha=.15,label='Conditional fit error');cx.set(title='(c) Corrected estimate versus constant',ylabel=r'$K_{\rm est}$ (m$^2$ s$^{-1}$)',xlabel='Rail distance $d$ (cm)',xlim=(0,88));cx.legend(frameon=False,fontsize=7.1,loc='lower right')
for a in [ax,bx,cx]:a.grid(alpha=.14)
fig.savefig(P/'two_fit_evidence.png',dpi=300,bbox_inches='tight');fig.savefig(P/'two_fit_evidence.pdf',bbox_inches='tight')
info={'fit_A':{'K':K,'mu_per_m':mu,'offset_mm':15,'joint_penalized_objective':ff['joint_penalized_deviance'],'max_distance_shift_mm':ff['maximum_distance_shift_mm'],'warning':'phenomenological and poor conditional fit; count likelihood + Gaussian constrained positions; no full systematic uncertainty'},'fit_B':last,'warning':'p values are only formal conditional diagnostics, not calibrated significance: incomplete covariance, limited independent Geant4 batches, beta transport and geometry are model assumptions; stage quantities have different transformations so chi-square changes do not isolate individual physical effects.'};(P/'summary.json').write_text(json.dumps(info,indent=2))
print(json.dumps(info,indent=2));print(pd.DataFrame(rows).to_string(index=False))
