from pathlib import Path
import concurrent.futures, subprocess, os, json, hashlib, csv, time
root=Path('/Users/chenqiyue/Documents/Codex/2026-10-29/r'); out=Path(__file__).resolve().parent
binary=root/'work/offset21_shift31/build/task16_sensitivity.app/Contents/MacOS/task16_sensitivity'
spectrum=root/'outputs/sr90_research/inputs/geant_source/spectra_unique.csv'
basedir=Path('/Users/chenqiyue/Documents/Codex/2026-10-12/https-chatgpt-com-share-6acd35f5-5168/.runtime/geant4/share/Geant4/data')
env=os.environ.copy();env.pop('TASK16_GEOMETRY_VIEW',None);env.pop('TASK16_VIS_MACRO',None)
for k,name in [('G4LEDATA','EMLOW'),('G4LEVELGAMMADATA','PhotonEvaporation'),('G4RADIOACTIVEDATA','RadioactiveDecay'),('G4ENSDFSTATEDATA','ENSDFSTATE')]:
 matches=list(basedir.glob(name+'*')); assert matches, (k,basedir);env[k]=str(matches[0])
ds=[0,.01,.025,.05,.075,.1,.125,.15,.175,.2]
plan={'distances_m':ds,'offset_mm':19.05,'center_x_mm':0,'center_y_mm':0,'nsource_per_batch':400000,'npop_per_stage':16000,'batches':8,'source_recess_mm':6,'detector_recess_mm':3,'source_diameter_mm':22,'source_aperture_diameter_mm':11,'threshold_keV':10,'model':'air SMC, same solids as offset21_shift31','binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest()}
(out/'plan.json').write_text(json.dumps(plan,indent=2))
def run(i):
 csvpath=out/f'batch_{i:02}.csv'; cmd=[str(binary),str(spectrum),str(csvpath),','.join(map(str,ds)),'400000','16000',str(1940110000+i*100003),'11','5.5','smc','10','10','19.05','0','0']
 t=time.time()
 with (out/f'batch_{i:02}.log').open('w') as f:subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
 rows=list(csv.DictReader(csvpath.open())); assert len(rows)==len(ds)*6
 for a in rows: assert abs(float(a['active_distance_m'])-float(a['distance_m'])-.01905)<1e-10 and float(a['height_mm'])==0 and float(a['lateral_x_mm'])==0
 log=(out/f'batch_{i:02}.log').read_text(); assert not any(x in log for x in ['G4Exception','Overlap is detected','Fatal','ERROR'])
 print(f'Batch {i+1} complete in {time.time()-t:.1f}s',flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:list(ex.map(run,range(8)))
