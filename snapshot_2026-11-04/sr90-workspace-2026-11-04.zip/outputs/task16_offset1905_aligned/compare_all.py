from pathlib import Path
import numpy as np,pandas as pd,matplotlib.pyplot as plt
p=Path(__file__).resolve().parent; base=p.parent/'sr90_research';raw=pd.read_csv(base/'results/raw_observations.csv');raw=raw[raw.d_m<=.200001]; latest=pd.read_csv(base/'results/last_three.csv');latest=latest[(latest.d_m<=.200001)&(latest.d_m>=.01)]
rows=[]
def add(group,d,N,t,source):
 u=N/t*d*d;s=u*np.sqrt(1/N+(2*.0005/d)**2);rows.append(dict(series=group,d_m=d,counts=N,time_s=t,Cd2=u,Cd2_unc=s,source=source))
for d,g in raw[raw.selected_last_three==0].groupby('d_m'):
 add('Earlier three in task16 workbook',d,g.counts.sum(),g.time_s.sum(),'task 16 data.xlsx rows '+','.join(map(str,g.row)))
older=pd.read_csv(base/'inputs/Task16_older.csv');older['d']=pd.to_numeric(older['d'],errors='coerce');older['n']=pd.to_numeric(older['n'],errors='coerce');older['t']=pd.to_numeric(older['t'],errors='coerce')
for _,x in older[(older.d<=.2)&older.n.notna()&older.t.notna()].iterrows():
 duplicates=raw[(np.isclose(raw.d_m,x.d))&(raw.counts==x.n)&(np.isclose(raw.time_s,x.t))]
 if len(duplicates):continue
 add('Older Task16.csv',x.d,x.n,x.t,'Task16.csv')
prior=pd.read_csv(p.parent/'task16_all_datasets/all_datasets_processed.csv');prior=prior[(prior.dataset=='book2_lower')&(prior.d_m<=.2)]
for _,x in prior.iterrows():
 duplicates=raw[np.isclose(raw.d_m,x.d_m)&(raw.counts==x.counts)&np.isclose(raw.time_s,x.time_s)]
 if len(duplicates):continue
 add('Book2 additional records',x.d_m,x.counts,x.time_s,'Book2.xlsx Sheet1 row '+str(x.source_rows))
extra=pd.DataFrame(rows);extra.to_csv(p/'additional_measurements.csv',index=False)
sim=pd.read_csv(p/'simulation_summary.csv');ds=sim.d_cm;fig,ax=plt.subplots(figsize=(9.2,5.8),layout='constrained')
ax.plot(ds,sim.scaled_Cd2_m2_per_s,color='#d15a34',lw=2,label='Geant4 (same normalization as previous figure)');ax.fill_between(ds,sim.scaled_Cd2_m2_per_s-sim.scaled_Cd2_mc_se,sim.scaled_Cd2_m2_per_s+sim.scaled_Cd2_mc_se,color='#d15a34',alpha=.15,label='Geant4 statistical uncertainty (1σ)')
ax.errorbar(latest.d_m*100,latest.raw_u,xerr=.05,yerr=latest.book2_u_se,fmt='o',ms=5.5,capsize=3,color='#14597a',label='Latest three measurements (mean)')
for name,fmt,col in [('Earlier three in task16 workbook','s','#8c5cab'),('Older Task16.csv','^','#b18213'),('Book2 additional records','D','#3c946a')]:
 z=extra[extra.series==name];ax.errorbar(z.d_m*100,z.Cd2,xerr=.05,yerr=z.Cd2_unc,fmt=fmt,ms=5.3,capsize=3,color=col,label=name)
ax.axvspan(12.5,20,color='#e9edf1',alpha=.5,zorder=-1);ax.set(xlabel='Rail distance d (cm)',ylabel=r'$Cd^2$ (m$^2$ s$^{-1}$)',title='Task 16: previous measurements and Geant4');ax.set_xlim(0,20.7);ax.set_ylim(bottom=0);ax.grid(alpha=.16);ax.legend(frameon=True,fontsize=8.4,loc='lower right');fig.savefig(p/'comparison_all_measurements.png',dpi=220);fig.savefig(p/'comparison_all_measurements.pdf');print(extra[['series','d_m','counts','time_s','Cd2']].to_string(index=False))
