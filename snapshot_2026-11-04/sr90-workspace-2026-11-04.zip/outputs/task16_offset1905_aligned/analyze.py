from pathlib import Path
import numpy as np,pandas as pd,matplotlib.pyplot as plt,json
from scipy.optimize import minimize_scalar
p=Path(__file__).resolve().parent
frames=[]
for i in range(8):
 x=pd.read_csv(p/f'batch_{i:02}.csv');x=x[x.threshold_keV==10].sort_values('distance_m');frames.append(x.probability.to_numpy());ds=x.distance_m.to_numpy()
arr=np.array(frames); prob=arr.mean(axis=0); se=arr.std(axis=0,ddof=1)/np.sqrt(len(arr))
assert np.all(np.isfinite(arr)) and np.all(prob>0)
raw=pd.read_csv(p.parent/'sr90_research/results/last_three.csv');raw=raw[raw.d_m<=.200001].copy();raw=raw[raw.d_m>=.01]
ids=[np.where(np.isclose(ds,d))[0][0] for d in raw.d_m]; mask=(raw.d_m>=.125).to_numpy(); obs=raw.rate_cps.to_numpy();u=raw.poisson_rate_se.to_numpy(); pred=prob[ids];w=1/u[mask]**2
A=np.sum(w*obs[mask]*pred[mask])/np.sum(w*pred[mask]**2)
# Resample whole batches to preserve covariance across distances and fitted normalization.
rng=np.random.default_rng(909);boot=[]
for _ in range(4000):
 ps=arr[rng.integers(0,len(arr),len(arr))].mean(axis=0);pobs=ps[ids];ab=np.sum(w*obs[mask]*pobs[mask])/np.sum(w*pobs[mask]**2);boot.append(ab*ps)
boot=np.asarray(boot);sim=A*prob;sim_se=boot.std(axis=0,ddof=1)
output=pd.DataFrame({'d_cm':ds*100,'active_distance_mm':ds*1000+19.05,'detection_probability_10keV':prob,'probability_mc_se':se,'scaled_rate_cps':sim,'scaled_rate_mc_se_conditional':sim_se,'scaled_Cd2_m2_per_s':sim*ds**2,'scaled_Cd2_mc_se':sim_se*ds**2});output.to_csv(p/'simulation_summary.csv',index=False)
comp=pd.DataFrame({'d_cm':raw.d_m*100,'data_rate_cps':obs,'data_rate_poisson_se':u,'model_rate_cps':sim[ids],'model_mc_se_conditional':sim_se[ids],'data_Cd2':raw.raw_u,'data_Cd2_book2_se':raw.book2_u_se,'ratio_data_model':obs/sim[ids]});comp.to_csv(p/'comparison.csv',index=False)
fig,ax=plt.subplots(figsize=(8,5.1),layout='constrained');d=ds*100
ax.plot(d,sim*ds**2,'-',color='#d45c34',lw=2,label='Geant4: common fitted scale');ax.fill_between(d,np.maximum(0,sim-sim_se)*ds**2,(sim+sim_se)*ds**2,color='#d45c34',alpha=.2,label='Simulation statistical uncertainty (1σ)')
ax.errorbar(raw.d_m*100,raw.raw_u,xerr=.05,yerr=raw.book2_u_se,fmt='o',markersize=5,capsize=3,color='#205977',label='Measurement: last 3, Book2 uncertainty')
ax.axvspan(12.5,20,color='#e9edf1',alpha=.6,zorder=-1,label='Scale fitted using 12.5–20 cm data')
ax.set(xlabel='Rail distance d (cm)',ylabel=r'$Cd^2$ (m$^2$ s$^{-1}$)',title='Task 16: data and Geant4, offset 19.05 mm');ax.set_xlim(0,20.6);ax.set_ylim(bottom=0);ax.grid(alpha=.18);ax.legend(frameon=False,fontsize=9,loc='lower right')
fig.savefig(p/'comparison_Cd2.png',dpi=220);fig.savefig(p/'comparison_Cd2.pdf');print(json.dumps({'scale_fit':A,'distance_points_cm':list(d),'ratios':comp[['d_cm','ratio_data_model']].to_dict(orient='records')},indent=2))
