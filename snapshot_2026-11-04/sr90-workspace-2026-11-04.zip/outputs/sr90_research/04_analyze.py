"""Reproducible Sr-90 Task16 analysis. Run after 01_extract_audit.py.
Fits untransformed rates with a log-Gaussian counting/reading approximation.
The nominal p values omit unmeasured correlated systematics and overdispersion.
"""
from pathlib import Path
import csv,json,math,os
import numpy as np
from scipy import optimize,stats
from scipy.special import lambertw
from scipy.stats import qmc
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import shutil
P=Path(__file__).resolve().parent;I=P/'inputs';O=P/'results';F=P/'figures';O.mkdir(exist_ok=True);F.mkdir(exist_ok=True)
with (O/'last_three.csv').open() as f:rows=list(csv.DictReader(f))
def col(k):return np.array([float(z[k]) for z in rows])
d=col('d_m');N=col('counts');time=col('time_s');rate=N/time;u=rate*d*d;su=col('book2_u_se');sd=.0005; S=1e-4; L=.01; a=L/2;delta0=.021;tau=json.loads((O/'timing_fit.json').read_text())['soft_delay_mu_us']*1e-6
assert len(d)==32
# Full 4π per-electron fraction of isotropic point emission into the square.
def square_prob(r):return np.arctan2(a*a,r*np.sqrt(r*r+2*a*a))/np.pi
# Importance-sample random source positions and detector-target directions; solid-angle Jacobian carries the exact 4π weight.
# Independent scrambled low-discrepancy batches supply an empirical integration error.
geom_seed=20261102; B=8; exp=15; dd=np.array([.016,.021,.025]); radius=[.0055,.011]; geo_mc={}
for rad in radius:
 vals=[]
 for j in range(B):
  z=qmc.Sobol(d=4,scramble=True,seed=geom_seed+j).random_base2(exp); rr=rad*np.sqrt(z[:,0]);phi=2*np.pi*z[:,1];sx=rr*np.cos(phi);sy=rr*np.sin(phi);tx=L*(z[:,2]-.5);ty=L*(z[:,3]-.5);h2=(tx-sx)**2+(ty-sy)**2
  slab=[]
  for off in dd:
   r=d+off;prob=np.array([np.mean(S*x/(4*np.pi*(x*x+h2)**1.5)) for x in r]);slab.append(prob)
  vals.append(slab)
 vals=np.array(vals);geo_mc[str(rad)]=dict(mean=vals.mean(0).tolist(),se=(vals.std(0,ddof=1)/np.sqrt(B)).tolist())
# Independent implementation check: zero-radius integral vs exact square.
z=qmc.Sobol(2,scramble=True,seed=88).random_base2(16);tx=L*(z[:,0]-.5);ty=L*(z[:,1]-.5);test_r=.031;integral=np.mean(S*test_r/(4*np.pi*(test_r**2+tx**2+ty**2)**1.5));assert abs(integral/square_prob(test_r)-1)<2e-4
# f is an effective probability per area (m^-2); K is a rate-distance-squared scale.
def shape(r,kind):
 if kind=='inverse':return 1/r**2
 if kind=='square':return 4*np.pi*square_prob(r)/S
 raise ValueError(kind)
def pred(dd,K,delta,kind,dead=False,b=0):
 true=K*shape(dd+delta,kind)+b
 return true/(1+tau*true) if dead else true
def slope(dd,K,delta,kind,dead=False,b=0):
 h=1e-6;return (np.log(pred(dd+h,K,delta,kind,dead,b))-np.log(pred(dd-h,K,delta,kind,dead,b)))/(2*h)
def calc(mask,kind,delta,dead=False,b=0):
 x=d[mask]; n=N[mask]; y=rate[mask];
 def objective(z):
  K=np.exp(z);m=pred(x,K,delta,kind,dead,b);g=slope(x,K,delta,kind,dead,b);sig=np.sqrt(1/n+(sd*g)**2);return np.sum(((np.log(y)-np.log(m))/sig)**2)
 opt=optimize.minimize_scalar(objective,bounds=(-5,6),method='bounded');K=float(np.exp(opt.x));chi=float(opt.fun);df=len(x)-1;h=1e-4;curv=(objective(opt.x+h)+objective(opt.x-h)-2*chi)/h**2;err=float(K*np.sqrt(2/curv)) if curv>0 else None
 mu=pred(x,K,delta,kind,dead,b)*time[mask];dev=2*np.sum(np.where(n>0,n*np.log(n/mu)-(n-mu),mu));g=slope(x,K,delta,kind,dead,b);res=(np.log(y)-np.log(pred(x,K,delta,kind,dead,b)))/np.sqrt(1/n+(sd*g)**2)
 return dict(K=K,conditional_se=err,chi2=chi,df=df,red_chi2=chi/df,p_nominal=float(stats.chi2.sf(chi,df)),poisson_deviance_fixed_positions=float(dev),residual=res.tolist(),prediction=pred(x,K,delta,kind,dead,b).tolist())
mask=np.ones(len(d),bool);models={}
for label,kind,off,dead in [('M0 ideal','inverse',0,False),('M1 offset16','inverse',.016,False),('M1 offset21','inverse',.021,False),('M1 offset25','inverse',.025,False),('M2 square21','square',.021,False),('M3 square21 deadtime2us','square',.021,True)]:models[label]=calc(mask,kind,off,dead)
# Profile scale and free effective δ. This is a poor-model, conditional diagnostic, not a measured apparatus length.
def prof(off):return calc(mask,'inverse',off)['chi2']
popt=optimize.minimize_scalar(prof,bounds=(0,.05),method='bounded',options={'xatol':1e-11});deltafit=float(popt.x);modfree=calc(mask,'inverse',deltafit);modfree['df']=30;modfree['red_chi2']=modfree['chi2']/30;modfree['p_nominal']=float(stats.chi2.sf(modfree['chi2'],30));modfree['delta_mm']=deltafit*1000
# Profile Δχ²=1 is conditional; no scientifically complete coverage under misspecification.
def edge(l,r):return optimize.brentq(lambda x:prof(x)-modfree['chi2']-1,l,r) if (prof(l)-modfree['chi2']-1)*(prof(r)-modfree['chi2']-1)<0 else None
modfree['conditional_delta1_interval_mm']=[None if z is None else 1000*z for z in [edge(0,deltafit),edge(deltafit,.05)]];models['M1 fitted offset']=modfree
# Matched Geant4 transport at actual 8 knots; full across-distance covariance.
with (O/'geant_air_vacuum_8points.csv').open(encoding='utf-8-sig') as f:ar=list(csv.DictReader(f))
x8=np.array([float(z['d_cm'])/100 for z in ar]);TT=np.array([float(z['air_over_vacuum']) for z in ar]);ix=np.array([np.where(np.isclose(d,x))[0][0] for x in x8]);covnp=np.load(O/'air_transport_covariance.npz');covd=covnp['distances_m'];cov=covnp['log_correction_covariance'];ci=np.array([np.where(np.isclose(covd,x))[0][0] for x in x8]);covT=cov[np.ix_(ci,ci)]
assert np.min(np.linalg.eigvalsh(covT))>-1e-8
m8=np.zeros(len(d),bool);m8[ix]=True
for key,kind,off,dead in [('M0 ideal','inverse',0,False),('M1 offset21','inverse',.021,False),('M2 square21','square',.021,False),('M3 square21 deadtime2us','square',.021,True)]:models[key]['eight_point_comparison']=calc(m8,kind,off,dead)
# T is taken at knots only, treating shape as hybrid point-square × full apparatus transmission.
# A small derivative of log T over rail distance is estimated for 0.5mm independent rail reading only.
gT=np.gradient(np.log(TT),x8); rr=rate[ix];nn=N[ix]
def hybrid(z):
 K=np.exp(z);true=K*shape(x8+delta0,'square')*TT;predr=true/(1+tau*true);g=slope(x8,K,delta0,'square',False)+gT;g=g/(1+tau*true)
 V=np.diag(1/nn+(sd*g)**2)+covT; e=np.log(rr)-np.log(predr);return float(e@np.linalg.solve(V,e))
opt=optimize.minimize_scalar(hybrid,bounds=(-5,6),method='bounded');Kh=float(np.exp(opt.x));ch=float(opt.fun);h=1e-4;hcurv=(hybrid(opt.x+h)+hybrid(opt.x-h)-2*ch)/h**2;Kh_se=float(Kh*np.sqrt(2/hcurv)) if hcurv>0 else None;hy=Kh*shape(x8+delta0,'square')*TT;hy=hy/(1+tau*hy);models['M4 hybrid 8 knots']={'K':Kh,'conditional_se':Kh_se,'chi2':ch,'df':7,'red_chi2':ch/7,'p_nominal':float(stats.chi2.sf(ch,7)),'prediction':hy.tolist(),'warning':'exploratory hybrid: point source geometry multiplied by full-geometry Geant4 transport; MC covariance estimated, physical-model covariance unknown; 8 points only'}
# Repeated observations, including unused first triples: test stationary Poisson per group.
with (O/'raw_observations.csv').open() as f: raw=list(csv.DictReader(f))
rep=[]
for dd0 in d:
 zz=[z for z in raw if abs(float(z['d_m'])-dd0)<1e-9 and int(z['selected_last_three'])]; nn=np.array([int(z['counts']) for z in zz]);tt=np.array([float(z['time_s']) for z in zz]);rr0=nn.sum()/tt.sum();Q=float(sum((nn-rr0*tt)**2/(rr0*tt)));rep.append(dict(d_cm=float(dd0*100),Q=Q,df=2,p_nominal=float(stats.chi2.sf(Q,2))))
# Explicit first/return triplets only; source group labels inferred from blank rows, confirmed earlier by user.
pairs=[]
for dd0 in d:
 zz=[z for z in raw if abs(float(z['d_m'])-dd0)<1e-9];groups=sorted(set(int(z['group']) for z in zz))
 if len(zz)==6 and groups==[1,2] and all(sum(int(z['group'])==g for z in zz)==3 for g in groups):
  n1=sum(int(z['counts']) for z in zz if int(z['group'])==1);t1=sum(float(z['time_s']) for z in zz if int(z['group'])==1);n2=sum(int(z['counts']) for z in zz if int(z['group'])==2);t2=sum(float(z['time_s']) for z in zz if int(z['group'])==2);r1=n1/t1;r2=n2/t2;change=r2/r1-1;se=(r2/r1)*np.sqrt(1/n1+1/n2);pooled=(n1+n2)/(t1+t2);qpair=(n1-pooled*t1)**2/(pooled*t1)+(n2-pooled*t2)**2/(pooled*t2);pairs.append(dict(d_cm=dd0*100,first=r1,returned=r2,relative_change=change,conditional_se=se,poisson_pearson_Q=qpair))
Qreturn=sum(z['poisson_pearson_Q'] for z in pairs)
# Data sensitivity: last-three versus pooling all recorded repeats.
allrate=[]
for dd0 in d:
 z=[v for v in raw if abs(float(v['d_m'])-dd0)<1e-9];allrate.append(sum(int(v['counts']) for v in z)/sum(float(v['time_s']) for v in z))
allrate=np.array(allrate);select_effect=np.abs(rate/allrate-1)
# Dead-time comparison, solving true e^- for paralyzable low-rate branch.
nonpar=rate/(1-rate*tau);par=-np.real(lambertw(-rate*tau,0))/tau
# Task 19 measured b=5/60 in separate context; older Task16 b=8/60; use as diagnostic, not pinned to current scan.
backgrounds={'older_task16':8/60,'task19_separate':5/60,'raw_model_main':0};
timing_sensitivity=[{'tau_us':t*1e6,'nonpar_correction_pct':float(100*(1/(1-rate[0]*t)-1)),'par_correction_pct':float(100*(-np.real(lambertw(-rate[0]*t,0))/(t*rate[0])-1))} for t in [1.2e-6,2e-6,3e-6]];
Sgeom=np.array([square_prob(x+delta0)/(S/(4*np.pi*(x+delta0)**2)) for x in d]);
# Threshold sensitivity from six saved independent G2 simulation batches. Same histories across thresholds.
thresholds=[.1,5.,10.,20.,40.,60.]; batches=sorted((I/'geant_threshold_batches').glob('batch_*.csv'));assert len(batches)==6
threshold_vals=[];source_corrected=rate/(1-tau*rate)-(8/60)/(1-tau*(8/60))
for th in thresholds:
 data_batches=[]
 for file in batches:
  rr=list(csv.DictReader(file.open()));data_batches.append([float(next(q['probability'] for q in rr if abs(float(q['distance_m'])-x)<1e-10 and float(q['threshold_keV'])==th)) for x in x8])
 pp=np.mean(data_batches,axis=0);scale=np.exp(np.mean(np.log(source_corrected[ix][5:]/pp[5:])));rv=source_corrected[ix]/(scale*pp);threshold_vals.append({'threshold_keV':th,'nearest_ratio':float(rv[0]),'near_ratio':rv[:5].tolist()})
# A single apparent ideal K cannot identify activity separately from efficiency or Sr/Y emission multiplicity.
result={'protocol':{'dataset':'last 3 per distance, exact worksheet order','n_distances':32,'n_observations':96,'u_formula':'rate*d^2','rail_sigma_m':sd,'sigma_assumption':'Book2 uses ±0.5mm as standard uncertainty; individual effects assumed independent for conditional test; common offset systematic is not included in per-point diagonal','background_main':0,'tau_seconds_sensitivity':tau,'air_model':'conditional 8 actual knots, prior data-informed G2 geometry; no single comprehensive systematics band'},'models':models,'repeat_tests':rep,'return_checks':{'n_pairs':len(pairs),'Q':float(Qreturn),'df':len(pairs),'p_nominal':float(stats.chi2.sf(Qreturn,len(pairs))),'pairs':pairs},'all_vs_last3_max_rate_pct':float(100*max(select_effect)),'all_vs_last3_near_max_rate_pct':float(100*max(select_effect[d<=.1])),'deadtime':{'nearest_observed_rate':float(rate[0]),'tau_us':tau*1e6,'nonpar_true_nearest':float(nonpar[0]),'nonpar_correction_pct':float(100*(nonpar[0]/rate[0]-1)),'par_true_nearest':float(par[0]),'par_correction_pct':float(100*(par[0]/rate[0]-1))},'backgrounds':backgrounds,'threshold_sensitivity':threshold_vals,'timing_sensitivity':timing_sensitivity,'raw_summary':{'near_u':float(u[0]),'near_se':float(su[0]),'max_d_cm':float(d[np.argmax(u)]*100),'max_u':float(max(u)),'far_u':float(u[-1]),'far_se':float(su[-1])},'geometry':{'nominal_offset_m':delta0,'offset_scenarios_m':dd.tolist(),'square_factor_near':float(Sgeom[0]),'square_factor_far':float(Sgeom[-1]),'source_diameters_assumed_mm':[11,22],'qmc_batches':B,'qmc_per_batch':2**exp,'qmc_check_integral_ratio':float(integral/square_prob(test_r)),'extended_source':geo_mc},'air_vacuum':{'distances_cm':(x8*100).tolist(),'T':TT.tolist(),'T_se':[float(z['air_over_vacuum_MC_se']) for z in ar],'from_summary':json.loads((I/'geant_airvac_summary.json').read_text())},'activity':{'K_convention':'R=K/r^2 in point isotropic limit','identity':'K=A_parent * beta_per_parent * efficiency * S/(4*pi)','identifiable':'A_parent * beta_per_parent * efficiency = 4*pi*K/S; efficiency and emission multiplicity not independently calibrated','amplitude_sensitivity':'simple fit K is not physical activity if transport, offset or point-source assumptions are wrong'}}
(O/'analysis.json').write_text(json.dumps(result,indent=2)+'\n')
with (O/'model_comparison.csv').open('w',newline='') as f:
 writer=csv.DictWriter(f,fieldnames=['model','n_points','K','K_conditional_se','chi_squared','degrees_of_freedom','reduced_chi_squared','nominal_p','statistical_scope'])
 writer.writeheader()
 for name,m in models.items():
  writer.writerow(dict(model=name,n_points=8 if name.startswith('M4') else 32,K=m['K'],K_conditional_se=m.get('conditional_se'),chi_squared=m['chi2'],degrees_of_freedom=m['df'],reduced_chi_squared=m['red_chi2'],nominal_p=m['p_nominal'] if m['p_nominal'] else '<1e-300',statistical_scope='conditional, model-dependent; see RESULTS.md'))
with (O/'pointwise_residuals.csv').open('w',newline='') as f:
 writer=csv.DictWriter(f,fieldnames=['model','d_cm','measured_rate_cps','predicted_rate_cps','conditional_standardised_residual'])
 writer.writeheader()
 for name,m in models.items():
  if name.startswith('M4'):continue
  for j,dist in enumerate(d):writer.writerow(dict(model=name,d_cm=100*dist,measured_rate_cps=rate[j],predicted_rate_cps=m['prediction'][j],conditional_standardised_residual=m['residual'][j]))
 truehy=Kh*shape(x8+delta0,'square')*TT
 ghy=(slope(x8,Kh,delta0,'square',False)+gT)/(1+tau*truehy)
 marg=(np.log(rate[ix])-np.log(hy))/np.sqrt(1/N[ix]+(sd*ghy)**2+np.diag(covT))
 for j,dist in enumerate(x8):writer.writerow(dict(model='M4 hybrid 8 knots (marginal)',d_cm=100*dist,measured_rate_cps=rate[ix[j]],predicted_rate_cps=hy[j],conditional_standardised_residual=marg[j]))
# Figure 1: all 32 original-distance results; x/y errors are displayed, not both used as independent fit inputs.
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.labelsize':10,'axes.titlesize':11,'legend.fontsize':8.5,'axes.spines.right':False,'axes.spines.top':False,'svg.fonttype':'none'})
fig,ax=plt.subplots(figsize=(8.4,5),layout='constrained');ax.errorbar(d*100,u,xerr=sd*100,yerr=su,fmt='o',ms=4,elinewidth=.8,capsize=1.5,color='#1c6488',label='Last three repeats / position');K=models['M0 ideal']['K'];ax.axhline(K,color='#5c6670',ls='--',lw=1.1,label='Ideal point-source fit (all 32 points)');ax.set(xlim=(0,90),ylim=(0,16),xlabel='Recorded rail separation $d$ (cm)',ylabel=r'Raw count rate $\times\,d^2$ (m$^2$ s$^{-1}$)',title='Measured inverse-square product');ax.grid(alpha=.17);ax.legend(frameon=False,loc='lower right');fig.savefig(F/'figure1_raw.png',dpi=240);fig.savefig(F/'figure1_raw.svg');plt.close(fig)
# Figure 2: each conditional curve normalised to the same three far points, near data not used.
anchors=np.isin(d,[.3,.5,.85]);far=np.array([np.where(np.isclose(d,x))[0][0] for x in [.3,.5,.85]])
def far_scale(f):return np.exp(np.mean(np.log(rate[far]/f[far])))
def geom_curve(q):return far_scale(q)*q*d*d
ideal=geom_curve(1/d**2);sq=lambda off:geom_curve(square_prob(d+off));mm=np.array(geo_mc['0.011']['mean']);gext=geom_curve(mm[1]);low=sq(.016);high=sq(.025)
fig,ax=plt.subplots(figsize=(8.4,5),layout='constrained');near=d<=.15;ax.errorbar(d[near]*100,u[near],xerr=sd*100,yerr=su[near],fmt='o',color='#1c6488',ms=4,capsize=2,label='Raw data');ax.plot(d[near]*100,ideal[near],ls='--',color='#777',label='Ideal $1/d^2$');ax.plot(d[near]*100,sq(.021)[near],color='#c15b32',marker='s',ms=3,label='Square, offset 21 mm');ax.fill_between(d[near]*100,np.minimum(low,high)[near],np.maximum(low,high)[near],color='#e7b9a4',alpha=.45,label='Square: offset 16–25 mm (scenarios)');ax.plot(d[near]*100,gext[near],color='#29815d',marker='^',ms=3,label='Extended source, diameter 22 mm (assumed)');ax.set(xlim=(0,16),ylim=(0,16),xlabel='Recorded rail separation $d$ (cm)',ylabel=r'Raw rate $\times\,d^2$ (m$^2$ s$^{-1}$)',title='Near-field geometry: equal far-point scaling');ax.grid(alpha=.17);ax.legend(frameon=False,fontsize=8,loc='lower right');fig.savefig(F/'figure2_geometry.png',dpi=240);fig.savefig(F/'figure2_geometry.svg');plt.close(fig)
# Figure 3: same eight measured distances for all models. Curves are fitted on the 8 observations.
fig,(ax,bx)=plt.subplots(2,1,figsize=(8.4,7),sharex=True,gridspec_kw={'height_ratios':[1.4,1]},layout='constrained');ax.errorbar(d*100,rate,yerr=np.sqrt(N)/time,fmt='.',ms=4,color='#1c6488',label='Raw measurements'); colors={'M0 ideal':'#8a939a','M2 square21':'#c15b32','M4 hybrid 8 knots':'#674390'}
for key,kind,off,dead in [('M0 ideal','inverse',0,False),('M2 square21','square',.021,False)]:
 m=models[key]['eight_point_comparison'];pr=pred(d,m['K'],off,kind,dead);ax.plot(d*100,pr,color=colors[key],label=key);g=slope(x8,m['K'],off,kind,dead);res=(np.log(rate[ix])-np.log(pred(x8,m['K'],off,kind,dead)))/np.sqrt(1/N[ix]+(sd*g)**2);bx.plot(x8*100,res,'o',ms=3,color=colors[key],label=key)
m=models['M4 hybrid 8 knots'];ax.errorbar(x8*100,m['prediction'],yerr=np.array(m['prediction'])*np.sqrt(np.diag(covT)),fmt='D',ms=4,color=colors['M4 hybrid 8 knots'],capsize=2,elinewidth=.8,label='M4 hybrid: MC error, scale fixed');truehy=Kh*shape(x8+delta0,'square')*TT;gh=(slope(x8,Kh,delta0,'square',False)+gT)/(1+tau*truehy);rh=(np.log(rate[ix])-np.log(m['prediction']))/np.sqrt(1/N[ix]+(sd*gh)**2+np.diag(covT));bx.plot(x8*100,rh,'D',ms=3,color=colors['M4 hybrid 8 knots'],label='M4 hybrid (marginal errors)');ax.set_xscale('log');ax.set_yscale('log');ax.set(ylabel='Observed count rate (s$^{-1}$)',title='Model comparison at the eight Geant4 distances');ax.legend(frameon=False,fontsize=8);bx.axhline(0,color='#444',lw=.8);bx.set(xlabel='Recorded rail separation $d$ (cm; log scale)',ylabel='Conditional marginal residual');bx.set_xticks([1,2.5,5,10,30,50,85],labels=['1','2.5','5','10','30','50','85']);bx.grid(alpha=.17);ax.grid(alpha=.17);fig.savefig(F/'figure3_models.png',dpi=240);fig.savefig(F/'figure3_models.svg');plt.close(fig)
# Eight actual simulation points: no interpolation or forced exponential law.
fig,ax=plt.subplots(figsize=(8.4,4.7),layout='constrained')
ax.errorbar(x8*100,TT,yerr=[float(z['air_over_vacuum_MC_se']) for z in ar],fmt='o',ms=4.5,capsize=2,color='#936629',label='Matched Geant4 batches; MC uncertainty')
ax.axhline(1,ls='--',lw=.9,color='#75818b',label='Equal air/vacuum response')
ax.set(xlim=(0,90),ylim=(0,1.1),xlabel='Recorded rail separation $d$ (cm)',ylabel='Simulated detection probability: air / vacuum',title='Modelled beta transport: matched air versus vacuum')
ax.grid(alpha=.17);ax.legend(frameon=False,fontsize=8.5,loc='lower left')
fig.savefig(F/'figure4_transport.png',dpi=240);fig.savefig(F/'figure4_transport.svg');plt.close(fig)
# Small figures for two-column report, with explicit report caption and no inflated significance claims.
fig,ax=plt.subplots(figsize=(3.35,2.2),layout='constrained');ax.errorbar(d*100,u,xerr=sd*100,yerr=su,fmt='o',ms=2.6,elinewidth=.6,capsize=.8,color='#1c6488',label='Measured');ax.axhline(K,color='#707c85',ls='--',lw=.8,label='Ideal, fitted to all data');ax.set(xlim=(0,90),ylim=(0,16),xlabel='Rail separation $d$ (cm)',ylabel=r'$cd^2$ (m$^2$ s$^{-1}$)');ax.grid(alpha=.15);ax.legend(frameon=False,fontsize=6.5,loc='lower right');fig.savefig(F/'report_data.png',dpi=400);plt.close(fig)
fig,ax=plt.subplots(figsize=(3.35,2.05),layout='constrained');ax.errorbar(d[near]*100,u[near],xerr=sd*100,yerr=su[near],fmt='o',ms=2.6,elinewidth=.6,capsize=.8,color='#1c6488',label='Measured');ax.plot(d[near]*100,ideal[near],ls='--',lw=.8,color='#777',label='Ideal');ax.plot(d[near]*100,sq(.021)[near],color='#c15b32',lw=1,label='Square, 21 mm offset');ax.fill_between(d[near]*100,np.minimum(low,high)[near],np.maximum(low,high)[near],color='#e7b9a4',alpha=.45,label='Square, 16–25 mm');ax.plot(d[near]*100,gext[near],color='#29815d',lw=1,label='Extended source (22 mm)');ax.set(xlim=(0,16),ylim=(0,16),xlabel='Rail separation $d$ (cm)',ylabel=r'$cd^2$ (m$^2$ s$^{-1}$)');ax.legend(frameon=False,fontsize=6.2,loc='lower right');ax.grid(alpha=.15);fig.savefig(F/'report_geometry.png',dpi=400);plt.close(fig)
tex_images=P/'tex'/'images'
if tex_images.is_dir():
 for name in ('report_data.png','report_geometry.png'):shutil.copy2(F/name,tex_images/name)
print(json.dumps({k:v for k,v in result.items() if k!='geometry'},indent=2))
