"""Reproduce the matched Geant4 T ratio from complete original batch outputs."""
from pathlib import Path
import csv,json,numpy as np
P=Path(__file__).resolve().parent;I=P/'inputs';O=P/'results';knots=np.array([.01,.025,.05,.075,.1,.3,.5,.85]);d=np.array([float(x['d_m']) for x in csv.DictReader((O/'last_three.csv').open())])
def read(folder,n):
 files=sorted(folder.glob('batch_*.csv'));assert len(files)==n,(folder,len(files));mat=[]
 for file in files:
  rows=list(csv.DictReader(file.open()));mat.append([float(next(z['probability'] for z in rows if abs(float(z['distance_m'])-x)<1e-10 and float(z['threshold_keV'])==10)) for x in knots])
 return np.array(mat)
a=read(I/'geant_air_batches',8);v=read(I/'geant_vacuum_batches',12);pa=a.mean(axis=0);pv=v.mean(axis=0);T=pa/pv
rng=np.random.default_rng(251102);n=10000;ia=rng.integers(0,len(a),(n,len(a)));iv=rng.integers(0,len(v),(n,len(v)));boot=a[ia].mean(axis=1)/v[iv].mean(axis=1);draw=np.array([np.exp(np.interp(np.log(d),np.log(knots),np.log(t))) for t in boot]);cov=np.cov(-np.log(draw),rowvar=False,ddof=1)
ref=list(csv.DictReader((I/'geant_air_vacuum_8points.csv').open(encoding='utf-8-sig')));reference=np.array([float(x['air_over_vacuum']) for x in ref]);assert np.max(abs(T-reference))<1e-12
original=np.load(I/'air_transport_covariance.npz');assert np.allclose(cov,original['log_correction_covariance'],rtol=1e-9,atol=1e-12)
rows=[]
for i,x in enumerate(knots):rows.append(dict(d_cm=x*100,air_probability=pa[i],air_MC_se=a.std(0,ddof=1)[i]/np.sqrt(len(a)),vacuum_probability=pv[i],vacuum_MC_se=v.std(0,ddof=1)[i]/np.sqrt(len(v)),air_over_vacuum=T[i],air_over_vacuum_MC_se=boot.std(0,ddof=1)[i]))
with (O/'geant_air_vacuum_8points.csv').open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
np.savez_compressed(O/'air_transport_covariance.npz',distances_m=d,log_correction_covariance=cov)
ratio=boot[:,-1]/boot[:,5];info=dict(air_batches=len(a),vacuum_batches=len(v),bootstrap_draws=n,seed=251102,T30=float(T[5]),T85=float(T[-1]),T85_over_T30=float(T[-1]/T[5]),T85_over_T30_se=float(ratio.std(ddof=1)),exact_match_to_previous_probabilities=True,exact_match_to_previous_covariance=True,warning='Same assumed G2 apparatus; Monte Carlo error only, not physical-model uncertainty. No independent validation of actual threshold and geometry.')
(O/'transport_reproduction.json').write_text(json.dumps(info,indent=2)+'\n');print(json.dumps(info,indent=2))
