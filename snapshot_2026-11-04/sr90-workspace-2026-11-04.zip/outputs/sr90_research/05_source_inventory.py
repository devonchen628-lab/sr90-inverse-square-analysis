"""Optional read-only inventory of the full original Radlab directory."""
from pathlib import Path
import argparse,csv,json,hashlib,datetime
from openpyxl import load_workbook
P=Path(__file__).resolve().parent; parser=argparse.ArgumentParser();parser.add_argument('--source-dir',type=Path,default=Path('/Users/chenqiyue/Library/CloudStorage/OneDrive-ImperialCollegeLondon/Radlab'));arg=parser.parse_args();S=arg.source_dir
if not S.is_dir():raise FileNotFoundError('Supply original directory with --source-dir')
records=[]
for f in sorted(S.iterdir(),key=lambda x:x.name.lower()):
 if not f.is_file() or f.name.startswith('.'):continue
 raw=f.read_bytes();d=dict(name=f.name,size_bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),extension=f.suffix.lower())
 if f.suffix.lower()=='.xlsx':
  book=load_workbook(f,data_only=False,read_only=True);d['worksheets']=[dict(name=s.title,rows=s.max_row,columns=s.max_column) for s in book];book.close()
 elif f.suffix.lower()=='.csv':
  lines=raw.decode('utf-8-sig',errors='replace').splitlines();meta=[x for x in lines if x.startswith('#')];body=[x for x in lines if x.strip() and not x.startswith('#')];d['csv_header']=body[0] if body else '';d['csv_records']=max(0,len(body)-1);d['metadata']=meta
 elif f.suffix.lower() in ('.mac','.py','.txt'):
  lines=raw.decode('utf-8-sig',errors='replace').splitlines();d['text_lines']=len(lines);d['first_nonempty_line']=next((x[:160] for x in lines if x.strip()),'')
 records.append(d)
result=dict(source_directory=str(S),file_count=len(records),files=records,scope='All files listed and tabular structures inspected; unrelated Tasks 6–13 and 18–20 are inventoried, not treated as independent Task16 scan data.');(P/'results'/'source_directory_manifest.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print('Inventoried files:',len(records))
