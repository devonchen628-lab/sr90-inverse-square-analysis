# Scientific results and critical evaluation

## Experimental result

The primary data contain 96 count–time records at 32 positions. Raw Cd² is 1.828 ± 0.183 m² s⁻¹ at 1 cm, 13.331 ± 0.162 at 37.5 cm, and 9.826 ± 0.208 at 85 cm, using the Book2 error rule. From 30 cm (12.570 ± 0.159) to 85 cm the raw product falls by 21.8%. These statements describe the measured curve; they do not separately identify causes. `figure1_raw.png` shows horizontal and vertical errors and a single ideal constant fitted to all 32 raw rates, not a visually chosen plateau.

Repeatability checks matter: under independent stationary Poisson assumptions, the 12 explicitly identified first/return pairs have Pearson Q=54.03 for 12 degrees of freedom, nominal p=2.70×10⁻⁷. At 17.5 cm the return change is +6.37 ± 1.38%. The last three 55 cm counts alone yield Q=15.93 for 2 degrees of freedom, nominal p=0.00035. These are diagnostic, not a proof of the cause. Replacing last-three by all repeats changes the raw rate by at most 3.09% over the scan and 0.36% at 1–10 cm; it is not a user-authorised replacement of the primary dataset.

## Geometry and offset

The exact on-axis point-source square formula is used. At recorded d=10 mm, the illustrative 21 mm offset gives r=31 mm and F_geo=Ω/(S/r²)=0.97475: the finite square alone reduces the point-source acceptance by 2.5% relative to the small-area approximation. At the farthest point F_geo=0.999967. For fixed d=10 mm, changing δ from 16 to 25 mm changes the point-source square probability from 0.01135 to 0.00637 per isotropic 4π emission. This comparison holds all other model inputs fixed and does not say the real δ lies within a calibrated interval.

A geometry-only quasi-Monte Carlo samples a uniformly distributed emitting-disc position and a uniformly sampled detector target point, mapping each target to an emission direction. The Jacobian dΩ/dS and 1/(4π) give unbiased importance weights for isotropic full-sphere emission; backward emission is properly included in the denominator. It does not assume all electrons were emitted forward. Eight independently scrambled Sobol batches of 2¹⁵ points give, at r=31 mm: point-source probability 0.0080716; assumed 11 mm diameter disc 0.00789623 ± 0.0000000011; assumed 22 mm diameter disc 0.00741591 ± 0.0000000020. These tiny errors are numerical integration errors only and do not reflect unknown source dimensions, nonuniform activity, aperture, medium, or detector response. The independent zero-radius integration agrees with the exact square within 0.02%.

Figure 2 compares raw data to ideal, square and assumed extended-source predictions, each scaled by the same three far points (30, 50, 85 cm). The offset envelope is the span of explicitly tested 16–25 mm scenarios, each renormalised to those anchors, not a confidence band. At 1 cm the square-model products are 1.77, 1.28 and 1.03 m²/s for 16, 21 and 25 mm, respectively, against data 1.83 ± 0.18. A match at one distance does not establish that geometry is correct or that the rest of the curve is explained. Model curves omit air, losses and source aperture.

## Timing, background and transport

The decay chain ⁹⁰Sr → ⁹⁰Y → ⁹⁰Zr supplies continuous beta spectra with approximate endpoint energies 0.546 and 2.28 MeV. In air, collision losses, multiple Coulomb scattering and energy-loss straggling change the distribution of energies and directions reaching the detector; source encapsulation and detector response further affect the count. The matched simulation uses a nominal hard energy-deposition threshold. A single exponential attenuation coefficient is not assumed. See the [IAEA nuclide record](https://nucleus.iaea.org/sites/fcris/SitePages/Pestiside-Attributes/STRON.htm) and the [Geant4 Livermore electromagnetic model guide](https://geant4.web.cern.ch/documentation/pipelines/master/plg_html/PhysicsListGuide/electromagnetic/Liv.html).

The new interval histogram gives μ≈1.999 μs under the fitted soft-recovery / overflow-bin assumption; an idealised sharp-cutoff fit gives 1.187 μs. Neither fit establishes the actual non-paralysable or paralysable electronics response. The histogram bin width is 62.5 ns, while the lab script's 32.5 ns is an illustrative minimum interval. They are different from a calibrated dead time.

At the nearest recorded rate 18,280.7 s⁻¹, setting τ=2 μs yields a 3.79% inferred-rate correction under the non-paralysable model and 3.87% under the low-rate paralysable branch. Assumed 1.2–3 μs gives 2.24–5.80% and 2.27–5.98%, respectively. This is a sensitivity study; no automatic rate correction is made to the primary dataset.

The earlier Task16 background is 8/60=0.1333 s⁻¹; Task19 has 5/60=0.0833 s⁻¹ in another context. At d=85 cm, their contributions to Cd² are 0.0963 and 0.0602 m²/s, respectively; background adds upward to the raw product. These are not independently confirmed backgrounds for the current scan.

The matched assumed-geometry Geant4 response T=p_air/p_vac is 0.778±0.047 at 30 cm and 0.423±0.063 at 85 cm; T85/T30=0.543±0.079. Errors are Monte Carlo only, with batch correlations. T includes source-dependent spectrum, energy loss, angular redistribution and the 10 keV model threshold, not a pure absorption coefficient. It is not an experimental estimate of air attenuation. Changing only that hard threshold in a separate same-geometry six-batch study over 0.1–60 keV changes the far-normalised nearest measured/simulated ratio from 0.813 to 0.800; those thresholds share histories and do not determine the real electronics threshold. Geometry, source stack and response systematics remain unquantified.

## Model tests: conditional, not calibrated model probabilities

Fits are to raw count rates, using a log-Gaussian approximation with σ²_log R≈1/N+(σd ∂logR_model/∂d)². The Book2 0.5 mm is treated as a standard independent reading term, once; the shared offset is a model parameter/scenario, not 32 independent random shifts. Counts are large enough for the approximation in the selected dataset, but observed excess repeatability and an uncertain dead-time response make nominal p values conditional. Model parameters were explored after viewing the data. AIC/BIC are omitted because a complete calibrated common likelihood and physical-systematic covariance are unavailable.

| Model, common amplitude fitted | Number of points | Conditional χ² / df | Nominal p | Interpretation |
|---|---:|---:|---:|---|
| M0: K/d² | 32 | 2001.6 / 31 | <10⁻³⁰⁰ | Raw ideal model inadequate under stated errors. |
| M1: K/(d+16 mm)² | 32 | 1214.7 / 31 | 1.2×10⁻²³⁵ | Better than M0 under these conditions, still inadequate. |
| M1: K/(d+21 mm)² | 32 | 2083.1 / 31 | <10⁻³⁰⁰ | A prescribed offset alone is not a complete model. |
| M1: K/(d+25 mm)² | 32 | 3309.2 / 31 | <10⁻³⁰⁰ | Sensitive to offset and strongly misspecified. |
| M1: offset fitted (K and δ) | 32 | 980.6 / 30 | 6.4×10⁻¹⁸⁷ | δ_fit=11.42 mm is a poor-model parameter, not a hardware measurement; Δχ²=1 profile 11.11–11.73 mm excludes unmeasured systematics and is not a valid calibrated physical confidence interval. |
| M2: exact square, δ=21 mm | 32 | 2135.9 / 31 | <10⁻³⁰⁰ | Point-source square alone is insufficient. |
| M3: M2 with assumed 2 μs non-paralysable response | 32 | 2200.9 / 31 | <10⁻³⁰⁰ | Does not repair the full-distance shape. |
| M4: M2 × matched Geant4 T with 2 μs response | 8 | 25.91 / 7 | 0.00052 | Exploratory hybrid; includes MC covariance but multiplies point-square geometry by T derived from a finite-source apparatus. It is not an exact full Geant4 model, not the same 32-point sample, and excludes model covariance. |

The fitted scale parameters (conditional curvature errors; m² s⁻¹) are: M0 **12.031 ± 0.028**; M1 fixed δ=16, 21 and 25 mm **13.691 ± 0.031**, **14.304 ± 0.032**, and **14.830 ± 0.033**; M2 **14.319 ± 0.032**; M3 **14.334 ± 0.032**; and M4 **19.06 ± 0.29**. The M4 value is based on eight points and the estimated MC covariance. These errors condition on each model and its fixed geometry; they omit physical-model uncertainty and must not be interpreted as total experimental errors. The fitted-offset model gives K=13.172 ± 0.030 if δ is held fixed at its fitted value; this is not a joint K–δ uncertainty.

For a like-for-like eight-distance comparison, M0 gives 1131.7/7 and M2 gives 678.5/7 under the same nominal individual-reading scheme; M4 uses a different covariance because T has correlated MC uncertainty. These tests are exploratory and should not be read as a definitive ranking or proof of causation. `figure3_models.png` shows marginal residuals; their points are correlated, and the displayed scale is not a complete uncertainty budget. The fit objective is conditional weighted least squares, not an exact Poisson likelihood; fixed-position Poisson deviance is included as a diagnostic in `results/analysis.json` but does not account for rail error, dead time, or drift.

## Activity

Under the ideal point-source limit, K=A_parent b_beta ε S/(4π), where b_beta is the effective beta count per parent decay. Under secular equilibrium and an oversimplified common β efficiency, b_beta≈2; then A_parent ε≈2πK/S. The δ=21 mm point model gives formal A_parent ε≈0.90 MBq, and δ=16–25 mm gives 0.86–0.93 MBq in that same no-transport model. These are fit-scale products, not measured source activities: the models have severe residuals and ε is unknown. The conditional fit-scale standard error is only 0.002 MBq for the δ=21 mm scenario; it does not include the dominant detector/transport/geometry/model errors. No finite total uncertainty or valid comparison to a reference activity can be supplied. The former 6.99±0.23 MBq full-Geant4 scale is likewise conditional on unvalidated source and detector response; its small quoted uncertainty is not an activity measurement.

## Critical evaluation

- **Strongest conclusion:** The observed Cd² curve is not constant under Book2's nominal statistical/rail error model; count rates vary systematically with distance. This does not invalidate the geometrical inverse-square law.
- **Weakest assumption:** Treating nominal geometry, source stack and a 10 keV simulated silicon threshold as the calibrated real apparatus.
- **Largest unresolved systematic:** The coupled distance-zero/source-emitter geometry and actual angle- and energy-dependent detection response; existing data do not isolate one component.
- **Most useful next measurement:** Independently map the active source plane and silicon sensitive plane to rail marks and measure the source aperture, with a quantified uncertainty; repeat fixed-distance return/alignment tests and characterise rate linearity or pulse-injection recovery.
- **Practical limits:** All G4 physical inputs have not been individually scanned; no new high-statistics transport run was performed here, and no calibrated absolute efficiency, same-session background, or verified activity/reference date was found.
