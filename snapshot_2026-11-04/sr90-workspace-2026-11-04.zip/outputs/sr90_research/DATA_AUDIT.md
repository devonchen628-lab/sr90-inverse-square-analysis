# Data audit and provenance

`results/source_directory_manifest.json` lists 61 files in the original Radlab directory with hashes and, for CSV/XLSX, their tabular structure. Unrelated Tasks 6–13 and 18–20 were inventoried rather than silently merged into Task16. The analysis-relevant sources are detailed below.

## Inputs

| Item | Purpose and contents | Treatment |
|---|---|---|
| `inputs/task16.xlsx`, Sheet1 | Latest distance log: 141 individual count–time records, 32 distances (1–85 cm), 5–65 s per record, counts 702–91,714. Seventeen distances have three records; fifteen have six. | Primary raw source. The previous user instruction selects the final three in worksheet order at each distance, 96 records; `results/raw_observations.csv` preserves all 141 and marks the selection. |
| `inputs/Task16_older.csv` | Earlier 23-point distance scan (1–80 cm); an extra background row records 8 counts / 60 s. | Historical data and independent-ish background context; not pooled with the later scan because sessions/settings/independence are not established. |
| `inputs/Book2.xlsx`, Sheet1 | 32 summary rows and 10 lower historical rows. Main row formulas use N/t, Poisson √N and σd=0.5 mm directly. | Source of the requested uncertainty formula, not an independent scan. Of the 32 upper rows, 30 match first-three, last-three or all-six counts in the current raw sheet; 62.5 and 65 cm do not. At 75–85 cm Book2 uses six records, whereas this analysis retains the last three. G28 refers to B29 and G29 to B30; those referenced distance uncertainties currently equal 0.5 mm, so this creates no numerical difference here. |
| `inputs/deadtime.csv` | 500-bin interval histogram, 299,106 entries, 54 accumulated frames, 60.13 s elapsed. User confirmed displayed total range 31.25 μs and 500 bins. The last bin contains 258,695 entries. | Effective recovery fit is conditional on mapping bins to that range and treating the last bin as overflow. CSV itself does not establish overflow behaviour, electronics pulse width, or a hard dead time. |
| `inputs/Task14_125us.csv`, `Task14_250us.csv`, `Task14_500us.csv` | Earlier 500-bin interval exports; 5,659, 5,785 and 5,792 entries, respectively. | Preserved for context; filename is not proof of time-axis settings, so not pooled with the confirmed later histogram. |
| `inputs/Task19.xlsx` | Absorber measurement with background row: 5 counts / 60 s. | Different measurement context, a second background sensitivity point, not asserted to be the latest Task16 background. |
| `inputs/task16_angle.csv` | 7 angle/count records (−5° to 30°, each 20 s). | Auxiliary scan; the rotation pivot, actual distance and detailed geometry are not documented sufficiently to convert to the present alignment error. Its stored `unc_C` is inconsistent with √N/t: at 0°, N=3876 and t=20 s give 3.11 s⁻¹, while the file lists 0.696 s⁻¹. All seven entries appear smaller by √20. The angle data are not used in this report; the source was not modified. |
| `inputs/geant_air_batches/`, `inputs/geant_vacuum_batches/` | Existing eight air and twelve vacuum matched-geometry simulations at eight distances; same assumed G2 solids, 10 keV energy-deposition count. | Batch outputs reprocessed independently in `03_rebuild_transport.py`; identical earlier ratios and covariance reproduced. They are model outputs, not measured vacuum observations. |
| `inputs/geant_source/` | Archived Geant4 air and vacuum geometry/transport sources, generator, spectrum and run plans. | Audit trail of simulation assumptions; Python reproduction uses saved batches. Building/rerunning Geant4 requires Geant4 11.4.3, its data libraries, and the original build environment; portability of a fresh Geant4 build was not verified. |
| Imperial Radioactivity 2026 script, Tasks 14–17 and Appendix E | Defines interval, distance and activity tasks and two-page report context. | Read as instructions/reference; the 32.5 ns in Task 14 is a suggested short interval, not this detector's measured dead time. |

## Distance, source and detector

The rail reading is documented in conversation as the moving support position minus the fixed 50 mm base. Earlier four segment estimates have been revised. A 21 mm total active-plane offset (10+2+3+6 mm) is a scenario; the left term is uncertain and the actual emitting plane, aperture geometry and silicon reference were not independently calibrated. 16–25 mm is a scenario range, not a standard deviation or confidence interval. Potential offset from the rail zero is shared across distances.

S3590-09 photographs identify 10×10 mm sensitive area and nominal 0.3 mm depletion thickness. The source and detector were aligned visually. The simulated emitting diameter 22 mm, aperture 11 mm, material stack, transverse shifts and 10 keV hard threshold are assumptions. No traceable source activity certificate and reference date were identified; do not infer a verified activity from a difficult-to-read label.

## Original versus processed

`results/last_three.csv` contains derived means, not new measurements. `results/raw_observations.csv` retains each original count, time and source row. `01_extract_audit.py` independently rebuilds the previous last-three raw Cd² values and checks equality. The previous closest-three-by-minimum-range selection is not used. Six-record cases are not all confirmed return checks: only 12 have explicitly separated first/return triplets. Pooling first and last measurements is shown only as a sensitivity analysis, not silently substituted for the selected dataset.

The old 8/60 s background and newer 5/60 s background must not be silently conflated. Main count-shape comparisons use raw total counts without a background subtraction; background is discussed separately as a small sensitivity effect. Original workbooks, raw histogram and old scripts have not been modified.
