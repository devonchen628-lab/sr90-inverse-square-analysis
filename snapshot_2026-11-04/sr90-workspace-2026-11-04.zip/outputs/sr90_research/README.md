# Sr-90 inverse-square investigation

## Key deliverables

- `DATA_AUDIT.md`: source files, provenance, assumptions and unresolved inconsistencies.
- `RESULTS.md`: numerical results, conditional model statistics, sensitivity and critical evaluation.
- `figures/figure1_raw.png`, `figure2_geometry.png`, `figure3_models.png` (also SVG): the three requested figures. `figure4_transport.png` separately shows the eight matched Geant4 air/vacuum points.
- `tex/main.tex` and `tex/main.pdf`: two-page English report and source. The `tex/` directory is a complete LaTeX project.
- `results/raw_observations.csv`: all 141 individual raw counts and times with derived rates, uncertainties and selection indicator. `results/last_three.csv` is the primary 32-position analysis summary.
- `results/model_comparison.csv`, `pointwise_residuals.csv`, `analysis.json`: numerical fit and diagnostic results. `inventory.json` records source hashes and issues; `source_directory_manifest.json` inventories all 61 original Radlab files.

## Reproduce the Python analysis

The data snapshots in `inputs/` are copies. The original workbooks and historical files remain unchanged. The analysis was tested with Python 3.13.5 and the packages listed in `requirements.txt`.

From this directory:

```sh
python 01_extract_audit.py
python 02_timing.py
python 03_rebuild_transport.py
python 04_analyze.py
```

To rebuild the report after regenerating the figures, compile `tex/main.tex` twice with `pdflatex` from the `tex/` directory. `04_analyze.py` copies the report figures into `tex/images/` when that directory exists.

The first script reconstructs raw and selected observations directly from the copied XLSX and verifies the previously plotted 32 raw Cd² values. The timing script independently refits the confirmed 31.25 μs / 500-bin histogram, treating the final bin as overflow as an explicit, unverified assumption. The third script reconstructs the air/vacuum probabilities and cross-distance bootstrap covariance from the saved independent Geant4 batch CSVs and checks them against the prior output. The final script computes the geometry-only importance-sampled Sobol integration, rates, conditional fits, repeat diagnostics, sensitivities and all plots.

An optional `python 05_source_inventory.py --source-dir /path/to/Radlab` lists and hashes the full original source directory; it is not required to reproduce the analysis from the copied inputs.

The Python scripts do **not** launch new Geant4 transport runs. The archived Geant4 sources, spectra, original configuration files and independent batch outputs are included for auditing. Rebuilding Geant4 requires a suitable Geant4 11.4.3 installation, data libraries and the original Qt/build configuration; an independent fresh build from this package was not validated.

## Statistical scope

The primary data selection follows the earlier user instruction: the last three individual readings in worksheet order at each distance, without picking the three values that happen to agree best. All 141 readings remain available. Book2 uses σd=0.5 mm directly; it is treated as an independent per-reading standard error for conditional plots/fits. A shared zero offset is represented by explicit model scenarios instead of 32 independent nuisance shifts. Unknown geometry and detector systematics, excess repeat variability, and the uncertainty in the detector recovery model are not covered by the nominal p values. M4 is an exploratory hybrid evaluated at eight Geant4 distances only; it is not a full Geant4 likelihood and cannot be compared naively with 32-point fits. AIC/BIC and calibrated source activity are not asserted.

## Source and apparatus facts

Manual: Imperial College London, *Radioactivity* (2026), Tasks 14–17; the user's copy is in `1_Radioactivity/RadioactivityScript-2026v1.pdf`. Detector: Hamamatsu S3590-09 datasheet, KPIN1052E11 (2020). The actual source certificate, its reference date, effective detection efficiency, source-emitter geometry and measurement-day background were not independently verified.

The report's statistical tests and activity-efficiency scale are conditional on their stated idealisations. A small nominal fit error should not be interpreted as total experimental uncertainty.
