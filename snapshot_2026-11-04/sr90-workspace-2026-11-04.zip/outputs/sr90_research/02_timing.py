"""Fit recorded interval histogram, subject to the assumed final overflow bin."""
from pathlib import Path
import csv,json,re,numpy as np
from scipy.optimize import minimize
from scipy.stats import exponnorm,norm
P=Path(__file__).resolve().parent;O=P/'results'; txt=(P/'inputs/deadtime.csv').read_text(encoding='utf-8-sig');n=np.array([int(r['Count']) for r in csv.DictReader(txt.split('BinIndex,Count',1)[1].strip().splitlines(),fieldnames=['BinIndex','Count'])]);assert len(n)==500
bins=500; total_time_us=31.25 # explicitly confirmed by the user, not encoded in CSV
edges=np.arange(500)*total_time_us/bins;total=n.sum()
def probabilities(q,sharp=False):
 m,ls,ll=q;s=np.exp(ls);lam=np.exp(ll)
 if sharp:cdf=-np.expm1(-lam*np.maximum(edges-m,0))
 else:cdf=exponnorm.cdf(edges,K=1/(lam*s),loc=m,scale=s)
 return np.maximum(np.r_[np.diff(cdf),1-cdf[-1]],1e-300)
def nll(q):return -np.sum(n*np.log(probabilities(q)))
fit=minimize(nll,[1.95,np.log(.28),np.log(.005)],method='Nelder-Mead',options={'maxiter':5000,'xatol':1e-10,'fatol':1e-7});assert fit.success
m,ls,ll=fit.x;h=np.array([.0005,.001,.001]);H=np.zeros((3,3));base=nll(fit.x)
for i in range(3):
 ei=np.eye(3)[i]*h[i];H[i,i]=(nll(fit.x+ei)-2*base+nll(fit.x-ei))/h[i]**2
 for j in range(i):
  ej=np.eye(3)[j]*h[j];H[i,j]=H[j,i]=(nll(fit.x+ei+ej)-nll(fit.x+ei-ej)-nll(fit.x-ei+ej)+nll(fit.x-ei-ej))/(4*h[i]*h[j])
se=np.sqrt(np.diag(np.linalg.inv(H)));sigma=np.exp(ls);lam=np.exp(ll)
def sharpfun(q):return -np.sum(n*np.log(probabilities([q[0],np.log(.001),q[1]],True)))
sharp=minimize(sharpfun,[1.15,np.log(.005)],method='Nelder-Mead',options={'maxiter':3000})
def free_obj(q):
 mu,lS,lL,lA=q;sig=np.exp(lS);la=np.exp(lL);cdf=exponnorm.cdf(edges,K=1/(la*sig),loc=mu,scale=sig);e=np.maximum(np.exp(lA)*np.diff(cdf),1e-300);return np.sum(e-n[:-1]*np.log(e))
free=minimize(free_obj,[*fit.x,np.log(total)],method='Nelder-Mead',options={'maxiter':5000,'xatol':1e-9})
out=dict(total_entries=int(total),final_bin_count=int(n[-1]),bin_width_ns=1000*total_time_us/bins,overflow_fraction=float(n[-1]/total),soft_delay_mu_us=float(m),soft_delay_fit_se_us=float(se[0]),soft_width_us=float(sigma),rate_per_us=float(lam),sharp_delay_us=float(sharp.x[0]),soft_fit_finite_range_free_amplitude_mu_us=float(free.x[0]),warning='User confirmed total displayed range and bin count; CSV does not document time-axis convention or that final bin is overflow. Final bin is treated as overflow as a model assumption. Soft delay is not a separately calibrated hard detector dead time.')
(O/'timing_fit.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
