"""Rebuild raw observations from copies of the workbooks; originals are untouched."""
from pathlib import Path
from openpyxl import load_workbook
from collections import defaultdict,Counter
import csv,json,hashlib,math
P=Path(__file__).resolve().parent;I=P/'inputs';O=P/'results';O.mkdir(exist_ok=True)
def clean(x):
 if x is None or not str(x).strip():return None
 return float(str(x).strip())
ws=load_workbook(I/'task16.xlsx',read_only=True,data_only=True).active
records=[];d=None;gap=False;g=1
for rowno,row in enumerate(ws.iter_rows(min_row=2,values_only=True),2):
 dd=clean(row[0]);N=clean(row[2]);t=clean(row[4]);sd=clean(row[1])
 if dd is not None:
  if d is None or dd!=d:g=1
  d=dd;gap=False
 if N is None:
  if d is not None:gap=True
  continue
 if d is None or t is None or t<=0 or N<0 or N!=int(N):raise ValueError(f'Bad row {rowno}')
 if dd is None and gap:g+=1
 gap=False; records.append(dict(row=rowno,d_m=d,counts=int(N),time_s=t,group=g))
by=defaultdict(list)
for r in records:by[r['d_m']].append(r)
assert len(records)==141 and len(by)==32
for d,rr in by.items():
 assert len(rr) in (3,6)
 for j,x in enumerate(rr):
  x['selected_last_three']=int(j>=len(rr)-3)
  x['rate_cps']=x['counts']/x['time_s']
  x['rate_poisson_se']=math.sqrt(x['counts'])/x['time_s']
  x['raw_u']=x['rate_cps']*d*d
  x['book2_u_se']=x['raw_u']*math.sqrt(1/x['counts']+(2*.0005/d)**2) if x['counts'] else None
with (O/'raw_observations.csv').open('w',newline='') as f:
 wr=csv.DictWriter(f,fieldnames=list(records[0]));wr.writeheader();wr.writerows(records)
summary=[]
for d,rr in sorted(by.items()):
 chosen=rr[-3:];N=sum(x['counts'] for x in chosen);T=sum(x['time_s'] for x in chosen);C=N/T; Q=sum((x['counts']-C*x['time_s'])**2/(C*x['time_s']) for x in chosen)
 summary.append(dict(d_m=d,n_available=len(rr),selected_rows=';'.join(str(x['row']) for x in chosen),counts=N,time_s=T,rate_cps=C,poisson_rate_se=math.sqrt(N)/T,raw_u=C*d*d,book2_u_se=C*d*d*math.sqrt(1/N+(2*.0005/d)**2),within_Q=Q))
# Independent regression check of the earlier plotted raw points. This does not validate the underlying apparatus assumptions.
reference=json.loads((I/'previous_last_three_reference.json').read_text())['points']
assert len(reference)==len(summary)
for cur,old in zip(summary,reference):
 assert abs(cur['d_m']-old['d_m'])<1e-12 and abs(cur['raw_u']-old['u_raw'])<1e-10
with (O/'last_three.csv').open('w',newline='') as f:
 wr=csv.DictWriter(f,fieldnames=list(summary[0]));wr.writeheader();wr.writerows(summary)
# Book2 cached numeric values are compared to the current raw records, not silently merged.
b=load_workbook(I/'Book2.xlsx',data_only=True,read_only=True).active;mismatch=[];matches=0
for idx in range(2,34):
 dd=clean(b.cell(idx,1).value); n=clean(b.cell(idx,3).value);t=clean(b.cell(idx,5).value);raw=by.get(dd,[])
 # Exact first three / last three / all group totals, no deduplication of coincidence.
 possibilities=[]
 for label,seg in [('first3',raw[:3]),('last3',raw[-3:]),('all',raw)]:
  if seg and n is not None and t is not None and n==sum(x['counts'] for x in seg) and abs(t-sum(x['time_s'] for x in seg))<1e-9:possibilities.append(label)
 if possibilities:matches+=1
 else:mismatch.append(dict(row=idx,d_m=dd,cached_counts=n,cached_time=t,raw_record_counts=[x['counts'] for x in raw],raw_times=[x['time_s'] for x in raw]))
older_all=list(csv.DictReader((I/'Task16_older.csv').open(encoding='utf-8-sig'))); older=[x for x in older_all if str(x['d']).lower()!='background']; older_bg=[x for x in older_all if str(x['d']).lower()=='background']
task19=load_workbook(I/'Task19.xlsx',read_only=True,data_only=True).active;bg=[]
for i,row in enumerate(task19.iter_rows(values_only=True),1):
 if any('background' in str(v).lower() for v in row if v is not None):bg.append(dict(row=i,values=[str(v) if v is not None else None for v in row]))
def meta_csv(path):
 lines=path.read_text(encoding='utf-8-sig').splitlines();comments=[x for x in lines if x.startswith('#')];body=[x for x in lines if x and not x.startswith('#')];rr=list(csv.DictReader(body));return dict(file=path.name,metadata=comments,bins=len(rr),sum_counts=sum(int(x['Count']) for x in rr) if rr and 'Count' in rr[0] else None,last_bin=int(rr[-1]['Count']) if rr and 'Count' in rr[0] else None)
inv={'hashes':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in I.iterdir() if p.is_file()},'task16':{'n_observations':len(records),'n_distances':len(by),'distance_m':[min(by),max(by)],'records_per_distance':dict(Counter(len(z) for z in by.values())),'exposure_s':[min(x['time_s'] for x in records),max(x['time_s'] for x in records)],'counts_range':[min(x['counts'] for x in records),max(x['counts'] for x in records)],'explicit_two_groups':sum(len({x['group'] for x in z})==2 for z in by.values()),'main_selected':'last 3 by row, previous user instruction','selected_n':sum(x['selected_last_three'] for x in records)},'book2':{'rows_2_to_33':32,'matches_exact_first_last_or_all':matches,'mismatches':mismatch,'rows_39_to_48_are_separate_legacy':10,'uncertainty':'u*sqrt(1/N+(2*0.0005/d)^2); 0.5mm treated as standard uncertainty by worksheet','formula_reference_issue':'G28 references B29 and G29 references B30; both values currently equal 0.0005, so no numerical effect'},'older_Task16_csv':{'rows':len(older),'background_rows':older_bg,'distance_m':[min(float(x['d']) for x in older),max(float(x['d']) for x in older)],'unknown_independence':'do not merge with latest dataset without verifying shared acquisition/settings'},'background_Task19':bg,'histograms':[meta_csv(I/x) for x in ['deadtime.csv','Task14_125us.csv','Task14_250us.csv','Task14_500us.csv']]}
(O/'inventory.json').write_text(json.dumps(inv,indent=2,ensure_ascii=False)+'\n');print(json.dumps(inv,indent=2,ensure_ascii=False))
