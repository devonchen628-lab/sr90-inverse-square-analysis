from pathlib import Path
import json
import numpy as np,pandas as pd,matplotlib.pyplot as plt
from scipy.optimize import minimize_scalar, brentq, least_squares
from scipy.special import xlogy
from scipy.stats import chi2
P=Path(__file__).resolve().parent; DATA=P.parent/'sr90_research/results/last_three.csv'; data=pd.read_csv(DATA)
d=data.d_m.to_numpy();N=data.counts.to_numpy(dtype=float);t=data.time_s.to_numpy();u=data.raw_u.to_numpy();su=data.book2_u_se.to_numpy();delta=.015;sd=.0005
r=d+delta
# Profiled Poisson likelihood: K_hat(mu) is analytic for fixed mu.
def khat(mu):return N.sum()/np.sum(t*np.exp(-mu*r)/r**2)
def deviance(mu):
 K=khat(mu);lam=t*K*np.exp(-mu*r)/r**2
 return 2*np.sum(lam-N+xlogy(N,N/lam))
opt=minimize_scalar(deviance,bounds=(0,10),method='bounded',options={'xatol':1e-12}); assert opt.success
mu=float(opt.x); K=float(khat(mu));dev=float(deviance(mu));ndof=len(d)-2
# Profile intervals assume the fitted Poisson model and fixed distances are correct.
target=dev+1
low=0. if deviance(0)<target else brentq(lambda q:deviance(q)-target,0,mu)
hi=mu+1
while deviance(hi)<target:hi*=2
hi=brentq(lambda q:deviance(q)-target,mu,hi)
pred=K/r**2*np.exp(-mu*r);u_pred=pred*d*d;residual=100*(u/u_pred-1)
# Conditional error for the residual: d enters data and model jointly.
# u_obs/u_model = (N/t)/R_model(d), so shared d² cancels.
res_err=100*(u/u_pred)*np.sqrt(1/N+((2/r+mu)*sd)**2)
# Refit with each rail distance constrained by an independent Gaussian 0.5 mm
# standard uncertainty. These are nuisance positions, not new physical effects.
def constrained_residual(params):
 K0,mu0=params[:2];shift=params[2:];rr=d+delta+shift
 lam=t*K0/rr**2*np.exp(-mu0*rr)
 D=2*(lam-N+xlogy(N,N/lam))
 return np.r_[np.sign(N-lam)*np.sqrt(np.maximum(D,0)),shift/sd]
lo=np.r_[.01,0,np.full(len(d),-.005)]; hi=np.r_[100,5,np.full(len(d),.005)]
fit=least_squares(constrained_residual,np.r_[13.5,.2,np.zeros(len(d))],bounds=(lo,hi),x_scale='jac',max_nfev=1000,ftol=1e-11,xtol=1e-11,gtol=1e-11)
assert fit.success
count_only_K,count_only_mu,count_only_dev=K,mu,dev
K,mu=map(float,fit.x[:2]);shift=fit.x[2:];joint_objective=float(np.sum(fit.fun**2));penalty=float(np.sum((shift/sd)**2))
C=np.linalg.inv(fit.jac.T@fit.jac);formal_errors=np.sqrt(np.diag(C)[:2])
pred=K/r**2*np.exp(-mu*r);u_pred=pred*d*d;residual=100*(u/u_pred-1)
res_err=100*(u/u_pred)*np.sqrt(1/N+((2/r+mu)*sd)**2)
peak=float((np.sqrt(delta**2+8*delta/mu)-delta)/2) if mu>1e-8 else None
row=pd.DataFrame({'d_cm':d*100,'counts':N,'time_s':t,'raw_Rd2':u,'raw_Book2_unc':su,'predicted_count_rate':pred,'predicted_Rd2':u_pred,'fitted_position_shift_mm':shift*1000,'residual_pct':residual,'conditional_residual_unc_pct':res_err});row.to_csv(P/'fit_points.csv',index=False)
info={'K_m2_per_s':K,'mu_per_m':mu,'formal_K_std_model_conditional':float(formal_errors[0]),'formal_mu_std_model_conditional':float(formal_errors[1]),'fixed_offset_mm':15,'joint_penalized_deviance':joint_objective,'distance_penalty':penalty,'nominal_dof_approx':len(d)-2,'peak_distance_cm':peak*100 if peak is not None else None,'maximum_distance_shift_mm':float(np.max(np.abs(shift))*1000),'shifts_mm':(shift*1000).tolist(),'count_only_fit':{'K':count_only_K,'mu_per_m':count_only_mu,'deviance':count_only_dev},'observations':len(d),'selection':'last three measurements at each distance, aggregated by sum counts and time','fit':'Poisson likelihood with 32 independent Gaussian-constrained per-distance nuisance shifts sigma=0.5 mm, fixed common offset 15 mm, no background/deadtime/finite geometry; mu>=0','geometry_comparison':'point-source offset only, same K as fitted model, not independently normalized','warning':'mu phenomenological and model-dependent, not independently measured air attenuation. Gaussian distance shifts are not proof of real misplacement. Strong model-data mismatch; formal errors conditional and not reliable total uncertainties. Offset and model systematics excluded.'}
(P/'fit_summary.json').write_text(json.dumps(info,indent=2))
xx=np.linspace(.005,.85,1000);rr=xx+delta;geom=K*(xx/rr)**2;full=geom*np.exp(-mu*rr)
plt.rcParams.update({'font.size':10,'font.family':'DejaVu Sans','axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42})
fig,(ax,bx)=plt.subplots(2,1,figsize=(7.8,7.1),sharex=True,gridspec_kw={'height_ratios':[2.1,1],'hspace':.08},layout='constrained')
ax.errorbar(d*100,u,xerr=sd*100,yerr=su,fmt='o',ms=4.1,capsize=2.4,elinewidth=.8,color='#20282f',label='Measured $Rd^2$ (Book2 errors)')
ax.plot(xx*100,geom,'--',color='#858e94',lw=1.6,label='Offset only (same K)');ax.plot(xx*100,full,color='#135c86',lw=2.2,label='Offset + effective exponential fit')
ax.set(ylabel=r'$Rd^2$ (m$^2$ s$^{-1}$)',title='Offset + effective attenuation: data and residuals',ylim=(0,None));ax.legend(frameon=False,fontsize=8.8,loc='lower right');
bx.axhline(0,color='#666666',lw=.9);bx.errorbar(d*100,residual,xerr=sd*100,yerr=res_err,fmt='o',ms=4,capsize=2.3,elinewidth=.8,color='#135c86');bx.set(xlabel='Rail distance $d$ (cm)',ylabel='(Data − model) / model (%)',xlim=(0,87))
for axis in (ax,bx):axis.grid(alpha=.15)
fig.savefig(P/'forward_model_residuals.png',dpi=300,bbox_inches='tight');fig.savefig(P/'forward_model_residuals.pdf',bbox_inches='tight');print(json.dumps(info,indent=2));print(row[['d_cm','residual_pct','conditional_residual_unc_pct']].iloc[[0,1,2,5,12,20,31]].to_string(index=False))
