from pathlib import Path
import csv,numpy as np,openpyxl,matplotlib.pyplot as plt
from scipy.special import roots_legendre
out=Path(__file__).resolve().parent;root=out.parent/'sr90_research/results';L=.01;rs=.005;nominal=.015;offsets=np.array([15.05,16,17.05,18,19.05,21,23])*1e-3
with (root/'raw_observations.csv').open(newline='') as f:rows=list(csv.DictReader(f))
ref=[z for z in rows if .20-1e-10<=float(z['d_m'])<=.30+1e-10]
z,w=roots_legendre(24);q=(z+1)/2;w=w/2;phi=2*np.pi*(np.arange(48)+.5)/48
xs=rs*np.sqrt(q)[:,None]*np.cos(phi)[None,:];ys=rs*np.sqrt(q)[:,None]*np.sin(phi)[None,:]
x1=-L/2-xs;x2=L/2-xs;y1=-L/2-ys;y2=L/2-ys
def omega(r):
 def f(a,b,v):return np.arctan2(a*b,v*np.sqrt(v*v+a*a+b*b))
 return np.array([np.sum(w[:,None]*(f(x2,y2,v)-f(x1,y2,v)-f(x2,y1,v)+f(x1,y1,v)))/48 for v in np.atleast_1d(r)])
refd=np.array([float(z['d_m']) for z in ref]);reft=np.array([float(z['time_s']) for z in ref]);refn=np.array([float(z['counts']) for z in ref]);K=refn.sum()/np.sum(reft*omega(refd+nominal)/L**2)
def model(d,offset):return K*omega(np.asarray(d)+offset)/L**2*np.asarray(d)**2
s=openpyxl.load_workbook(root/'task16_Book2_calculation.xlsx',data_only=True)['Book2 calculation'];a=np.array([[s.cell(i,j).value for j in (1,2,6,7)] for i in range(2,34)],float);a=a[(a[:,0]>=.01)&(a[:,0]<=.200001)]
dgrid=np.linspace(.01,.2,400);curve=np.array([model(dgrid,o) for o in offsets]);d=a[:,0];mu=np.array([model(d,o) for o in offsets]);g0=K*(d/(d+nominal))**2
plt.rcParams.update({'font.size':11,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42})
fig,ax=plt.subplots(figsize=(7.4,4.8),layout='constrained');xx=dgrid*100
ax.plot(xx,model(dgrid,nominal),color='#00816b',lw=2.2,label='Nominal G2: offset 15 mm')
ax.errorbar(a[:,0]*100,a[:,2],xerr=a[:,1]*100,yerr=a[:,3],fmt='o',ms=5,capsize=2.8,elinewidth=1,color='#204f70',label='Raw data: last three measurements')
ax.set(xlabel='Rail distance $d$ (cm)',ylabel=r'$Rd^2$ (m$^2$ s$^{-1}$)',title='Near-field geometry model vs experiment',xlim=(0,20.6),ylim=(0,None))
ax.grid(alpha=.18);ax.legend(frameon=False,loc='lower right',fontsize=9)
fig.savefig(out/'figure2_near_field.png',dpi=300,bbox_inches='tight');fig.savefig(out/'figure2_near_field.pdf',bbox_inches='tight')
print('K',K)
