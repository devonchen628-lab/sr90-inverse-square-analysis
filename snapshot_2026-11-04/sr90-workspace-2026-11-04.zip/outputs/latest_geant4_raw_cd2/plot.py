from pathlib import Path
import json,numpy as np,pandas as pd,matplotlib.pyplot as plt
P=Path(__file__).resolve().parent;root=P.parent;D=pd.read_csv(root/'sr90_research/results/last_three.csv');d=D.d_m.to_numpy();N=D.counts.to_numpy(float);t=D.time_s.to_numpy();u=D.raw_u.to_numpy();eu=D.book2_u_se.to_numpy();near=root/'main_figure_transport15';far=root/'far_field_15mm_aligned';dn=d[d<.3-1e-9];df=d[d>=.3-1e-9]
def read(folder,dist):
 fs=sorted((folder/'air').glob('batch_*.csv'));assert len(fs)==8
 result=[]
 for f in fs:
  x=pd.read_csv(f);x=x[x.threshold_keV==10];result.append([x.loc[np.isclose(x.distance_m,z),'probability'].iloc[0] for z in dist])
 return np.array(result)
a=read(near,dn);b=read(far,df);p=np.r_[a.mean(0),b.mean(0)];ref=(d>=.2-1e-9)&(d<=.3+1e-9);scale=N[ref].sum()/np.sum(t[ref]*p[ref]);sim=scale*p*d*d
# Bootstrap independent whole near and far simulation batches, including a
# Poisson resample of reference measurements; fit a shared scale on each draw.
B=10000;rng=np.random.default_rng(20261103);ab=a[rng.integers(0,8,(B,8))].mean(1);bb=b[rng.integers(0,8,(B,8))].mean(1);pb=np.c_[ab,bb];nb=rng.poisson(N[ref],size=(B,ref.sum()));sc=nb.sum(1)/np.sum(t[ref]*pb[:,ref],axis=1);curves=sc[:,None]*pb*d*d;es=curves.std(0,ddof=1)
out=pd.DataFrame({'d_cm':d*100,'experimental_Cd2':u,'experimental_Book2_unc':eu,'geant4_air_probability':p,'geant4_scaled_Cd2':sim,'geant4_MC_and_scale_unc_conditional':es,'reference_20_30cm':ref});out.to_csv(P/'plot_data.csv',index=False)
np.savez_compressed(P/'simulation_covariance.npz',d_cm=d*100,covariance_conditional=np.cov(curves,rowvar=False))
info={'geometry':'15 mm offset, zero transverse displacement','medium':'air','sensitive_threshold_keV':10,'scaling':'one scale estimated with Poisson likelihood from latest-three raw counts at 20–30 cm','scale_per_second':scale,'warning':'scale absorbs effective source activity and detector response; not independent activity. uncertainty combines conditional Geant4 batch MC and reference count statistics, excludes geometry/model/position systematics; no deadtime/background in simulation.'};(P/'plot_info.json').write_text(json.dumps(info,indent=2))
plt.rcParams.update({'font.size':10.5,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42});fig,ax=plt.subplots(figsize=(8.5,5.4),layout='constrained')
ax.errorbar(d*100,u,xerr=.05,yerr=eu,fmt='o',ms=4.3,capsize=2,elinewidth=.8,color='#1c4e70',label='Raw measurements (Book2 uncertainty)',zorder=4)
ax.errorbar(d*100,sim,yerr=es,fmt='s',mfc='white',ms=3.8,capsize=1.7,elinewidth=.7,color='#d26b2a',alpha=.9,label='Geant4 air (MC + scaling uncertainty)',zorder=3)
ax.plot(d*100,sim,color='#d26b2a',lw=1.1,alpha=.7)
ax.axvspan(20,30,color='#e3e7ea',alpha=.55,zorder=0,label='20–30 cm scaling region')
ax.set(xlabel='Rail distance $d$ (cm)',ylabel=r'$Cd^2$ (m$^2$ s$^{-1}$)',title='Raw measurements and latest Geant4 air simulation',xlim=(0,88),ylim=(0,None));ax.grid(alpha=.16);ax.legend(frameon=False,fontsize=8.8,loc='lower right')
fig.savefig(P/'raw_vs_geant4.png',dpi=300,bbox_inches='tight');fig.savefig(P/'raw_vs_geant4.pdf',bbox_inches='tight')
print(json.dumps(info,indent=2));print(out.iloc[[0,1,2,8,12,20,31]].to_string(index=False))
