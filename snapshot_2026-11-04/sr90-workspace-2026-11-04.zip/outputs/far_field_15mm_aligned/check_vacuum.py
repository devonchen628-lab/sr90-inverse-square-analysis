from pathlib import Path
import os,subprocess,csv,json
p=Path(__file__).resolve().parent;runtime=Path('/Users/chenqiyue/Documents/Codex/2026-10-12/https-chatgpt-com-share-6acd35f5-5168/.runtime/geant4');env=os.environ.copy()
for k,n in [('G4LEDATA','EMLOW'),('G4LEVELGAMMADATA','PhotonEvaporation'),('G4RADIOACTIVEDATA','RadioactiveDecay'),('G4ENSDFSTATEDATA','ENSDFSTATE')]:env[k]=str(next((runtime/'share/Geant4/data').glob(n+'*')))
for filt in [1,0]:
 f=p/f'validation_prefilter_{filt}.csv';cmd=[str(p/'build/far15_vac'),str(p/'src/spectra_unique.csv'),str(f),'0.3','400000','1961220000',str(filt)]
 with f.with_suffix('.log').open('w') as log:subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
 print('Validation prefilter',filt,'complete',flush=True)
