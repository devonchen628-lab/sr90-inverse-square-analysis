from pathlib import Path
import json,numpy as np,pandas as pd,matplotlib.pyplot as plt
out=Path(__file__).resolve().parent;root=out.parent/'sr90_research'; inp=out;data=pd.read_csv(root/'results/last_three.csv');data=data[(data.d_m>=.3-1e-10)&(data.d_m<=.85+1e-10)].copy().reset_index(drop=True)
d=data.d_m.to_numpy();u=data.raw_u.to_numpy();su=data.book2_u_se.to_numpy();assert np.isclose(d[0],.3) and np.isclose(d[-1],.85)
q=u/u[0];cov=np.diag(su**2)/u[0]**2+np.outer(u,u)*su[0]**2/u[0]**4;cov[0,:]=0;cov[:,0]=0;qse=np.sqrt(np.diag(cov))
knots=d.copy();
def read(folder,n):
 files=sorted((inp/folder).glob('batch_*.csv'));assert len(files)==n
 a=[]
 for f in files:
  x=pd.read_csv(f);x=x[x.threshold_keV==10]
  a.append([x.loc[np.isclose(x.distance_m,v),'probability'].iloc[0] for v in knots])
 return np.array(a)
a=read('air',8);v=read('vacuum',12); rng=np.random.default_rng(251102);n=50000
ab=a[rng.integers(0,len(a),(n,len(a)))].mean(axis=1);vb=v[rng.integers(0,len(v),(n,len(v)))].mean(axis=1)
def norm(p):return p/p[...,0,None]*(knots/knots[0])**2
am=a.mean(axis=0);vm=v.mean(axis=0);aq=norm(am);vq=norm(vm);aqb=norm(ab);vqb=norm(vb);aqse=aqb.std(axis=0,ddof=1);vqse=vqb.std(axis=0,ddof=1)
T=am/vm;Tr=T[-1]/T[0];Trb=(ab[:,-1]/vb[:,-1])/(ab[:,0]/vb[:,0]);diff=q[-1]-aq[-1];diffse=np.sqrt(qse[-1]**2+aqse[-1]**2)
results={'Q_exp':q[-1],'Q_exp_se_conditional':qse[-1],'Q_air':aq[-1],'Q_air_mc_se':aqse[-1],'Q_vacuum':vq[-1],'Q_vacuum_mc_se':vqse[-1],'T30':T[0],'T85':T[-1],'T85_over_T30':Tr,'T_ratio_mc_se':Trb.std(ddof=1),'Q_exp_minus_air':diff,'difference_stat_only_se':diffse,'stat_only_z':diff/diffse,'MC_bootstrap_replicates':n,'simulation_geometry':'offset 15 mm, x 0 mm, y 0 mm; source and detector recess 6 and 3 mm; assumed emitter diameter 22 mm and aperture diameter 11 mm; 10 keV threshold','experimental_selection':'last 3 measurements per distance; raw rates; Book2 sigma d 0.5 mm treated as independent standard distance uncertainty; no background/deadtime correction','caveat':'MC errors only; unknown geometry, activity spectrum, enclosure, electronics and between-run effects excluded; assumed source structures, actual materials and threshold not independently established'}
(out/'summary.json').write_text(json.dumps(results,indent=2));pd.DataFrame({'d_cm':d*100,'raw_u':u,'book2_unc':su,'relative_u':q,'relative_u_se':qse}).to_csv(out/'experimental_relative.csv',index=False)
pd.DataFrame({'d_cm':knots*100,'air_probability':am,'air_relative':aq,'air_relative_mc_se':aqse,'vacuum_probability':vm,'vacuum_relative':vq,'vacuum_relative_mc_se':vqse}).to_csv(out/'simulation_relative.csv',index=False)
np.savez_compressed(out/'normalized_covariances.npz',experimental=cov,air_mc=np.cov(aqb,rowvar=False),vacuum_mc=np.cov(vqb,rowvar=False),experiment_d_cm=d*100,simulation_d_cm=knots*100)
plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42})
fig,ax=plt.subplots(figsize=(8,5),layout='constrained')
ax.errorbar(d*100,q,xerr=.05,yerr=qse,fmt='o',color='#225779',ms=4.2,capsize=2.5,label='Experiment (last three; Book2 error)',zorder=4)
# Lines connect the simulated distances; shaded bands show MC standard errors.
ax.plot(knots*100,aq,'s-',ms=3,color='#d45a28',lw=1.3,label='Geant4 air')
ax.fill_between(knots*100,aq-aqse,aq+aqse,color='#d45a28',alpha=.18,label='Air MC uncertainty (1σ)')
ax.plot(knots*100,vq,'D--',ms=3,color='#008574',lw=1.3,label='Geant4 vacuum')
ax.fill_between(knots*100,vq-vqse,vq+vqse,color='#008574',alpha=.15,label='Vacuum MC uncertainty (1σ)')
ax.axhline(1,color='#929da3',lw=.8);ax.axvline(30,color='#b7bfc3',lw=.8,ls=':');ax.set(xlabel='Rail distance $d$ (cm)',ylabel=r'Normalized $Rd^2$ (relative to 30 cm)',title='Far-field transport: 15 mm offset, aligned geometry',xlim=(27,88),ylim=(max(0,min(float(np.min(aq-aqse)),float(np.min(q-qse)))-.1),max(1.4,float(np.max(vq+vqse))+.1)));ax.grid(alpha=.15);ax.legend(frameon=False,fontsize=9,loc='lower left')
fig.savefig(out/'far_field_15mm_aligned.png',dpi=300,bbox_inches='tight');fig.savefig(out/'far_field_15mm_aligned.pdf',bbox_inches='tight');print(json.dumps(results,indent=2))
