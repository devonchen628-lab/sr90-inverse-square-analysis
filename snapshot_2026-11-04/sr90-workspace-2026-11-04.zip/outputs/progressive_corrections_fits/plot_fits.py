from pathlib import Path
import numpy as np,pandas as pd,matplotlib.pyplot as plt
from scipy.interpolate import UnivariateSpline
p=Path(__file__).resolve().parent;data=pd.read_csv(p.parent/'progressive_corrections/progressive_correction_values.csv');x=data.d_cm.to_numpy()
sets=[('1. Raw $Rd^2$','raw_Rd2','raw_se','#557b96','o'),('2. Distance correction','distance_corrected','distance_corrected_se','#d58a23','s'),('3. + geometry and dead time','geometry_deadtime_corrected','geometry_deadtime_se','#16846e','^'),('4. + relative air transport','air_corrected','air_corrected_se','#b44c70','D')]
plt.rcParams.update({'font.size':10,'font.family':'DejaVu Sans','axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42});fig,ax=plt.subplots(figsize=(9.5,5.8),layout='constrained');out=[]
for label,ycol,ecol,col,mark in sets:
 y=data[ycol].to_numpy();err=data[ecol].to_numpy();mask=np.isfinite(y)&np.isfinite(err)&(err>0);xx=x[mask];yy=y[mask];ee=err[mask]
 spl=UnivariateSpline(xx,yy,w=1/ee,k=3,s=len(xx));grid=np.linspace(xx.min(),xx.max(),600);fit=spl(grid)
 ax.errorbar(xx,yy,yerr=ee,fmt=mark,ms=3.6,capsize=1.5,elinewidth=.65,color=col,alpha=.48,label='_nolegend_')
 ax.plot(grid,fit,color=col,lw=1.9,label=label)
 out.extend([dict(series=label,d_cm=a,fit=b) for a,b in zip(grid,fit)])
ax.set(xlabel='Rail distance $d$ (cm)',ylabel=r'Corrected rate × distance² (m$^2$ s$^{-1}$)',title=r'Stepwise corrections and fitted trends',xlim=(0,88),ylim=(0,None));ax.grid(alpha=.16);ax.legend(frameon=False,fontsize=9,loc='lower right')
fig.savefig(p/'progressive_fits.png',dpi=300,bbox_inches='tight');fig.savefig(p/'progressive_fits.pdf',bbox_inches='tight');pd.DataFrame(out).to_csv(p/'fitted_curves.csv',index=False)
