from pathlib import Path
import numpy as np,pandas as pd,matplotlib.pyplot as plt
from scipy.special import roots_legendre
O=Path(__file__).resolve().parent; root=O.parent;raw=pd.read_csv(root/'sr90_research/results/last_three.csv');obs=pd.read_csv(root/'sr90_research/results/raw_observations.csv');ref=obs[(obs.d_m>=.2-1e-10)&(obs.d_m<=.3+1e-10)]
L=.01;rs=.005;delta=.015;tau=2e-6
z,w=roots_legendre(24);q=(z+1)/2;w=w/2;phi=2*np.pi*(np.arange(48)+.5)/48;x=rs*np.sqrt(q)[:,None]*np.cos(phi);y=rs*np.sqrt(q)[:,None]*np.sin(phi);x1=-L/2-x;x2=L/2-x;y1=-L/2-y;y2=L/2-y
def omega(r):
 def f(a,b,r):return np.arctan2(a*b,r*np.sqrt(r*r+a*a+b*b))
 return np.array([np.sum(w[:,None]*(f(x2,y2,r)-f(x1,y2,r)-f(x2,y1,r)+f(x1,y1,r)))/48 for r in np.atleast_1d(r)])
K=ref.counts.sum()/np.sum(ref.time_s.to_numpy()*omega(ref.d_m.to_numpy()+delta)/L**2)
d=np.linspace(.01,.2,450);g0=K*(d/(d+delta))**2;rate=K*omega(d+delta)/L**2;g2=rate*d**2;dead=rate/(1+tau*rate)*d**2
exp=raw[(raw.d_m>=.01)&(raw.d_m<=.2)].copy();fexp=pd.read_csv(root/'far_field_15mm_aligned/experimental_relative.csv');fsim=pd.read_csv(root/'far_field_15mm_aligned/simulation_relative.csv');assert np.allclose(fexp.d_cm,fsim.d_cm)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42})
fig,(ax,bx)=plt.subplots(1,2,figsize=(11.2,4.2),layout='constrained')
ax.errorbar(exp.d_m*100,exp.raw_u,xerr=.05,yerr=exp.book2_u_se,fmt='o',ms=4,capsize=2,color='#233c50',label='Measurement (last three)',zorder=5)
ax.axhline(K,color='#777777',ls='-.',lw=1.3,label='Ideal constant K')
ax.plot(d*100,g0,color='#0072b2',ls=':',lw=2,label='Offset only (G0)');ax.plot(d*100,g2,color='#009e73',ls='--',lw=2,label='+ finite geometry (G2)');ax.plot(d*100,dead,color='#d55e00',lw=2,label=r'+ dead time ($\tau=2\,\mu$s)')
ax.set(xlabel='Rail distance d (cm)',ylabel=r'$Rd^2$ (m$^2$ s$^{-1}$)',title='(a) Near field: progressive effects',xlim=(0,20.5),ylim=(0,None));ax.legend(frameon=False,fontsize=8,loc='lower right')
x=fsim.d_cm;axexp=fexp
bx.errorbar(axexp.d_cm,axexp.relative_u,xerr=.05,yerr=axexp.relative_u_se,fmt='o',ms=4,capsize=2,color='#233c50',label='Measurement / 30 cm',zorder=5)
for label,col,ls,key in [('Vacuum: geometry + source','#009e73','--','vacuum'),('Air: + electron transport','#d55e00','-','air')]:
 y=fsim[key+'_relative'];err=fsim[key+'_relative_mc_se'];bx.plot(x,y,ls,color=col,lw=1.7,label=label);bx.fill_between(x,(y-err).to_numpy(),(y+err).to_numpy(),color=col,alpha=.13)
bx.axhline(1,color='#969c9e',lw=.8);bx.set(xlabel='Rail distance d (cm)',ylabel=r'$Rd^2$ relative to 30 cm',title='(b) Far field: Geant4 comparison',xlim=(29,87),ylim=(.54,1.38));bx.legend(frameon=False,fontsize=8,loc='lower left')
for a in [ax,bx]:a.grid(alpha=.15)
fig.savefig(O/'progressive_effects.png',dpi=300,bbox_inches='tight');fig.savefig(O/'progressive_effects.pdf',bbox_inches='tight')
print('K=',K,'near1cm G0,G2,dead=',g0[0],g2[0],dead[0],'dead relative percent=',100*(dead[0]/g2[0]-1))
