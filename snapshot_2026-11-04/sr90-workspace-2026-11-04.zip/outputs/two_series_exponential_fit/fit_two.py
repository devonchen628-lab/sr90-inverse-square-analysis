from pathlib import Path
import json,numpy as np,pandas as pd,matplotlib.pyplot as plt
from scipy.optimize import least_squares, minimize_scalar
from scipy.special import xlogy
O=Path(__file__).resolve().parent;root=O.parent;D=pd.read_csv(root/'sr90_research/results/last_three.csv');d=D.d_m.to_numpy();N=D.counts.to_numpy(float);t=D.time_s.to_numpy();u=D.raw_u.to_numpy();uerr=D.book2_u_se.to_numpy();delta=.015;sd=.0005
near=root/'main_figure_transport15';far=root/'far_field_15mm_aligned';near_d=d[d<.3-1e-9];far_d=d[d>=.3-1e-9]
def read(path,dist):
 files=sorted((path/'air').glob('batch_*.csv'));assert len(files)==8
 mat=[]
 for f in files:
  x=pd.read_csv(f);x=x[x.threshold_keV==10];mat.append([x.loc[np.isclose(x.distance_m,v),'probability'].iloc[0] for v in dist])
 return np.array(mat)
a=read(near,near_d);b=read(far,far_d);p=np.r_[a.mean(axis=0),b.mean(axis=0)];pse=np.r_[a.std(0,ddof=1)/np.sqrt(8),b.std(0,ddof=1)/np.sqrt(8)];assert np.all(p>0)&np.all(pse>0)
# Direct Poisson on sums, with one Gaussian constrained nuisance per distinct distance.
def exres(par):
 K,mu=par[:2];shift=par[2:];r=d+delta+shift;lam=t*K/r**2*np.exp(-mu*r);dev=2*(lam-N+xlogy(N,N/lam));return np.r_[np.sign(N-lam)*np.sqrt(np.maximum(dev,0)),shift/sd]
lo=np.r_[.001,0,np.full(len(d),-.005)];hi=np.r_[100,5,np.full(len(d),.005)];opt=least_squares(exres,np.r_[13.5,.2,np.zeros(len(d))],bounds=(lo,hi),x_scale='jac',max_nfev=1000,ftol=1e-11,xtol=1e-11,gtol=1e-11);assert opt.success
Ke,mue=opt.x[:2];cov=np.linalg.inv(opt.jac.T@opt.jac);formal=np.sqrt(np.diag(cov)[:2]);
# Fit unnormalised Geant4 probabilities. Diagonal WLS gives a reproducible
# descriptive fit; batch bootstrap captures between-distance dependence in fitted parameters.
y=p*d*d;sy=pse*d*d;weights=1/sy**2
def simfit(y,weights):
 def get(mu):
  g=(d/(d+delta))**2*np.exp(-mu*(d+delta)); k=np.sum(weights*g*y)/np.sum(weights*g*g);return np.sum(weights*(y-k*g)**2)
 o=minimize_scalar(get,bounds=(0,5),method='bounded',options={'xatol':1e-10});m=float(o.x);g=(d/(d+delta))**2*np.exp(-m*(d+delta));return np.sum(weights*g*y)/np.sum(weights*g*g),m,float(o.fun)
Ks,mus,simobj=simfit(y,weights)
ref=(d>=.2-1e-9)&(d<=.3+1e-9);scale=N[ref].sum()/np.sum(t[ref]*p[ref]);Kscaled=Ks*scale
# Bootstrap complete independent runs in each distance block. No pretending
# that replayed events or neighbouring distance points are independent.
rng=np.random.default_rng(20261102);draw=1200;bs=[]
for _ in range(draw):
 pp=np.r_[a[rng.integers(0,8,8)].mean(0),b[rng.integers(0,8,8)].mean(0)];k,m,_=simfit(pp*d*d,weights);sc=N[ref].sum()/np.sum(t[ref]*pp[ref]);bs.append((k,m,k*sc))
bs=np.array(bs)
def model(ds,K,mu):return K*(ds/(ds+delta))**2*np.exp(-mu*(ds+delta))
epred=model(d,Ke,mue);spred=model(d,Kscaled,mus);eres=100*(u/epred-1);sres=100*(scale*y/spred-1)
esig=100*(u/epred)*np.sqrt(1/N+((2/(d+delta)+mue)*sd)**2);ssig=100*scale*sy/spred
xx=np.linspace(.0085,.85,1000)
plt.rcParams.update({'font.size':10,'font.family':'DejaVu Sans','axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42})
fig,(ax,bx)=plt.subplots(2,1,figsize=(8.4,7.3),sharex=True,gridspec_kw={'height_ratios':[2,1]},layout='constrained')
ax.errorbar(d*100,u,xerr=sd*100,yerr=uerr,fmt='o',ms=4,capsize=2,elinewidth=.7,color='#26343e',label='Experiment (Book2 error)')
ax.errorbar(d*100,scale*y,yerr=scale*sy,fmt='s',mfc='none',ms=3.8,capsize=1.5,elinewidth=.6,color='#d07529',alpha=.75,label='Geant4 air (scaled; MC error)')
ax.plot(xx*100,model(xx,Ke,mue),color='#145b86',lw=2,label='Experiment: offset + exponential fit')
ax.plot(xx*100,model(xx,Kscaled,mus),color='#d07529',ls='--',lw=2,label='Geant4 air: same functional fit')
ax.set(ylabel=r'$Rd^2$ (m$^2$ s$^{-1}$)',title='Experimental and Geant4 fits with fixed 15 mm offset',ylim=(0,None));ax.legend(frameon=False,fontsize=8.2,loc='lower right')
bx.errorbar(d*100,eres,yerr=esig,fmt='o',color='#145b86',ms=3.5,capsize=1.8,elinewidth=.7,label='Experiment (conditional)')
bx.errorbar(d*100,sres,yerr=ssig,fmt='s',mfc='none',color='#d07529',ms=3.4,capsize=1.8,elinewidth=.7,label='Geant4 (MC only)')
bx.axhline(0,color='#666',lw=.8);bx.set(xlabel='Rail distance d (cm)',ylabel='(Data − own fit) / fit (%)',xlim=(0,87));bx.legend(frameon=False,fontsize=8,loc='lower right')
for ax in (ax,bx):ax.grid(alpha=.15)
fig.savefig(O/'experiment_geant4_exponential_fit.png',dpi=300,bbox_inches='tight');fig.savefig(O/'experiment_geant4_exponential_fit.pdf',bbox_inches='tight')
result={'assumed_two_series':'latest task16 experimental measurements vs matched 15mm aligned Geant4 AIR probabilities','delta_m':delta,'experiment':{'K_m2_s':Ke,'mu_per_m':mue,'formal_conditional_se_K_mu':formal.tolist(),'objective_poisson_plus_gaussian_distance':float(sum(opt.fun**2)),'largest_profiled_distance_shift_mm':float(np.max(np.abs(opt.x[2:]))*1000),'warning':'formal errors assume specified model, fixed common offset, and 0.5mm independent Gaussian distance errors; substantial mismatch, thus not final uncertainties'},'geant4':{'K_per_emitted_beta_m2':Ks,'mu_per_m':mus,'mu_bootstrap_se_fixed_weights':float(bs[:,1].std(ddof=1)),'mu_bootstrap_16_84':np.quantile(bs[:,1],[.16,.84]).tolist(),'scaled_K_m2_s':Kscaled,'scale_per_s_fitted_to_20_30cm':scale,'diag_weighted_objective':simobj,'nominal_df':len(d)-2,'bootstrap_replicates':draw,'warning':'WLS central fit ignores cross-distance covariance; whole-batch bootstrap for mu; simulated series scaled using experiment and is not independent absolute-rate prediction'},'caveats':'Source geometry uncalibrated. The exponential is phenomenological; both models omit explicit dead time and other response corrections; mu values are effective shape parameters. Geant4 point error bars are conditional MC only. Residual bars omit parameter uncertainty and model systematics.'}
(O/'fit_summary.json').write_text(json.dumps(result,indent=2));pd.DataFrame({'d_cm':d*100,'N':N,'time_s':t,'exp_Rd2':u,'exp_Rd2_unc':uerr,'exp_model':epred,'exp_residual_pct':eres,'geant4_probability':p,'geant4_probability_MC_se':pse,'geant4_scaled_Rd2':scale*y,'geant4_scaled_MC_se':scale*sy,'geant4_model_scaled':spred,'geant4_residual_pct':sres}).to_csv(O/'fit_points.csv',index=False);print(json.dumps(result,indent=2))
