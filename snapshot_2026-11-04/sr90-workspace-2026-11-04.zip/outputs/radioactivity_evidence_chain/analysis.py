from pathlib import Path
import json,numpy as np,pandas as pd,matplotlib.pyplot as plt
from scipy.special import roots_legendre
P=Path(__file__).resolve().parent;ROOT=P.parent;D=pd.read_csv(ROOT/'sr90_research/results/last_three.csv');near=ROOT/'main_figure_transport15';far=ROOT/'far_field_15mm_aligned';d=D.d_m.to_numpy();N=D.counts.to_numpy(float);time=D.time_s.to_numpy();R=N/time;sd=.0005;delta=.015;tau=2e-6;L=.01;rs=.011
nd=d[d<.3-1e-9];fd=d[d>=.3-1e-9]
def read(folder,medium,n,ds):
 fs=sorted((folder/medium).glob('batch_*.csv'));assert len(fs)==n,(folder,medium,len(fs));out=[]
 for f in fs:
  x=pd.read_csv(f);x=x[x.threshold_keV==10];out.append([x.loc[np.isclose(x.distance_m,v),'probability'].iloc[0] for v in ds])
 return np.array(out)
an=read(near,'air',8,nd);vn=read(near,'vacuum',12,nd);af=read(far,'air',8,fd);vf=read(far,'vacuum',12,fd)
a=np.r_[an.mean(0),af.mean(0)];v=np.r_[vn.mean(0),vf.mean(0)];T=a/v
z,w=roots_legendre(32);w=w/2;phi=2*np.pi*(np.arange(64)+.5)/64;x=rs*np.sqrt((z+1)/2)[:,None]*np.cos(phi);y=rs*np.sqrt((z+1)/2)[:,None]*np.sin(phi);x1=-L/2-x;x2=L/2-x;y1=-L/2-y;y2=L/2-y
def Omega(ds):
 def f(a,b,r):return np.arctan2(a*b,r*np.sqrt(r*r+a*a+b*b))
 return np.array([np.sum(w[:,None]*(f(x2,y2,r)-f(x1,y2,r)-f(x2,y1,r)+f(x1,y1,r)))/64 for r in np.atleast_1d(ds)+delta])
def h(ds):return Omega(ds)/L**2
h0=h(d);raw=R*d*d;rawse=D.book2_u_se.to_numpy();geom=R/h0;true=R/(1-tau*R);full=true/(h0*T)
# Conditional uncertainty: independently resample Geant4 whole batches and counts.
rng=np.random.default_rng(20261103);B=12000
anb=an[rng.integers(0,8,(B,8))].mean(1);vnb=vn[rng.integers(0,12,(B,12))].mean(1);afb=af[rng.integers(0,8,(B,8))].mean(1);vfb=vf[rng.integers(0,12,(B,12))].mean(1)
Tb=np.concatenate([anb/vnb,afb/vfb],axis=1);nb=rng.poisson(N,size=(B,len(N)));Rb=nb/time;Fb=Rb/(1-tau*Rb)/h0/Tb
# Linearized independent rail error in geometry; T(d) derivative omitted.
small=1e-6;hprime=(h(d+small)-h(d-small))/(2*small);geom_sd=np.sqrt((np.sqrt(N)/time/h0)**2+(geom*hprime/h0*sd)**2)
Cmc=np.cov(Fb,rowvar=False,ddof=1);dist_sd=np.abs(full*hprime/h0*sd);C=Cmc+np.diag(dist_sd**2);fullse=np.sqrt(np.diag(C));ones=np.ones(len(d));wgt=np.linalg.solve(C,ones);mean=float(wgt@full/(ones@wgt));se=float(np.sqrt(1/(ones@wgt)))
diagw=1/np.diag(C);diagmean=float(diagw@full/diagw.sum());Dchi=float((full-mean)@np.linalg.solve(C,full-mean))
# Ideal constant reference is data-defined, not an independent theory prediction.
ref=(d>=.3-1e-10)&(d<=.4+1e-10);w0=1/rawse[ref]**2;rawref=float(np.sum(w0*raw[ref])/np.sum(w0))
# Count uncertainty only plus selected geometry/MC terms; common uncertain parameters excluded.
results=pd.DataFrame({'d_cm':d*100,'counts':N,'time_s':time,'raw_Rd2':raw,'raw_unc':rawse,'geometry_corrected':geom,'geometry_unc':geom_sd,'air_vacuum_response':T,'fully_corrected':full,'fully_corrected_unc_conditional':fullse});results.to_csv(P/'pointwise_analysis.csv',index=False)
np.savez_compressed(P/'corrected_covariance.npz',d_cm=d*100,conditional=C,MC_and_count=Cmc,rail_variance=dist_sd**2)
def ix(v):return int(np.where(np.isclose(d,v))[0][0])
i1=ix(.01);i25=ix(.025);i85=ix(.85);i30=ix(.3)
mbq=float(2*np.pi*mean/(L**2)/1e6);mbq_se=float(2*np.pi*se/(L**2)/1e6)
info={'source_radius_assumed_mm':rs*1000,'offset_mm':delta*1000,'tau_us':tau*1e6,'K_GLS_conditional':mean,'K_GLS_conditional_se':se,'K_diagonal_only':diagmean,'corrected_constancy_chi2_conditional_unreliable':Dchi,'conditional_df':len(d)-1,'A_parent_times_mean_response_MBq_assuming_equilibrium':mbq,'A_product_conditional_se_MBq':mbq_se,'raw_reference_30_40_cm':rawref,'distance_2_5cm_factor':((d[i25]+delta)/d[i25])**2,'finite_area_2_5cm_factor_vs_offset_only':float((1/h0[i25])/(d[i25]+delta)**2),'deadtime_rate_correction_1cm_percent':float(100*(true[i1]/R[i1]-1)),'T30':T[i30],'T85':T[i85],'T85_bootstrap_se':float(Tb[:,i85].std(ddof=1)),'air_inverse_correction_85cm_percent':float(100*(1/T[i85]-1)),'air_relative_85_over_30':float(T[i85]/T[i30]),'caveats':['Geant4 air/vac is detector-and-source-model-dependent transport response, not measured transmission.','Absolute T includes threshold and geometry-dependent scattering; assuming its product with ideal geometric acceptance is a separability approximation.','Source radius 11 mm and encapsulation assumed, not independently measured; different from the 5mm earlier G2 example.','No independently measured background or detector efficiency.','Shared offset, deadtime, source geometry, spectrum and response uncertainty not in band; 8/12 MC batches limit covariance reliability; do not use naive chi-square as established constancy.','Treating 0.5mm as independent standard d error assumes a standard interpretation; distance derivative of T ignored.','Constant is fit to same points; no independent proof.','Estimated activity-times-response product relies on equilibrium and approximate factorization; not absolute parent activity.']}
(P/'summary.json').write_text(json.dumps(info,indent=2))
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42})
fig,(ax,bx,cx)=plt.subplots(3,1,figsize=(7.1,8.4),sharex=True,gridspec_kw={'height_ratios':[1,1.1,1]},layout='constrained')
ax.errorbar(d*100,raw,xerr=.05,yerr=rawse,fmt='o',ms=3.2,capsize=1.5,elinewidth=.7,color='#333333',label='Raw $Rd^2$ (Book2)');ax.axhline(rawref,color='#8c969d',ls='--',lw=1,label='Constant: mean over 30–40 cm');ax.set(title='(a) Observed distance dependence',ylabel=r'$Rd^2$ (m$^2$ s$^{-1}$)',ylim=(0,None));ax.legend(frameon=False,fontsize=7.3,loc='lower right')
bx.errorbar(d*100,raw,yerr=rawse,fmt='o',ms=2.8,capsize=1,elinewidth=.5,color='#9da7ae',alpha=.8,label='Raw $Rd^2$');bx.errorbar(d*100,geom,yerr=geom_sd,fmt='s',ms=2.8,capsize=1,elinewidth=.5,color='#d78323',label='Geometry corrected');bx.errorbar(d*100,full,yerr=fullse,fmt='^',ms=2.7,capsize=1,elinewidth=.6,color='#008574',alpha=.8,label='Model corrected (conditional)');bx.set(title='(b) Effect of model-dependent corrections',ylabel=r'Effective $K$ (m$^2$ s$^{-1}$)');bx.legend(frameon=False,fontsize=7.1,ncol=1,loc='lower right')
cx.errorbar(d*100,full,yerr=fullse,fmt='o',ms=3.1,capsize=1.5,elinewidth=.6,color='#176550',label='Model-corrected estimate');cx.axhline(mean,color='#176550',lw=1.4,label='GLS mean (conditional)');cx.axhspan(mean-se,mean+se,color='#176550',alpha=.15,label='Conditional statistical uncertainty');cx.set(title='(c) Corrected source-strength proxy',xlabel='Rail distance $d$ (cm)',ylabel=r'$K_{\rm est}$ (m$^2$ s$^{-1}$)',xlim=(0,88));cx.legend(frameon=False,fontsize=7.2,loc='lower right')
for a in [ax,bx,cx]:a.grid(alpha=.14)
fig.savefig(P/'evidence_chain.png',dpi=300,bbox_inches='tight');fig.savefig(P/'evidence_chain.pdf',bbox_inches='tight')
print(json.dumps(info,indent=2));print(results.iloc[[0,1,12,20,31]].to_string(index=False))
