from pathlib import Path
import json,numpy as np,pandas as pd,matplotlib.pyplot as plt
P=Path(__file__).resolve().parent;D=pd.read_csv(P.parent/'sr90_research/results/last_three.csv');d=D.d_m.to_numpy();N=D.counts.to_numpy(float);t=D.time_s.to_numpy();u=D.raw_u.to_numpy();eu=D.book2_u_se.to_numpy()
def load(medium,nb):
 fs=sorted((P/medium).glob('batch_*.csv'));assert len(fs)==nb
 out=[]
 for f in fs:
  x=pd.read_csv(f);x=x[x.threshold_keV==10];out.append([x.loc[np.isclose(x.distance_m,z),'probability'].iloc[0] for z in d])
 return np.array(out)
a=load('air',8);v=load('vacuum',12);pa=a.mean(0);pv=v.mean(0);T=pa/pv;ref=(d>=.2-1e-9)&(d<=.3+1e-9);amp=N[ref].sum()/np.sum(t[ref]*pa[ref]);sim=amp*pa*d*d
B=10000;rng=np.random.default_rng(20301103);ab=a[rng.integers(0,8,(B,8))].mean(1);vb=v[rng.integers(0,12,(B,12))].mean(1);nb=rng.poisson(N[ref],size=(B,ref.sum()));ampb=nb.sum(1)/np.sum(t[ref]*ab[:,ref],axis=1);simboot=ampb[:,None]*ab*d*d;simse=simboot.std(0,ddof=1);Tb=ab/vb;Tse=Tb.std(0,ddof=1)
out=pd.DataFrame({'d_cm':d*100,'exp_Cd2':u,'exp_Book2_unc':eu,'air_probability':pa,'vacuum_probability':pv,'air_over_vacuum':T,'air_over_vacuum_MC_se':Tse,'scaled_air_Cd2':sim,'scaled_air_conditional_MC_and_scale_se':simse,'normalization_point':ref});out.to_csv(P/'comparison.csv',index=False)
np.savez_compressed(P/'covariance.npz',d_cm=d*100,scaled_air_covariance=np.cov(simboot,rowvar=False),air_over_vacuum_covariance=np.cov(Tb,rowvar=False))
i30=np.where(np.isclose(d,.3))[0][0];i85=np.where(np.isclose(d,.85))[0][0];qexp=u[i85]/u[i30];qair=(pa[i85]/pa[i30])*(d[i85]/d[i30])**2;qvac=(pv[i85]/pv[i30])*(d[i85]/d[i30])**2
qa=(ab[:,i85]/ab[:,i30])*(d[i85]/d[i30])**2;qv=(vb[:,i85]/vb[:,i30])*(d[i85]/d[i30])**2;qerr=qexp*np.sqrt((eu[i85]/u[i85])**2+(eu[i30]/u[i30])**2)
summary={'source_exit_diameter_mm':9.75,'active_source_diameter_mm_assumed':22,'offset_mm':15,'transverse_x_y_mm':[0,0],'threshold_keV_assumed':10,'geometrical_aperture_used_air_and_vacuum':'9.75 mm; same source and detector solids','normalization':'single scale fitted to latest three experimental count sums at 20–30cm','scale_per_s':amp,'Q_experiment_85_over_30':qexp,'Q_experiment_conditional_unc':qerr,'Q_air_85_over_30':qair,'Q_air_MC_se':qa.std(ddof=1),'Q_vacuum_85_over_30':qvac,'Q_vacuum_MC_se':qv.std(ddof=1),'T30':T[i30],'T85':T[i85],'T85_over_T30':T[i85]/T[i30],'assumptions':'15mm offset not independently calibrated; 22mm emitting disk, 0.05mm foil, 1mm acrylic, detector frame material and 10keV threshold assumed; deadtime and background not included in raw simulation comparison','batch_reuse':'8 independent air and 12 vacuum batches over 32 distances; bootstrap resamples entire batches to retain cross-distance correlation'}
old=pd.read_csv(P.parent/'latest_geant4_raw_cd2/plot_data.csv');assert np.allclose(old.d_cm,d*100)
compare=pd.DataFrame({'d_cm':d*100,'new_probability_975mm':pa,'old_probability_11mm':old.geant4_air_probability,'new_over_old_probability':pa/old.geant4_air_probability,'new_scaled_Cd2':sim,'old_scaled_Cd2':old.geant4_scaled_Cd2,'new_over_old_scaled_Cd2':sim/old.geant4_scaled_Cd2});compare.to_csv(P/'aperture_comparison.csv',index=False)
summary['new_over_old_at_1cm_unscaled']=float(compare.new_over_old_probability.iloc[0]);summary['new_over_old_at_1cm_scaled']=float(compare.new_over_old_scaled_Cd2.iloc[0]);summary['new_over_old_at_85cm_unscaled']=float(compare.new_over_old_probability.iloc[-1]);summary['new_over_old_at_85cm_scaled']=float(compare.new_over_old_scaled_Cd2.iloc[-1]);
(P/'summary.json').write_text(json.dumps(summary,indent=2));
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42});fig,ax=plt.subplots(figsize=(8.5,5.4),layout='constrained')
ax.errorbar(d*100,u,xerr=.05,yerr=eu,fmt='o',ms=4.2,capsize=2,elinewidth=.8,color='#1c4e70',label='Raw measurements (Book2 error)',zorder=4)
ax.errorbar(d*100,sim,yerr=simse,fmt='s',mfc='white',ms=3.7,capsize=1.7,elinewidth=.7,color='#d26b2a',label='Geant4 air (MC + scale error)',zorder=3)
ax.plot(d*100,sim,color='#d26b2a',lw=1.05,alpha=.75);ax.axvspan(20,30,color='#e3e7ea',alpha=.55,zorder=0,label='20–30 cm normalization')
ax.set(xlabel='Rail distance $d$ (cm)',ylabel=r'$Cd^2$ (m$^2$ s$^{-1}$)',title='Measured data and Geant4: 9.75 mm source aperture',xlim=(0,88),ylim=(0,None));ax.grid(alpha=.15);ax.legend(frameon=False,fontsize=8.8,loc='lower right')
fig.savefig(P/'raw_vs_geant4_975.png',dpi=300,bbox_inches='tight');fig.savefig(P/'raw_vs_geant4_975.pdf',bbox_inches='tight');print(json.dumps(summary,indent=2));print(out.iloc[[0,1,2,8,12,20,31]].to_string(index=False))
