#!/usr/bin/env python3
"""Geometry-only Task16 analysis. Run: python geometry_analysis.py [input_dir] [output_dir].
Requires numpy, scipy, pandas, openpyxl and matplotlib. No Geant4.
Inputs: task16.xlsx, Task16_older.csv, Book2.xlsx (default sibling sr90_research/inputs).
"""
from pathlib import Path
import sys, json
import numpy as np,pandas as pd, openpyxl, matplotlib.pyplot as plt
from scipy.special import roots_legendre
from scipy.stats import chi2, qmc
HERE=Path(__file__).resolve().parent
IN=Path(sys.argv[1]) if len(sys.argv)>1 else HERE/'inputs'
OUT=Path(sys.argv[2]) if len(sys.argv)>2 else HERE
OUT.mkdir(parents=True,exist_ok=True)
L=.010; DELTA=.01905; RS=.005; SD=.0005

def num(x):
 try: return float(str(x).replace('\xa0','').strip())
 except (ValueError,TypeError): return np.nan
# Load primary original records. A blank row separates groups; a new distance also resets group.
s=openpyxl.load_workbook(IN/'task16.xlsx',data_only=True).worksheets[0]
records=[];d=np.nan;sd=np.nan;group=1;blank=False
for i in range(2,s.max_row+1):
 vals=[s.cell(i,j).value for j in [1,2,3,5]];a,b,n,t=map(num,vals)
 if np.isfinite(a): d=a;sd=b if np.isfinite(b) else SD;group=1;blank=False
 if not np.isfinite(n) or not np.isfinite(t):
  if np.isfinite(d): blank=True
  continue
 if blank: group+=1;blank=False
 records.append(dict(source='task16.xlsx',source_row=i,d_m=d,sigma_d_m=sd,counts=int(n),time_s=t,group=group))
raw=pd.DataFrame(records);assert len(raw)==141 and raw.d_m.notna().all()
raw['rate_s']=raw.counts/raw.time_s;raw['u_m2_s']=raw.rate_s*raw.d_m**2
raw['sigma_u']=raw.u_m2_s*np.sqrt(1/raw.counts+(2*raw.sigma_d_m/raw.d_m)**2)
raw.to_csv(OUT/'original_observations.csv',index=False)
# Test each group for a constant rate before aggregation; retain each group independently.
groups=[]
for (d,g),x in raw.groupby(['d_m','group'],sort=True):
 n=x.counts.to_numpy();t=x.time_s.to_numpy();rate=n.sum()/t.sum(); mu=rate*t
 Q=np.sum((n-mu)**2/mu);df=len(n)-1
 groups.append(dict(d_m=d,group=g,N=int(n.sum()),t_s=t.sum(),n_obs=len(n),rate=rate,u=rate*d*d,
 sigma_u=rate*d*d*np.sqrt(1/n.sum()+(2*float(x.sigma_d_m.iloc[0])/d)**2),sigma_d=float(x.sigma_d_m.iloc[0]),
 consistency_Q=Q,consistency_df=df,consistency_p=chi2.sf(Q,df) if df else np.nan,source_rows=';'.join(map(str,x.source_row))))
grp=pd.DataFrame(groups);grp['latest']=grp.group.eq(grp.groupby('d_m').group.transform('max'))
grp.to_csv(OUT/'repeat_groups_and_consistency.csv',index=False)
# Compare group rates at each distance without pooling them for the near-field figure.
pairs=[]
for d,gg in grp.groupby('d_m'):
 if len(gg)<2: continue
 n=gg.N.to_numpy();t=gg.t_s.to_numpy();expected=n.sum()/t.sum()*t
 q=float(np.sum((n-expected)**2/expected));df=len(n)-1
 pairs.append(dict(d_m=d,groups=len(n),Q=q,df=df,p_value=chi2.sf(q,df),source_rows=' | '.join(gg.source_rows)))
pd.DataFrame(pairs).to_csv(OUT/'between_group_consistency.csv',index=False)
# Historical records and Book2 lower rows retained as source records; possible duplicates flagged, not deleted.
old=pd.read_csv(IN/'Task16_older.csv');
for c in ['d','d_unc','n','t']:old[c]=pd.to_numeric(old[c],errors='coerce')
old=old[(old.d>0)&old.n.notna()&old.t.notna()].copy();old['possible_duplicate']=False
for ix,x in old.iterrows(): old.loc[ix,'possible_duplicate']=bool(((np.isclose(raw.d_m,x.d))&(raw.counts==x.n)&np.isclose(raw.time_s,x.t)).any())
b=openpyxl.load_workbook(IN/'Book2.xlsx',data_only=True).worksheets[0];extra=[]
for i in range(35,b.max_row+1):
 d0,sd0,n0,t0=map(num,[b.cell(i,1).value,b.cell(i,2).value,b.cell(i,3).value,b.cell(i,5).value])
 if np.isfinite(d0) and d0>0 and n0>0 and t0>0:
  duplicate=bool(((np.isclose(raw.d_m,d0))&(raw.counts==n0)&np.isclose(raw.time_s,t0)).any())
  extra.append(dict(source_row=i,d=d0,d_unc=sd0 if np.isfinite(sd0) else SD,n=n0,t=t0,possible_duplicate=duplicate))
extra=pd.DataFrame(extra);old.to_csv(OUT/'older_csv_observations.csv',index=False);extra.to_csv(OUT/'book2_lower_observations.csv',index=False)
# Analytic solid angle of a rectangle viewed from an off-axis point.
def solid_rect(r,x,y):
 x1=-L/2-x;x2=L/2-x;y1=-L/2-y;y2=L/2-y
 def f(a,b):return np.arctan2(a*b,r*np.sqrt(r*r+a*a+b*b))
 return f(x2,y2)-f(x1,y2)-f(x2,y1)+f(x1,y1)
def square(r):return 4*np.arctan(L*L/(4*r*np.sqrt(r*r+L*L/2)))
def omega_disc(r,rs,nr=24,nt=48):
 r=np.atleast_1d(np.asarray(r,float))
 if rs==0:return square(r)
 # Radial quadrature is uniform in area: rho=Rs*sqrt(q).
 z,w=roots_legendre(nr);q=(z+1)/2;w=w/2; phi=2*np.pi*(np.arange(nt)+.5)/nt
 x=rs*np.sqrt(q)[:,None]*np.cos(phi)[None,:];y=rs*np.sqrt(q)[:,None]*np.sin(phi)[None,:]
 return np.array([np.sum(w[:,None]*solid_rect(float(a),x,y))/nt for a in r])
def factor(d,delta,kind,rs=RS,nr=24,nt=48):
 d=np.atleast_1d(np.array(d,float));r=d+delta
 if kind=='G0':return (d/r)**2
 if kind=='G1':return square(r)/L**2*d**2
 return omega_disc(r,rs,nr,nt)/L**2*d**2
# Normalise G0 with raw counts, 30–40 cm inclusive, all individual observations.
# Poisson likelihood, expectation mu_i=t_i*K/(d_i+delta)^2; no near-field points.
ref=raw[(raw.d_m>=.30-1e-10)&(raw.d_m<=.40+1e-10)]
K=ref.counts.sum()/np.sum(ref.time_s/(ref.d_m+DELTA)**2); Kse=K/np.sqrt(ref.counts.sum())
near=grp[(grp.d_m<=.100001)&(grp.d_m>=.009999)].copy();rr=near.d_m.to_numpy()
for model in ['G0','G1','G2']:
 m=K*factor(rr,DELTA,model);near[model]=m;near['resid_'+model+'_pct']=100*(near.u/m-1);near['resid_'+model+'_sigma_pct']=100*near.sigma_u/m
 near['conditional_z_'+model]=(near.u-m)/np.sqrt(near.sigma_u**2+(m*Kse/K)**2)
near['G0_to_G1_pct']=100*(near.G1/near.G0-1);near['G1_to_G2_pct']=100*(near.G2/near.G1-1)
for off in [.016,.018,.01905,.021,.023]:near[f'G2_offset_{off*1000:g}mm']=K*factor(rr,off,'G2')
for rs in [0,.0025,.005,.011]:near[f'G2_Rs_{rs*1000:g}mm']=K*factor(rr,DELTA,'G2',rs)
near.to_csv(OUT/'model_comparison.csv',index=False)
# Independent numerical tests: exact point formula and direct 4D scrambled Sobol.
test=np.array([.01,.025,.05,.075,.1]);r=test+DELTA
low=omega_disc(r,RS,12,24);hi=omega_disc(r,RS,48,96); nominal=omega_disc(r,RS)
quadmax=float(np.max(np.abs(nominal-hi)/hi));point_error=float(np.max(np.abs(solid_rect(r,0,0)/square(r)-1)))
def qmc_check(rr,rs):
 vals=[]
 for seed in range(8):
  v=qmc.Sobol(4,scramble=True,seed=seed).random_base2(16);rad=rs*np.sqrt(v[:,0]);phi=2*np.pi*v[:,1];xs=rad*np.cos(phi);ys=rad*np.sin(phi);xd=L*(v[:,2]-.5);yd=L*(v[:,3]-.5)
  vals.append(np.mean(rr/(rr*rr+(xd-xs)**2+(yd-ys)**2)**1.5)*L**2)
 return np.mean(vals),np.std(vals,ddof=1)/np.sqrt(len(vals))
qm=[qmc_check(a,RS) for a in r]; qm_rel=[(m-h)/h for (m,se),h in zip(qm,hi)]
checks={'K_m2_per_s':K,'K_poisson_se':Kse,'reference':'G0, fixed delta 19.05 mm, Poisson MLE, all task16 workbook raw observations at 30–40 cm; common K for all models/scenarios', 'reference_rows':len(ref),'reference_total_counts':int(ref.counts.sum()),'offset_mm':19.05,'source_radius_mm_illustrative':5,'detector_side_mm':10,'delta_scenarios_mm':[16,18,19.05,21,23], 'radius_scenarios_mm':[0,2.5,5,11], 'quad_24x48_vs_48x96_max_rel':quadmax,'point_solid_angle_max_rel':point_error,'qmc_relative_differences':qm_rel,'qmc_standard_errors_solid_angle':[float(z[1]) for z in qm], 'geometry_and_offsets_calibrated':False,'numeric_integration_uncertainty_type':'independent scrambled Sobol numerical integration, not experimental uncertainty'}
assert quadmax<1e-8 and point_error<1e-12
(OUT/'numerical_checks.json').write_text(json.dumps(checks,indent=2))
# Figure: conditional data errors; scenario span is not a confidence band.
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':8,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42})
fig,axs=plt.subplots(1,3,figsize=(10.4,3.35),layout='constrained');grid=np.linspace(.01,.1,350);xx=grid*100
colors={'G0':'#0072B2','G1':'#D55E00','G2':'#009E73'};styles={'G0':':','G1':'--','G2':'-'}
def plotdata(ax):
 for latest,mark,label in [(True,'o','Latest group'),(False,'s','Earlier group')]:
  z=near[near.latest==latest];ax.errorbar(z.d_m*100,z.u,xerr=z.sigma_d*100,yerr=z.sigma_u,fmt=mark,color='#333333',mfc='white' if not latest else '#333333',ms=3.7,capsize=2,elinewidth=.8,label=label,zorder=5)
 z=old[(old.d<=.100001)&~old.possible_duplicate];u=z.n/z.t*z.d**2;se=u*np.sqrt(1/z.n+(2*z.d_unc/z.d)**2)
 ax.errorbar(z.d*100,u,xerr=z.d_unc*100,yerr=se,fmt='^',color='#AA4499',ms=3.2,capsize=2,elinewidth=.7,label='Older CSV',zorder=4)
 if not extra.empty:
  z=extra[(extra.d<=.100001)&~extra.possible_duplicate];u=z.n/z.t*z.d**2;se=u*np.sqrt(1/z.n+(2*z.d_unc/z.d)**2)
  ax.errorbar(z.d*100,u,xerr=z.d_unc*100,yerr=se,fmt='D',color='#CC79A7',ms=3,capsize=2,elinewidth=.7,label='Book2 extra',zorder=4)
ax=axs[0]
for m in ['G0','G1','G2']:ax.plot(xx,K*factor(grid,DELTA,m),color=colors[m],ls=styles[m],lw=1.8,label=m)
plotdata(ax);ax.set_title('(a) Near-field geometrical acceptance',fontsize=9);ax.set_ylabel(r'$Rd^2$ (m$^2$ s$^{-1}$)');ax.legend(fontsize=6.3,ncol=2,frameon=False,loc='lower right')
ax=axs[1];curves=np.array([K*factor(grid,x,'G2') for x in [.016,.018,.01905,.021,.023]])
ax.fill_between(xx,curves.min(axis=0),curves.max(axis=0),color='#009E73',alpha=.19,label=r'$\delta=16$–$23$ mm scenarios');ax.plot(xx,curves[2],color='#009E73',lw=1.8,label=r'G2, $\delta=19.05$ mm');plotdata(ax);ax.set_title('(b) Sensitivity to effective separation',fontsize=9);ax.legend(fontsize=6.3,frameon=False,loc='lower right')
ax=axs[2];ax.axhline(0,color='#333333',lw=.8);ax.axhspan(-100*Kse/K,100*Kse/K,color='0.55',alpha=.25,label='Common K: conditional 1σ')
for model in ['G0','G1','G2']:
 for latest,marker in [(True,'o'),(False,'s')]:
  z=near[near.latest==latest];ax.errorbar(z.d_m*100,z['resid_'+model+'_pct'],yerr=z['resid_'+model+'_sigma_pct'],fmt=marker,color=colors[model],mfc=colors[model] if latest else 'white',ms=3.4,capsize=1.7,elinewidth=.7,label=model if latest else None)
ax.set_title('(c) Model-to-data comparison',fontsize=9);ax.set_ylabel('Data − model / model (%)');ax.legend(fontsize=6.4,frameon=False,loc='upper right');
for ax in axs:ax.set_xlim(.5,10.5);ax.set_xlabel('$d$ (cm)');ax.grid(alpha=.15)
fig.savefig(OUT/'near_field_geometry.pdf',bbox_inches='tight');fig.savefig(OUT/'near_field_geometry.png',dpi=400,bbox_inches='tight')
print(json.dumps(checks,indent=2));print('\nNear group results:');print(near[['d_m','group','u','sigma_u','G0','G1','G2','G0_to_G1_pct','G1_to_G2_pct','resid_G2_pct','consistency_p']].to_string(index=False))
