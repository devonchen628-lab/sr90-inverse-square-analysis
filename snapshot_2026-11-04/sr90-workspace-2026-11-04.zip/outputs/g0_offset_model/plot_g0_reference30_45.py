from pathlib import Path
import numpy as np, openpyxl, matplotlib.pyplot as plt
out=Path(__file__).resolve().parent
s=openpyxl.load_workbook(out.parent/'sr90_research/results/task16_Book2_calculation.xlsx',data_only=True)['Book2 calculation']
a=np.array([[s.cell(i,j).value for j in (1,2,6,7)] for i in range(2,34)],float)
mask=(a[:,0]>=.30-1e-12)&(a[:,0]<=.45+1e-12); ref=a[mask]; w=1/ref[:,3]**2
K=np.sum(w*ref[:,2])/np.sum(w);Kse=1/np.sqrt(np.sum(w));chi=np.sum(((ref[:,2]-K)/ref[:,3])**2)
d=np.linspace(0,.85,1000);delta=.01905;u=K*(d/(d+delta))**2
plt.rcParams.update({'font.size':11,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42})
fig,ax=plt.subplots(figsize=(8.3,5.2),layout='constrained')
ax.errorbar(a[:,0]*100,a[:,2],xerr=a[:,1]*100,yerr=a[:,3],fmt='o',markersize=4.6,capsize=2.7,elinewidth=.9,color='#175976',label='Raw data: last 3 measurements')
ax.plot(d*100,u,color='#c55832',lw=2.1,label=r'G0: $K[d/(d+\delta)]^2$')
ax.axhline(K,color='#687780',lw=1.3,ls='--',label=rf'Weighted constant fit: $K={K:.3f}$')
ax.axvspan(30,45,color='#dfe4e8',alpha=.6,zorder=-1,label='Fit interval: 30–45 cm')
ax.set(xlabel='Rail distance $d$ (cm)',ylabel=r'$Rd^2$ (m$^2$ s$^{-1}$)',title=r'Raw data and G0 model: $\delta=19.05$ mm',xlim=(0,87),ylim=(0,None));ax.grid(alpha=.2);ax.legend(frameon=False,loc='lower right',fontsize=8.6)
fig.savefig(out/'G0_reference30_45.png',dpi=250,bbox_inches='tight');fig.savefig(out/'G0_reference30_45.pdf',bbox_inches='tight')
print(f'K={K:.8f} conditional_sigma={Kse:.8f} chi2={chi:.3f} dof={len(ref)-1} n={len(ref)}')
