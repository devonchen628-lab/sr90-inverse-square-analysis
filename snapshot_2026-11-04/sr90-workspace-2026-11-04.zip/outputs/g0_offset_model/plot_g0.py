from pathlib import Path
import numpy as np
import matplotlib.pyplot as plt

out = Path(__file__).resolve().parent
d_cm = np.linspace(0, 20, 1001)
delta_cm = 1.905
normalized_u = (d_cm / (d_cm + delta_cm))**2

plt.rcParams.update({'font.size': 11, 'axes.spines.top': False, 'axes.spines.right': False, 'pdf.fonttype': 42})
fig, ax = plt.subplots(figsize=(7.2, 4.6), layout='constrained')
ax.plot(d_cm, normalized_u, color='#12658a', lw=2.5, label=r'$u_{\rm G0}/K=[d/(d+\delta)]^2$')
ax.axhline(1, color='#7e8991', lw=1, ls='--', label=r'Ideal limit $u/K=1$')
ax.set(xlabel='Rail distance $d$ (cm)', ylabel=r'Normalized $u_{\rm G0}/K$ (dimensionless)', title=r'Distance offset model: $\delta=19.05$ mm', xlim=(0, 20), ylim=(0, 1.08))
ax.grid(alpha=.2); ax.legend(frameon=False, loc='lower right')
fig.savefig(out/'G0_distance_offset.png', dpi=250, bbox_inches='tight')
fig.savefig(out/'G0_distance_offset.pdf', bbox_inches='tight')
