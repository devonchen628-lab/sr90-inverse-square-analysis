from pathlib import Path
import numpy as np, openpyxl, matplotlib.pyplot as plt
out=Path(__file__).resolve().parent
root=out.parent/'sr90_research/results'
s=openpyxl.load_workbook(root/'task16_Book2_calculation.xlsx',data_only=True)['Book2 calculation']
a=np.array([[s.cell(i,j).value for j in (1,2,6,7)] for i in range(2,34)],float)
d=np.linspace(0,.85,1000); K=14.461629776573316;delta=.01905
u=K*(d/(d+delta))**2
plt.rcParams.update({'font.size':11,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42})
fig,ax=plt.subplots(figsize=(8,5.1),layout='constrained')
ax.errorbar(a[:,0]*100,a[:,2],xerr=a[:,1]*100,yerr=a[:,3],fmt='o',markersize=4.6,capsize=2.7,elinewidth=.9,color='#175976',label='Raw data: last 3 measurements')
ax.plot(d*100,u,color='#c55832',lw=2.1,label=r'G0: $K[d/(d+\delta)]^2$')
ax.axvspan(30,40,color='#dfe4e8',alpha=.6,zorder=-1,label='$K$ fitted: 30–40 cm')
ax.set(xlabel='Rail distance $d$ (cm)',ylabel=r'$Rd^2$ (m$^2$ s$^{-1}$)',title=r'Raw data and distance-offset model ($\delta=19.05$ mm)',xlim=(0,87),ylim=(0,None))
ax.grid(alpha=.2);ax.legend(frameon=False,loc='lower right',fontsize=9)
fig.savefig(out/'G0_vs_raw.png',dpi=250,bbox_inches='tight');fig.savefig(out/'G0_vs_raw.pdf',bbox_inches='tight')
