from pathlib import Path
import numpy as np, openpyxl, matplotlib.pyplot as plt, csv
out=Path(__file__).resolve().parent
root=out.parent/'sr90_research/results'
s=openpyxl.load_workbook(root/'task16_Book2_calculation.xlsx',data_only=True)['Book2 calculation']
a=np.array([[s.cell(i,j).value for j in (1,2,6,7)] for i in range(2,34)],float)
d=np.linspace(0,.85,1000); delta=.01905
with (root/'raw_observations.csv').open(newline='') as f:
    rows=list(csv.DictReader(f))
reference=[r for r in rows if .30-1e-10 <= float(r['d_m']) <= .45+1e-10]
K=sum(float(r['counts']) for r in reference)/sum(float(r['time_s'])/(float(r['d_m'])+delta)**2 for r in reference)
print(f'K = {K:.8f} m²/s; {len(reference)} reference observations')
u=K*(d/(d+delta))**2
plt.rcParams.update({'font.size':11,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42})
fig,ax=plt.subplots(figsize=(8,5.1),layout='constrained')
ax.errorbar(a[:,0]*100,a[:,2],xerr=a[:,1]*100,yerr=a[:,3],fmt='o',markersize=4.6,capsize=2.7,elinewidth=.9,color='#175976',label='Raw data: last 3 measurements')
ax.plot(d*100,u,color='#c55832',lw=2.1,label=r'G0: $K[d/(d+\delta)]^2$')
ax.axvspan(30,45,color='#dfe4e8',alpha=.6,zorder=-1,label='$K$ fitted: 30–45 cm')
ax.set(xlabel='Rail distance $d$ (cm)',ylabel=r'$Rd^2$ (m$^2$ s$^{-1}$)',title=r'Raw data and distance-offset model ($\delta=19.05$ mm)',xlim=(0,87),ylim=(0,None))
ax.grid(alpha=.2);ax.legend(frameon=False,loc='lower right',fontsize=9)
fig.savefig(out/'G0_vs_raw_30_45.png',dpi=250,bbox_inches='tight');fig.savefig(out/'G0_vs_raw_30_45.pdf',bbox_inches='tight')
