from pathlib import Path
import json,numpy as np,pandas as pd,matplotlib.pyplot as plt
from scipy.special import roots_legendre
O=Path(__file__).resolve().parent;root=O.parent;df=pd.read_csv(root/'sr90_research/results/last_three.csv');far=root/'far_field_15mm_aligned'
d=df.d_m.to_numpy();N=df.counts.to_numpy();t=df.time_s.to_numpy();R=N/t;sigR=np.sqrt(N)/t;sd=.0005;delta=.015;tau=2e-6;L=.01;rs=.005
z,w=roots_legendre(24);w=w/2;phi=2*np.pi*(np.arange(48)+.5)/48;x=rs*np.sqrt((z+1)/2)[:,None]*np.cos(phi);y=rs*np.sqrt((z+1)/2)[:,None]*np.sin(phi);x1=-L/2-x;x2=L/2-x;y1=-L/2-y;y2=L/2-y
def omega(r):
 def f(a,b,r):return np.arctan2(a*b,r*np.sqrt(r*r+a*a+b*b))
 return np.array([np.sum(w[:,None]*(f(x2,y2,v)-f(x1,y2,v)-f(x2,y1,v)+f(x1,y1,v)))/48 for v in np.atleast_1d(r)])
def factor(d):return L**2/omega(d+delta)
def numerical(f,d):return (f(d+1e-6)-f(d-1e-6))/(2e-6)
r=d+delta;F=factor(d);Fp=numerical(factor,d);Rtrue=R/(1-tau*R);drdR=1/(1-tau*R)**2
Uraw=R*d*d;Sraw=np.sqrt((d*d*sigR)**2+(2*d*R*sd)**2)
Udist=R*r*r;Sdist=np.sqrt((r*r*sigR)**2+(2*r*R*sd)**2)
Ugeom=Rtrue*F;Sgeom=np.sqrt((F*drdR*sigR)**2+(Rtrue*Fp*sd)**2)
knots=np.array(pd.read_csv(far/'simulation_relative.csv').d_cm)/100
idx=np.array([np.where(np.isclose(d,x))[0][0] for x in knots]);assert np.allclose(knots,d[idx])
def read(folder,n):
 files=sorted((far/folder).glob('batch_*.csv'));assert len(files)==n;out=[]
 for f in files:
  a=pd.read_csv(f);a=a[a.threshold_keV==10];out.append([a.loc[np.isclose(a.distance_m,x),'probability'].iloc[0] for x in knots])
 return np.array(out)
a=read('air',8);v=read('vacuum',12);T=a.mean(axis=0)/v.mean(axis=0);Trel=T/T[0]
rng=np.random.default_rng(251102);B=50000
ab=a[rng.integers(0,len(a),(B,len(a)))].mean(axis=1);vb=v[rng.integers(0,len(v),(B,len(v)))].mean(axis=1);Tb=ab/vb;Trelb=Tb/Tb[:,0,None];air_factor=1/Trel;bootfactor=1/Trelb
Uair=Ugeom[idx]*air_factor;Cmc=np.cov(bootfactor,rowvar=False)*np.outer(Ugeom[idx],Ugeom[idx]);Cstats=np.diag((Sgeom[idx]*air_factor)**2);Ctot=Cmc+Cstats;Sair=np.sqrt(np.diag(Ctot))
allrows=pd.DataFrame({'d_cm':d*100,'counts':N,'time_s':t,'raw_Rd2':Uraw,'raw_se':Sraw,'distance_corrected':Udist,'distance_corrected_se':Sdist,'geometry_deadtime_corrected':Ugeom,'geometry_deadtime_se':Sgeom,'air_corrected':np.nan,'air_corrected_se':np.nan,'relative_air_transmission':np.nan});allrows.loc[idx,'air_corrected']=Uair;allrows.loc[idx,'air_corrected_se']=Sair;allrows.loc[idx,'relative_air_transmission']=Trel;allrows.to_csv(O/'progressive_correction_values.csv',index=False)
np.savez_compressed(O/'air_corrected_covariance.npz',distance_cm=knots*100,total_conditional=Ctot,mc=Cmc,experimental=Cstats)
meta={'offset_mm':15,'source_radius_mm_assumed':5,'tau_us_assumed':2,'deadtime_model':'nonparalyzable','air_sim_source_radius_mm_assumed':11,'air_sim_actual_distances_only_cm':list(knots*100),'air_anchor_cm':30,'formula':'K_air(d)=R_obs/(1-tau*R_obs)*L^2/Omega_disc(d+delta) * T(30)/T(d)','interpretation':'air correction normalized to 30 cm, not absolute unattenuated emission; hybrid model with unequal assumed source radius; no validated uncertainty on geometry/deadtime/MC model','uncertainty':'conditional Poisson, rail 0.5mm at each point, whole-batch Monte Carlo for air factor; shared 30 cm and cross-distance MC covariance saved; no common delta, source radius, tau or material systematic'};(O/'assumptions.json').write_text(json.dumps(meta,indent=2))
plt.rcParams.update({'font.size':10,'font.family':'DejaVu Sans','axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42})
fig,ax=plt.subplots(figsize=(9,5.7),layout='constrained')
ax.errorbar(d*100,Uraw,yerr=Sraw,fmt='o',mfc='none',color='#557b96',ms=4.2,elinewidth=.7,capsize=1.5,alpha=.8,label=r'1. Raw $Rd^2$')
ax.errorbar(d*100,Udist,yerr=Sdist,fmt='s',mfc='none',color='#d58a23',ms=4,elinewidth=.7,capsize=1.5,alpha=.8,label=r'2. Distance: $R(d+\delta)^2$')
ax.errorbar(d*100,Ugeom,yerr=Sgeom,fmt='^',color='#16846e',ms=4,elinewidth=.7,capsize=1.5,alpha=.85,label='3. + finite geometry and dead time')
ax.errorbar(knots*100,Uair,yerr=Sair,fmt='D',color='#b44c70',ms=4.3,elinewidth=.9,capsize=2,alpha=.9,label='4. + relative air transport (30–85 cm)')
ref=Uair[0];ax.axhline(ref,color='#777777',ls=':',lw=1,label='30 cm reference (not a fit)')
ax.set(xlabel='Rail distance $d$ (cm)',ylabel=r'Corrected rate × distance² (m$^2$ s$^{-1}$)',title=r'Stepwise corrections to the measured $Rd^2$',xlim=(0,88),ylim=(0,None));ax.grid(alpha=.16);ax.legend(frameon=False,fontsize=8.7,loc='lower right',ncol=1)
fig.savefig(O/'progressive_corrections.png',dpi=300,bbox_inches='tight');fig.savefig(O/'progressive_corrections.pdf',bbox_inches='tight')
print('Reference corrected K30:',ref,'air end K85:',Uair[-1],'+-',Sair[-1]);print(allrows.loc[[0,1,10,12,20,31]].to_string(index=False))
