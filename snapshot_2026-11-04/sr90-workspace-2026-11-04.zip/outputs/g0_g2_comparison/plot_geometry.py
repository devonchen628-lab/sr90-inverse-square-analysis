from pathlib import Path
import csv,numpy as np,openpyxl,matplotlib.pyplot as plt
from scipy.special import roots_legendre
out=Path(__file__).resolve().parent; root=out.parent/'sr90_research/results';L=.010;rs=.005;delta=.01905
with (root/'raw_observations.csv').open(newline='') as f: rows=list(csv.DictReader(f))
ref=[r for r in rows if .30-1e-10<=float(r['d_m'])<=.45+1e-10]
K=sum(float(r['counts']) for r in ref)/sum(float(r['time_s'])/(float(r['d_m'])+delta)**2 for r in ref)
s=openpyxl.load_workbook(root/'task16_Book2_calculation.xlsx',data_only=True)['Book2 calculation'];a=np.array([[s.cell(i,j).value for j in (1,2,6,7)] for i in range(2,34)],float)
def omega_disc(r):
 z,w=roots_legendre(24);q=(z+1)/2;w=w/2;phi=2*np.pi*(np.arange(48)+.5)/48
 x=rs*np.sqrt(q)[:,None]*np.cos(phi)[None,:];y=rs*np.sqrt(q)[:,None]*np.sin(phi)[None,:]
 x1=-L/2-x;x2=L/2-x;y1=-L/2-y;y2=L/2-y
 def F(a,b,r):return np.arctan2(a*b,r*np.sqrt(r*r+a*a+b*b))
 return np.array([np.sum(w[:,None]*(F(x2,y2,v)-F(x1,y2,v)-F(x2,y1,v)+F(x1,y1,v)))/48 for v in r])
d=np.linspace(.01,.2,500);r=d+delta; g0=K*(d/r)**2;g2=K*omega_disc(r)/L**2*d**2;pct=100*(g2/g0-1)
points=a[(a[:,0]>=.01)&(a[:,0]<=.200001)]
plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42})
fig,(ax,bx)=plt.subplots(2,1,figsize=(7.8,7),sharex=True,gridspec_kw={'height_ratios':[2,1]},layout='constrained')
ax.errorbar(points[:,0]*100,points[:,2],xerr=points[:,1]*100,yerr=points[:,3],fmt='o',ms=4.7,capsize=2.6,color='#265b76',label='Raw data: latest three')
ax.plot(d*100,g0,'--',color='#d3592e',lw=2,label='G0: offset only');ax.plot(d*100,g2,'-',color='#008b72',lw=2,label='G2: finite source and square detector')
ax.set(ylabel=r'$Rd^2$ (m$^2$ s$^{-1}$)',title='Near-field data and geometrical models',ylim=(0,None));ax.legend(frameon=False,fontsize=9,loc='lower right')
bx.plot(d*100,pct,color='#008b72',lw=2);bx.axhline(0,color='#8b9296',lw=.8);bx.set(xlabel='Rail distance $d$ (cm)',ylabel=r'$(G2-G0)/G0$ (%)',xlim=(1,20),ylim=(-5.5,.5));
for a in [ax,bx]:a.grid(alpha=.2)
fig.savefig(out/'G0_G2_vs_data.png',dpi=250,bbox_inches='tight');fig.savefig(out/'G0_G2_vs_data.pdf',bbox_inches='tight')
print('K',K,'G2/G0 at 1 cm',pct[0])
