from pathlib import Path
import csv,numpy as np,openpyxl,matplotlib.pyplot as plt
from scipy.special import roots_legendre
out=Path(__file__).resolve().parent;root=out.parent/'sr90_research/results';L=.01;rs=.005;nominal=.01505;offsets=np.array([15.05,16,17.05,18,19.05,21,23])*1e-3
with (root/'raw_observations.csv').open(newline='') as f:rows=list(csv.DictReader(f))
ref=[z for z in rows if .30-1e-10<=float(z['d_m'])<=.45+1e-10]
z,w=roots_legendre(24);q=(z+1)/2;w=w/2;phi=2*np.pi*(np.arange(48)+.5)/48
xs=rs*np.sqrt(q)[:,None]*np.cos(phi)[None,:];ys=rs*np.sqrt(q)[:,None]*np.sin(phi)[None,:]
x1=-L/2-xs;x2=L/2-xs;y1=-L/2-ys;y2=L/2-ys
def omega(r):
 def f(a,b,v):return np.arctan2(a*b,v*np.sqrt(v*v+a*a+b*b))
 return np.array([np.sum(w[:,None]*(f(x2,y2,v)-f(x1,y2,v)-f(x2,y1,v)+f(x1,y1,v)))/48 for v in np.atleast_1d(r)])
refd=np.array([float(z['d_m']) for z in ref]);reft=np.array([float(z['time_s']) for z in ref]);refn=np.array([float(z['counts']) for z in ref]);K=refn.sum()/np.sum(reft*omega(refd+nominal)/L**2)
def model(d,offset):return K*omega(np.asarray(d)+offset)/L**2*np.asarray(d)**2
s=openpyxl.load_workbook(root/'task16_Book2_calculation.xlsx',data_only=True)['Book2 calculation'];a=np.array([[s.cell(i,j).value for j in (1,2,6,7)] for i in range(2,34)],float);a=a[(a[:,0]>=.01)&(a[:,0]<=.200001)]
dgrid=np.linspace(.01,.2,400);curve=np.array([model(dgrid,o) for o in offsets]);d=a[:,0];mu=np.array([model(d,o) for o in offsets]);g0=K*(d/(d+nominal))**2
with (out/'offset_sensitivity_results.csv').open('w',newline='') as f:
 wr=csv.writer(f);wr.writerow(['d_cm','data_Cd2','book2_unc','G0_nominal','G2_15.05mm','G2_16mm','G2_17.05mm','G2_18mm','G2_19.05mm','G2_21mm','G2_23mm','finite_geometry_change_pct','offset_min_vs_nominal_pct','offset_max_vs_nominal_pct','nominal_residual_pct','nominal_residual_book2_se_pct','point_inside_scenario_envelope'])
 for j,v in enumerate(d):wr.writerow([v*100,a[j,2],a[j,3],g0[j],*mu[:,j],100*(mu[0,j]/g0[j]-1),100*(mu[:,j].min()/mu[0,j]-1),100*(mu[:,j].max()/mu[0,j]-1),100*(a[j,2]/mu[0,j]-1),100*a[j,3]/mu[0,j],int(mu[:,j].min()<=a[j,2]<=mu[:,j].max())])
plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42})
fig,(ax,bx)=plt.subplots(2,1,figsize=(8,7),sharex=True,gridspec_kw={'height_ratios':[2,1]},layout='constrained');xx=dgrid*100
colors=['#009E73','#0072B2','#56B4E9','#8e6db0','#CC79A7','#E69F00','#D55E00'];styles=['-','--','-.',':','--','-.','--']
ax.fill_between(xx,curve.min(axis=0),curve.max(axis=0),color='#b8cbd1',alpha=.22,label='Scenario range (not confidence interval)')
for o,c,ls,v in zip(offsets,colors,styles,curve):ax.plot(xx,v,color=c,ls=ls,lw=2 if o==nominal else 1.3,label=fr'$\delta$ = {o*1000:g} mm')
ax.errorbar(a[:,0]*100,a[:,2],xerr=a[:,1]*100,yerr=a[:,3],fmt='o',ms=4.5,capsize=2.5,color='#222222',label='Raw data: last three')
ax.set(title='Sensitivity to source–detector distance offset',ylabel=r'$Rd^2$ (m$^2$ s$^{-1}$)',ylim=(0,None));ax.legend(frameon=False,ncol=2,fontsize=8,loc='lower right')
nom=curve[0];bx.fill_between(xx,100*(curve.min(axis=0)/nom-1),100*(curve.max(axis=0)/nom-1),color='#829fa8',alpha=.25,label='Offset scenarios vs nominal G2')
g0grid=K*(dgrid/(dgrid+nominal))**2;bx.plot(xx,100*(nom/g0grid-1),color='#b44b8a',lw=2,label='Finite geometry: G2 vs G0')
bx.errorbar(d*100,100*(a[:,2]/mu[0]-1),yerr=100*a[:,3]/mu[0],fmt='o',color='#222222',ms=4,capsize=2,label='Data vs nominal G2 (Book2 error)')
bx.axhline(0,color='#555555',lw=.8);bx.set(xlabel='Rail distance $d$ (cm)',ylabel='Difference (%)',xlim=(1,20));bx.legend(frameon=False,fontsize=8,loc='upper right')
for z in [ax,bx]:z.grid(alpha=.15)
fig.savefig(out/'offset_sensitivity.png',dpi=250,bbox_inches='tight');fig.savefig(out/'offset_sensitivity.pdf',bbox_inches='tight')
print('K =',K);print((out/'offset_sensitivity_results.csv').read_text())
