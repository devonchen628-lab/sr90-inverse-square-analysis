from pathlib import Path
import csv,json,os,subprocess,hashlib,concurrent.futures,time
p=Path(__file__).resolve().parent;root=p.parent.parent;runtime=Path('/Users/chenqiyue/Documents/Codex/2026-10-12/https-chatgpt-com-share-6acd35f5-5168/.runtime/geant4');src=root/'outputs/far_field_15mm_aligned/src'; data=root/'outputs/sr90_research/results/last_three.csv'
with data.open() as f:rows=list(csv.DictReader(f))
ds=[float(z['d_m']) for z in rows if 0.01-1e-9<=float(z['d_m'])<.3-1e-9]; assert len(ds)==12 and abs(ds[0]-.01)<1e-9 and abs(ds[-1]-.275)<1e-9
binary_air=root/'work/offset21_shift31/build/task16_sensitivity.app/Contents/MacOS/task16_sensitivity';binary_vac=root/'outputs/far_field_15mm_aligned/build/far15_vac'
env=os.environ.copy();env.pop('TASK16_GEOMETRY_VIEW',None);env.pop('TASK16_VIS_MACRO',None)
for k,n in [('G4LEDATA','EMLOW'),('G4LEVELGAMMADATA','PhotonEvaporation'),('G4RADIOACTIVEDATA','RadioactiveDecay'),('G4ENSDFSTATEDATA','ENSDFSTATE')]: env[k]=str(next((runtime/'share/Geant4/data').glob(n+'*')))
def sha(x):return hashlib.sha256(x.read_bytes()).hexdigest()
plan={'distances_m':ds,'offset_mm':15,'transverse_x_y_mm':[0,0],'source_recess_mm':6,'detector_recess_mm':3,'source_diameter_mm':22,'source_exit_diameter_mm':11,'detector_active_mm':[10,10,.3],'detector_opening_mm':[10,10],'threshold_keV':10,'air_batches':8,'air_source_histories_per_batch':400000,'air_replay_per_stage':16000,'vacuum_batches':12,'vacuum_source_histories_per_batch':1000000,'air_binary_sha256':sha(binary_air),'vacuum_binary_sha256':sha(binary_vac),'vacuum_source_sha256':sha(src/'geant_vacuum.cc'),'spectrum_sha256':sha(src/'spectra_unique.csv'),'vacuum_prefilter':'forward trajectory must intersect 30x30mm detector frame bounding box; all backward rays retained','uncertainty':'independent batch resampling; no geometry systematics'}
(p/'plan.json').write_text(json.dumps(plan,indent=2));print('Distances',len(ds),ds,flush=True)
def run(item):
 medium,i=item;seed=(1975000000 if medium=='air' else 1985000000)+i*100003;f=p/medium/f'batch_{i:02}.csv';log=f.with_suffix('.log');meta=f.with_suffix('.json');dtext=','.join(map(str,ds))
 if medium=='air':cmd=[str(binary_air),str(src/'spectra_unique.csv'),str(f),dtext,'400000','16000',str(seed),'11','5.5','smc','10','10','15','0','0']
 else:cmd=[str(binary_vac),str(src/'spectra_unique.csv'),str(f),dtext,'1000000',str(seed),'1']
 if meta.exists():assert json.loads(meta.read_text())['command']==cmd;print('Existing',medium,i,flush=True);return
 t=time.time()
 with log.open('w') as h: subprocess.run(cmd,env=env,stdout=h,stderr=subprocess.STDOUT,check=True)
 with f.open() as h:z=list(csv.DictReader(h))
 assert len(z)==6*len(ds),(medium,i,len(z))
 for r in z:
  if medium=='air':assert abs(float(r['active_distance_m'])-float(r['distance_m'])-.015)<1e-9 and float(r['height_mm'])==0 and float(r['lateral_x_mm'])==0
  else:assert abs(float(r['offset_m'])-.015)<1e-9
 text=log.read_text();assert not any(e in text for e in ['G4Exception','Overlap is detected','Fatal','ERROR'])
 meta.write_text(json.dumps({'command':cmd,'elapsed_s':time.time()-t,'seed':seed},indent=2));print(medium,'batch',i+1,'complete',round(time.time()-t),'s',flush=True)
items=[('air',i) for i in range(8)]+[('vacuum',i) for i in range(12)]
with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool:list(pool.map(run,items))
