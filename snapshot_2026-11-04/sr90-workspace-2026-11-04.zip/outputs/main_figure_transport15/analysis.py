from pathlib import Path
import json,numpy as np,pandas as pd,matplotlib.pyplot as plt
from scipy.special import roots_legendre
P=Path(__file__).resolve().parent;ROOT=P.parent;near=P;far=ROOT/'far_field_15mm_aligned';raw=pd.read_csv(ROOT/'sr90_research/results/last_three.csv');d=raw.d_m.to_numpy();n=raw.counts.to_numpy(float);t=raw.time_s.to_numpy();u=raw.raw_u.to_numpy();uerr=raw.book2_u_se.to_numpy();delta=.015;L=.01;rs=.011;tau=2e-6;sd=.0005

def load(path,medium,nb,ds):
 files=sorted((path/medium).glob('batch_*.csv')); assert len(files)==nb,(path,medium,len(files))
 rows=[]
 for f in files:
  z=pd.read_csv(f);z=z[z.threshold_keV==10];rows.append([z.loc[np.isclose(z.distance_m,x),'probability'].iloc[0] for x in ds])
 return np.array(rows)
near_d=d[d<.3-1e-9];far_d=d[d>=.3-1e-9]; assert len(near_d)==12 and len(far_d)==20
an=load(near,'air',8,near_d);vn=load(near,'vacuum',12,near_d);af=load(far,'air',8,far_d);vf=load(far,'vacuum',12,far_d)
T=np.r_[an.mean(axis=0)/vn.mean(axis=0),af.mean(axis=0)/vf.mean(axis=0)];anchor=len(near_d);Trel=T/T[anchor]
z,w=roots_legendre(32);w=w/2;phi=2*np.pi*(np.arange(64)+.5)/64;x=rs*np.sqrt((z+1)/2)[:,None]*np.cos(phi);y=rs*np.sqrt((z+1)/2)[:,None]*np.sin(phi);x1=-L/2-x;x2=L/2-x;y1=-L/2-y;y2=L/2-y
def solid(r):
 def f(a,b,v):return np.arctan2(a*b,v*np.sqrt(v*v+a*a+b*b))
 return np.array([np.sum(w[:,None]*(f(x2,y2,v)-f(x1,y2,v)-f(x2,y1,v)+f(x1,y1,v)))/64 for v in np.atleast_1d(r)])
def geom(ds):return solid(np.asarray(ds)+delta)/L**2
h=geom(d);ref=(d>=.2-1e-9)&(d<=.3+1e-9);ix=np.where(ref)[0]
# One K for all full and geometry-only predictions; nonparalyzable mean
# fitted to raw count totals at the five reference distances only.
def fitK(X,counts):
 X=np.atleast_2d(X);counts=np.atleast_2d(counts);tref=t[ix];k=np.sum(counts,axis=1)/np.sum(tref*X,axis=1)
 for _ in range(8):
  v=1+tau*k[:,None]*X
  score=np.sum(counts*(1/k[:,None]-tau*X/v)-tref*X/v**2,axis=1)
  hess=np.sum(-counts/k[:,None]**2+counts*(tau*X/v)**2+2*tref*tau*X**2/v**3,axis=1)
  k=np.maximum(.01,k-score/hess)
 return k
K=float(fitK((h*Trel)[ix],n[ix])[0]);rate_pre=K*h*Trel;rate=rate_pre/(1+tau*rate_pre);pred=rate*d**2;geom_only=K*h*d**2;ratio=(n/t)/rate;res=100*(ratio-1)
# Whole-batch bootstrap within each of four independent pools; use a common
# resampled 30-cm denominator and refit a common K from independently sampled
# reference counts. This retains normalization/reference correlations.
B=8000;rng=np.random.default_rng(183004);bn=an[rng.integers(0,8,(B,8))].mean(1);bvn=vn[rng.integers(0,12,(B,12))].mean(1);bf=af[rng.integers(0,8,(B,8))].mean(1);bvf=vf[rng.integers(0,12,(B,12))].mean(1)
bT=np.concatenate([bn/bvn,bf/bvf],axis=1);brel=bT/bT[:,anchor,None];nb=rng.poisson(n,size=(B,len(n)));bk=fitK((h*brel)[:,ix],nb[:,ix]);pre=bk[:,None]*h*brel;brate=pre/(1+tau*pre);bpred=brate*d*d;bres=100*((nb/t)/brate-1)
# Rail uncertainty: local analytic geometric response; numerical MC transfer
# distance derivative is not estimated (jagged sampled values).
eps=1e-6;dlnh=(np.log(geom(d+eps))-np.log(geom(d-eps)))/(2*eps);res_dsig=100*ratio*np.abs(dlnh/(1+tau*rate_pre))*sd
res_sigma=np.sqrt(bres.std(axis=0,ddof=1)**2+res_dsig**2);pred_sigma=bpred.std(axis=0,ddof=1)
# Effects are relative to explicitly stated comparison baselines, not additive.
Ti_sd=brel.std(axis=0,ddof=1)
effect_rows=[]
for wanted in [.01,.85]:
 i=int(np.where(np.isclose(d,wanted))[0][0]);geom_rel=h[i]*(d[i]+delta)**2
 effect_rows.append({'d_cm':d[i]*100,'offset_factor_d2_over_r2':(d[i]/(d[i]+delta))**2,'finite_geometry_pct_vs_point':100*(geom_rel-1),'dead_time_loss_pct':100*(1-1/(1+tau*rate_pre[i])),'air_response_relative_to_30cm_pct':100*(Trel[i]-1),'air_response_relative_to_30cm_MC_se_pct':100*Ti_sd[i]})
pd.DataFrame(effect_rows).to_csv(P/'effect_sizes.csv',index=False)
out=pd.DataFrame({'d_cm':d*100,'N':n,'time_s':t,'observed_Rd2':u,'observed_book2_unc':uerr,'T_air_over_vacuum':T,'T_relative_30cm':Trel,'geometry_only_Rd2':geom_only,'full_model_Rd2':pred,'full_model_conditional_unc':pred_sigma,'residual_pct':res,'residual_conditional_unc_pct':res_sigma});out.to_csv(P/'model_comparison_points.csv',index=False)
np.savez_compressed(P/'model_covariance.npz',distance_cm=d*100,model=np.cov(bpred,rowvar=False),residual_pct=np.cov(bres,rowvar=False)+np.diag(res_dsig**2))
info={'reference_cm':[20,30],'ref_points_cm':list(d[ix]*100),'K':K,'offset_mm':15,'detector_square_mm':10,'assumed_source_radius_mm':11,'source_radius_not_measured':True,'deadtime_model':'nonparalyzable, tau=2 us (illustrative)','Geant4_threshold_keV':10,'Geant4_air_batches_near_far':[8,8],'Geant4_vacuum_batches_near_far':[12,12],'normalization':'joint count Poisson likelihood 20–30 cm latest-three groups; T/T30; same K for both curves','approximation':'geometry * relative air/vacuum response; assumes separable effective response; unvalidated source/encapsulation and threshold; includes no background','uncertainty':'bootstrap 8000 whole runs independently by medium and near/far, common T30, refit K using resampled reference counts; residual bars also include Poisson data and geometric rail sigma 0.5mm; omits MC-transfer local distance derivative, offset common uncertainty, tau, source geometry, threshold, background, repeatability','caveat':'Reference normalization shares data with 20–30 cm residuals; all points correlated. Bootstrap is conditional on the chosen Geant4 and geometry. Curves connect calculated points, not dense simulations.'}
(P/'summary.json').write_text(json.dumps(info,indent=2))
plt.rcParams.update({'font.size':10,'font.family':'DejaVu Sans','axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42})
fig,(ax,bx)=plt.subplots(2,1,figsize=(8,7.2),sharex=True,gridspec_kw={'height_ratios':[2.1,1]},layout='constrained')
ax.errorbar(d*100,u,xerr=sd*100,yerr=uerr,fmt='o',ms=4,capsize=2.1,elinewidth=.75,color='#20282f',label='Measured $Rd^2$ (Book2 errors)',zorder=5)
ax.plot(d*100,geom_only,'--',color='#8b9296',lw=1.5,label='Geometry only (same K)')
ax.plot(d*100,pred,'-',color='#155c86',lw=2,label='Geometry + dead time + Geant4 air')
ax.fill_between(d*100,pred-pred_sigma,pred+pred_sigma,color='#155c86',alpha=.16,label='Model: conditional MC + scale uncertainty')
ax.set(ylabel=r'$Rd^2$ (m$^2$ s$^{-1}$)',title='Physical interpretation of inverse-square deviations',ylim=(0,None));ax.legend(frameon=False,fontsize=8.4,loc='lower right')
bx.errorbar(d*100,res,xerr=sd*100,yerr=res_sigma,fmt='o',ms=3.8,capsize=2,elinewidth=.75,color='#155c86');bx.axhline(0,color='#666666',lw=.9);bx.set(xlabel='Rail distance $d$ (cm)',ylabel='(Data − model) / model (%)',xlim=(0,87));
for a in [ax,bx]:a.grid(alpha=.15)
fig.savefig(P/'physical_interpretation.png',dpi=300,bbox_inches='tight');fig.savefig(P/'physical_interpretation.pdf',bbox_inches='tight')
print(json.dumps(info,indent=2));print(out.iloc[[0,1,2,5,8,12,20,31]][['d_cm','T_relative_30cm','observed_Rd2','full_model_Rd2','residual_pct','residual_conditional_unc_pct']].to_string(index=False))
