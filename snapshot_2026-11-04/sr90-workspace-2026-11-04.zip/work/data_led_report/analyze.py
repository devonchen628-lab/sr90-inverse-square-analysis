from pathlib import Path
import json,sys,csv
import numpy as np
from scipy.special import ndtr
from scipy.stats import chi2
from scipy.interpolate import PchipInterpolator
ROOT=Path('/Users/chenqiyue/Documents/Codex/2026-10-29/r'); W=ROOT/'work/data_led_report';P=ROOT/'output/pdf/radioactivity_reframed';O=ROOT/'outputs/task16_data_led_report';O.mkdir(exist_ok=True)
data=json.loads((ROOT/'outputs/task16_last_three_book2/calculation_details.json').read_text());q=data['points'];d=np.array([x['d_m'] for x in q]);N=np.array([x['total_counts'] for x in q]);tm=np.array([x['total_time_s'] for x in q]);raw=N/tm;rawse=np.sqrt(N)/tm; sigma_d=.0005;r=d+.021;tau=1.9987336691853628e-6;stau=.02080681023026314e-6;b=8/60;sb=np.sqrt(8)/60
C=raw/(1-tau*raw)-b/(1-tau*b);eind=rawse/(1-tau*raw)**2; db=-sb/(1-tau*b)**2;dt=stau*(raw**2/(1-tau*raw)**2-b*b/(1-tau*b)**2); VC=np.diag(eind**2)+np.outer(db*np.ones(len(d)),db*np.ones(len(d)))+np.outer(dt,dt);Vy=VC/np.outer(C,C)
u=raw*d*d;su=u*np.sqrt(1/N+(2*sigma_d/d)**2);uc=C*r*r;suc=np.sqrt((r*r)**2*np.diag(VC)+(2*r*C*sigma_d)**2)
Z=np.load(ROOT/'output/pdf/radioactivity_report/data/G2_model.npz');md=Z['d_m'];prob=Z['probability'];vp=Z['probability_covariance'];idx=np.array([np.where(np.isclose(d,x))[0][0] for x in md]);w=np.array([0]*5+[1/3]*3);H=np.eye(8)-np.outer(np.ones(8),w);amp=np.exp(w@(np.log(C[idx])-np.log(prob)));ratio=C[idx]/(amp*prob);grad=PchipInterpolator(np.log(md+.021),np.log(prob)).derivative()(np.log(md+.021))/(md+.021);V=Vy[np.ix_(idx,idx)]+vp/np.outer(prob,prob)+np.diag((grad*sigma_d)**2);ratiose=ratio*np.sqrt(np.diag(H@V@H.T)); pred=amp*prob;predraw=(pred+b/(1-tau*b))/(1+tau*(pred+b/(1-tau*b)));pred_u=predraw*md**2;pred_raw_MC_err=amp*np.sqrt(np.diag(vp))/(1+tau*(pred+b/(1-tau*b)))**2*md**2
# Matched-medium comparison; 8 actually simulated distances.
air=json.loads((ROOT/'outputs/task16_air_correction/summary.json').read_text());T=np.array([x['air_over_vacuum'] for x in air['knots']]);tse=np.array([x['air_over_vacuum_MC_se'] for x in air['knots']]);assert np.allclose(md*100,[x['d_cm'] for x in air['knots']]);
# Compare low-dimensional, distance windows: conditional fit, not prespecified.
fits={}
for low,high in [(.15,.3),(.20,.30),(.30,.50)]:
 mask=(d>=low-1e-9)&(d<=high+1e-9);y=uc[mask];s=suc[mask]; ww=1/s**2; k=float(np.sum(ww*y)/sum(ww));stat=float(sum(((y-k)/s)**2));df=int(mask.sum()-1);fits[f'{low:g}–{high:g}m']=dict(K=k,se=float(1/np.sqrt(sum(ww))),chi2=stat,df=df,p=float(chi2.sf(stat,df)),n=len(y))
# Exact on-axis solid angle of 10mm square. Geometric acceptance compared to area/r^2.
# Stable algebra with atan2.
a=.005; g=lambda dist: 4*np.arctan2(a*a,dist*np.sqrt(dist*dist+2*a*a))/(.01*.01/dist**2)
raw_near_geometry_ratio=float(g(.01));true_near_geometry_ratio=float(g(.031))
repeat55=next(x for x in q if abs(x['d_m']-.55)<1e-9);u75=next(x for x in q if abs(x['d_m']-.75)<1e-9)
# vacuum-equivalent inferred products are counterfactual and depend on unvalidated T.
k30=np.where(np.isclose(d,.3))[0][0];k85=np.where(np.isclose(d,.85))[0][0];v30=float(uc[k30]/T[5]);v85=float(uc[k85]/T[7]);
# proxy only, conditional on ideal isotropic beta flux and 100% efficiency, no transport: sr+y emission rate
fit=fits['0.2–0.3m'];k=fit['K'];area=.01*.01;apparent=4*np.pi*k/area
out={'inputs':'last three records by worksheet row per distance; Book2 Poisson + sigma_d=0.5mm','N':int(N.sum()),'obs':len(q)*3,'dcm':(d*100).tolist(),'near_raw':dict(u=float(u[0]),se=float(su[0]),raw_rate=float(raw[0]),corrected_rate=float(C[0]),correction_pct=float((C[0]/raw[0]-1)*100)), 'near_point_source_square_geometry_factor_actual31mm':true_near_geometry_ratio,'square_geometry_factor_at_rail10mm_not_actual_separation':raw_near_geometry_ratio,'ratio_rail_vs_active_nearest':(.01/.031)**2,'background_effect85_u':float(b*.85**2),'u85_raw':float(u[-1]),'matches':{'distances_cm':(md*100).tolist(),'ratio':ratio.tolist(),'se':ratiose.tolist(),'normalization':float(amp),'normalization_conditional_se':float(amp*np.sqrt(w@V@w)),'pred_raw_u':pred_u.tolist(),'sim_mc_fixed_normalization_se':pred_raw_MC_err.tolist()},'air':{'T30':float(T[5]),'T85':float(T[7]),'T30_se':float(tse[5]),'T85_se':float(tse[7]),'T85_over_T30':air['T85_div_T30'],'T85_over_T30_se':air['T85_div_T30_bootstrap_se'],'vacuum_equivalent_u30':v30,'vacuum_equivalent_u85':v85},'repeat55':{'counts':[x['counts'] for x in repeat55['selected_records']],'time_s':[x['exposure_s'] for x in repeat55['selected_records']],'Q':repeat55['pearson_Q'],'p':float(chi2.sf(repeat55['pearson_Q'],2))},'window_fits_conditional':fits,'apparent_emission_rate_per_s_20_to_30cm':float(apparent),'proxy_warning':'Not calibrated Sr-90 activity; ignores energy response, air transport, source encapsulation and Sr/Y branching; window chosen after viewing data.'}
(O/'analysis_summary.json').write_text(json.dumps(out,indent=2)+'\n')
with (O/'last_three_analysis.csv').open('w',newline='') as f:
 rows=[{'d_m':float(d[i]),'total_counts':int(N[i]),'time_s':float(tm[i]),'raw_rate_cps':float(raw[i]),'raw_u':float(u[i]),'book2_u_uncertainty':float(su[i]),'corrected_rate_cps':float(C[i]),'active_separation_m':float(r[i]),'corrected_u':float(uc[i]),'corrected_u_uncertainty_conditional':float(suc[i])} for i in range(len(d))];writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':8,'axes.labelsize':8,'xtick.labelsize':7,'ytick.labelsize':7,'legend.fontsize':6.8,'axes.spines.right':False,'axes.spines.top':False})
fig,ax=plt.subplots(figsize=(3.4,2.5),layout='constrained');ax.errorbar(d*100,u,yerr=su,fmt='o',color='#1d668b',ms=2.8,elinewidth=.6,capsize=1,label='Data: last three repeats');ax.errorbar(md*100,pred_u,yerr=pred_raw_MC_err,fmt='s',mfc='white',mew=.8,color='#be572e',ms=3.8,elinewidth=.7,capsize=1,label='Geant4: fixed far-point scale');ax.axhline(u[np.where(np.isclose(d,.3))[0][0]],ls='--',color='#77828b',lw=.8,label='Constant through 30 cm (guide)');ax.set(xlim=(0,90),ylim=(0,15.5),xlabel='Recorded rail distance $d$ (cm)',ylabel=r'$C_{\rm raw}d^2$ (m$^2$ s$^{-1}$)');ax.legend(frameon=False,loc='lower right',handlelength=1.1);ax.grid(alpha=.15);fig.savefig(P/'images/data_led_measurement.png',dpi=400,bbox_inches='tight');plt.close(fig)
fig,ax=plt.subplots(figsize=(3.4,2.0),layout='constrained');ax.errorbar(md*100,T,yerr=tse,fmt='o',ms=3.3,capsize=1.4,color='#8f611d',elinewidth=.8);ax.axhline(1,color='#777',ls='--',lw=.8);ax.set(xlim=(0,90),ylim=(0,1.12),xlabel='Recorded rail distance $d$ (cm)',ylabel='Simulated air / vacuum');ax.grid(alpha=.16);fig.savefig(P/'images/data_led_air.png',dpi=400,bbox_inches='tight');plt.close(fig)
print(json.dumps(out,indent=2))
