// User-requested sensitivity scenario; original recessed model remains unchanged.
// Detector and entrance frame translated together in y; no rotations.
// Defaults: axial active-plane offset19mm and transverse center displacement3mm.
#include "smc_reuse_base.cc"
#include <chrono>
#include "G4VisExecutive.hh"
#include "G4UIExecutive.hh"
#include "G4UImanager.hh"
#include "G4VisAttributes.hh"
#include <QDir>
#include <QPluginLoader>
#include <QDebug>
#include <QLibrary>
#include <QtCore/qplugin.h>

struct PPTModel { double axial_offset_mm=19,lateral_shift_mm=3; SMC c; double aperture_mm=5.5; double detector_opening_w_mm=10,detector_opening_h_mm=10; };
class PPTGeometry:public G4VUserDetectorConstruction {
 PPTModel& a;
 public:explicit PPTGeometry(PPTModel& x):a(x){}
 G4VPhysicalVolume* Construct() override {
  auto& c=a.c;auto n=G4NistManager::Instance();auto air=n->FindOrBuildMaterial("G4_AIR");double W=c.world_half*m;
  auto world=new G4LogicalVolume(new G4Box("World",W,W,W),air,"World");
  world->SetVisAttributes(G4VisAttributes::GetInvisible());
  auto pv=new G4PVPlacement(nullptr,{},world,"World",nullptr,false,0,true);
  auto al=n->FindOrBuildMaterial("G4_Al"),pmma=n->FindOrBuildMaterial("G4_PLEXIGLASS");
  auto box=[&](const G4String& name,double t,double z,G4Material* mat){
   auto lv=new G4LogicalVolume(new G4Box(name,25*mm,25*mm,t/2),mat,name);
   lv->SetVisAttributes(new G4VisAttributes(name=="SourceAcrylic"?G4Colour(.9,.65,.2,.7):G4Colour(.55,.6,.7,.65)));
   new G4PVPlacement(nullptr,{0,0,z},lv,name,world,false,0,true);
  };
  box("SourceAlFoil",.05*mm,.275*mm,al);box("SourceAcrylic",1*mm,.8*mm,pmma);
  auto tb=new G4Box("TopPlateBox",25*mm,25*mm,1.85*mm);
  auto hole=new G4Tubs("ExitHole",0,a.aperture_mm*mm,1.95*mm,0,twopi);
  auto top=new G4LogicalVolume(new G4SubtractionSolid("TopWithHole",tb,hole),al,"SourceTopPlate");
  top->SetVisAttributes(new G4VisAttributes(G4Colour(.2,.45,.85,.7)));
  new G4PVPlacement(nullptr,{0,0,3.15*mm},top,"SourceTopPlate",world,false,0,true);
  box("SourceBacking",1.5*mm,-1*mm,al);
  auto mother=world;double previous=0;
  for(unsigned i=0;i<c.planes.size();++i){
   double z=c.planes[i]*m,centre=(W+z)/2;auto name="Phase_"+std::to_string(i);
   auto lv=new G4LogicalVolume(new G4Box(name,W,W,(W-z)/2),air,name);
   lv->SetVisAttributes(G4VisAttributes::GetInvisible());
   new G4PVPlacement(nullptr,{0,0,centre-previous},lv,name,mother,false,0,true);
   mother=lv;previous=centre;
  }
  // The final phase checkpoint is upstream of this entire frame.
  // Opening and material are explicit unmeasured review assumptions.
  auto frameBox=new G4Box("DetectorFrameBox",15*mm,15*mm,1*mm);
  auto entry=new G4Box("DetectorEntrance",a.detector_opening_w_mm*.5*mm,a.detector_opening_h_mm*.5*mm,1.01*mm);
  auto frame=new G4LogicalVolume(new G4SubtractionSolid("DetectorFrameWithOpening",frameBox,entry),al,"DetectorEntranceFrame");
  frame->SetVisAttributes(new G4VisAttributes(G4Colour(.35,.65,.75,.7)));
  new G4PVPlacement(nullptr,{0,a.lateral_shift_mm*mm,c.r*m-1*mm-previous},frame,"DetectorEntranceFrame",mother,false,0,true);
  auto si=new G4LogicalVolume(new G4Box("Silicon",5*mm,5*mm,.15*mm),n->FindOrBuildMaterial("G4_Si"),"Silicon");
  si->SetVisAttributes(new G4VisAttributes(G4Colour(.2,.85,.35,1)));
  new G4PVPlacement(nullptr,{0,a.lateral_shift_mm*mm,c.r*m+.15*mm-previous},si,"Silicon",mother,false,0,true);
  return pv;
 }
};

int main(int argc,char** argv){
 if(argc<9){std::cerr<<"spectrum output distances nsource npop seed emitter_radius_mm aperture_radius_mm [smc|direct] [detector_opening_w_mm] [detector_opening_h_mm] [axial_offset_mm] [lateral_shift_mm]\n";return 2;}
 PPTModel a;auto& c=a.c;c.nsource=std::stol(argv[4]);c.npop=std::stol(argv[5]);long seed=std::stol(argv[6]);
 c.source.radius_mm=std::stod(argv[7]);a.aperture_mm=std::stod(argv[8]);bool direct=argc>9&&std::string(argv[9])=="direct";
 // The legacy 4.875mm focus disk is an importance proposal only. Its exact
 // density correction is retained; it does not define this geometry's hole.
 if(argc>10)a.detector_opening_w_mm=std::stod(argv[10]);
 if(argc>11)a.detector_opening_h_mm=std::stod(argv[11]);
 if(argc>12)a.axial_offset_mm=std::stod(argv[12]);
 if(argc>13)a.lateral_shift_mm=std::stod(argv[13]);
 if(a.axial_offset_mm<7||std::abs(a.lateral_shift_mm)>100)throw std::runtime_error("Invalid displacement");
 if(a.detector_opening_w_mm<=0||a.detector_opening_h_mm<=0||a.detector_opening_w_mm>=30||a.detector_opening_h_mm>=30)throw std::runtime_error("Invalid detector opening");
 if(c.source.radius_mm<4.875||a.aperture_mm<=0)throw std::runtime_error("Invalid PPT geometry/proposal support");
 c.source.source_case=true;c.source.smooth_importance=true;c.source.position_mix=.6;
 c.source.y_importance_cutoff=500;c.source.sr_sampling_fraction=.5;c.source.cut_mm=.01;
 c.planes={.005001};c.r=.9;c.uniform_mix=.1;c.tail_importance=1;
 std::ifstream spec(argv[1]);std::string line;std::getline(spec,line);
 while(std::getline(spec,line)){std::replace(line.begin(),line.end(),',',' ');std::istringstream f(line);int b;double E,F;f>>b>>E>>F;c.source.energy[b].push_back(E);c.source.cdf[b].push_back(F);}
 std::vector<double> ds;std::istringstream dl(argv[3]);while(std::getline(dl,line,','))ds.push_back(std::stod(line));
 if(direct&&ds.size()!=1)throw std::runtime_error("Direct validation uses one distance per process");
 auto planes=[&](double d){c.r=d+a.axial_offset_mm*.001;double z=.005001,last=c.r-.002001;c.planes={z};for(double f:{.25,.5,.75,.9})c.planes.push_back(z+f*(last-z));c.planes.push_back(last);};
 if(direct)planes(ds[0]);
 auto rm=new G4RunManager;G4Random::setTheSeed(seed);
 rm->SetUserInitialization(new PPTGeometry(a));rm->SetUserInitialization(new Physics(.01));
 rm->SetUserAction(new SMCGenerator(c));rm->SetUserAction(new SMCEvents(c));rm->SetUserAction(new SMCSteps(c));rm->SetUserAction(new SMCBoundaryBirths(c));
 G4EmParameters::Instance()->SetStepFunction(.1,10*um);rm->Initialize();
 if(std::getenv("TASK16_GEOMETRY_VIEW")){
  auto pp=QString::fromLocal8Bit(std::getenv("QT_QPA_PLATFORM_PLUGIN_PATH"));
  qWarning()<<"QT_DIRECTORY"<<pp<<QDir(pp).entryList(QDir::Files);
  QPluginLoader platform(pp+"/libqcocoa.dylib");
  qWarning()<<"QT_COCOA_METADATA"<<platform.metaData();
  qWarning()<<"QT_COCOA_LOAD"<<platform.load()<<platform.errorString();
  // Register this known local vendor plugin explicitly when Qt's directory
  // enumeration fails; no change to system Qt or security settings.
  QLibrary cocoa(pp+"/libqcocoa.dylib");
  auto instance=reinterpret_cast<QtPluginInstanceFunction>(cocoa.resolve("qt_plugin_instance"));
  auto metadata=reinterpret_cast<QtPluginMetaDataFunction>(cocoa.resolve("qt_plugin_query_metadata_v2"));
  if(!instance||!metadata)throw std::runtime_error("Cannot register local Cocoa plugin");
  qRegisterStaticPluginFunction(QStaticPlugin(instance,metadata));
  int ac=1;char* av[]={argv[0],nullptr};
  auto ui=new G4UIExecutive(ac,av,"Qt");
  auto vis=new G4VisExecutive("warnings");vis->Initialize();
  auto manager=G4UImanager::GetUIpointer();
  auto macro=std::getenv("TASK16_VIS_MACRO");
  if(macro){auto code=manager->ApplyCommand(G4String("/control/execute ")+macro);if(code!=0)std::cerr<<"VIS_MACRO_STATUS "<<code<<std::endl;}
  ui->SessionStart();delete vis;delete ui;delete rm;return 0;
 }
 std::cout<<"RECESS_REVIEW source_depth_mm=5 source_wall_mm=3.7 detector_depth_mm=2 detector_opening_mm="<<a.detector_opening_w_mm<<"x"<<a.detector_opening_h_mm<<" active_offset_mm="<<a.axial_offset_mm<<" lateral_shift_mm="<<a.lateral_shift_mm<<" frame_material=G4_Al_assumed"<<std::endl;
 auto start=std::chrono::steady_clock::now();std::vector<History> bank;
 if(!direct){c.stage=0;rm->BeamOn(c.nsource);bank=std::move(c.next);for(auto& h:bank)h.weight/=c.nsource;
  std::cout<<"SOURCE_BANK "<<bank.size()<<" original_events "<<c.nsource<<" elapsed_s "<<std::chrono::duration<double>(std::chrono::steady_clock::now()-start).count()<<std::endl;}
 std::ofstream out(argv[2]);out<<std::setprecision(15)<<"distance_m,active_distance_m,threshold_keV,probability,direct_se,nsource,npop,seed,emitter_diameter_mm,aperture_diameter_mm,detector_side_mm,source_yaw_deg,detector_yaw_deg,height_mm,mode\n";
 for(unsigned di=0;di<ds.size();++di){
  double d=ds[di];planes(d);c.score={};c.score_square={};
  if(direct){c.stage=-1;rm->BeamOn(c.nsource);}
  else {
   c.population=bank;c.stage=1;G4Random::setTheSeed(seed+1000000+di*10007);rm->ReinitializeGeometry(true);rm->Initialize();
   for(unsigned stage=1;stage<=c.planes.size();++stage){
    c.stage=stage;c.next.clear();if(c.population.empty())break;
    double total=0,focused=0;std::vector<double> focus;
    for(const auto& h:c.population){double v=importance(h,c);focus.push_back(v);total+=h.weight;focused+=h.weight*v;}
    c.selection.clear();c.cdf.clear();double sum=0;
    for(unsigned j=0;j<c.population.size();++j){double q=c.uniform_mix*c.population[j].weight/total+(1-c.uniform_mix)*c.population[j].weight*focus[j]/focused;c.selection.push_back(q);sum+=q;c.cdf.push_back(sum);}
    c.cdf.back()=1;rm->BeamOn(c.npop);
    if(stage<c.planes.size()){for(auto& h:c.next)h.weight/=c.npop;c.population=std::move(c.next);}
   }
  }
  double N=direct?c.nsource:c.npop;
  for(unsigned j=0;j<c.score.size();++j){
   double p=c.score[j]/N,se=direct?std::sqrt(std::max(0.,c.score_square[j]-c.score[j]*c.score[j]/N)/(N*(N-1))):0;
   out<<d<<','<<c.r<<','<<c.source.thresholds[j]<<','<<p<<','<<se<<','<<c.nsource<<','<<c.npop<<','<<seed<<','<<2*c.source.radius_mm<<','<<2*a.aperture_mm<<",10,0,0,"<<a.lateral_shift_mm<<","<<(direct?"direct":"smc")<<'\n';
  }
  out.flush();std::cout<<"DONE d "<<d<<" P10 "<<c.score[2]/N<<" elapsed_s "<<std::chrono::duration<double>(std::chrono::steady_clock::now()-start).count()<<std::endl;
 }
 delete rm;return 0;
}
