"""Extract Task16 records, select the closest three, then plot saved CSVs."""
from pathlib import Path
import csv
import hashlib
import itertools
import json
import math
import sys

ROOT = Path('/Users/chenqiyue/Documents/Codex/2026-10-29/r')
SOURCE = Path('/Users/chenqiyue/Library/CloudStorage/OneDrive-ImperialCollegeLondon/Radlab/task 16 data.xlsx')
BASE = Path('/Users/chenqiyue/Documents/Codex/2026-10-12/https-chatgpt-com-share-6acd35f5-5168/outputs/task16_geant4')
OUT = ROOT / 'outputs/task16_closest_three'


def csv_rows(path):
    with path.open(newline='', encoding='utf-8-sig') as f:
        return list(csv.DictReader(f))


def write_csv(path, rows):
    with path.open('w', newline='', encoding='utf-8-sig') as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)


def extract():
    import openpyxl
    OUT.mkdir(exist_ok=True, parents=True)
    original_hash = hashlib.sha256(SOURCE.read_bytes()).hexdigest()
    ws = openpyxl.load_workbook(SOURCE, data_only=True, read_only=True).active
    raw = []
    d = sd = None
    group = 0
    after_blank = True
    for rn, row in enumerate(ws.iter_rows(values_only=True), 1):
        if rn == 1:
            continue
        def num(value):
            return None if value is None else float(str(value).strip())
        new_d, n, t = num(row[0]), num(row[2]), num(row[4])
        if new_d is not None:
            d, sd = new_d, num(row[1])
            group, after_blank = 0, True
        if n is None:
            after_blank = True
            continue
        if after_blank:
            group += 1
        after_blank = False
        assert d is not None and sd is not None and n >= 0 and n.is_integer() and t > 0
        raw.append(dict(source_sheet=ws.title, source_row=rn, d_m=d,
                        d_unc_m=sd, measurement_group=group,
                        counts=int(n), time_s=t, rate_cps=n/t))
    mc_path = BASE / 'results/book2_dense_comparison/model_data_comparison_32.csv'
    mc = {float(r['d_m']): r for r in csv_rows(mc_path)}
    fit = json.loads((BASE / 'results/book2_dense_comparison/fit_summary.json').read_text())
    report = next(r for r in fit['reports'] if r['threshold_keV'] == 10)
    A = report['normalization']
    tau = fit['effective_recovery_us'] * 1e-6
    B = fit['background_rate']
    selected_rows = set()
    processed = []
    for distance in sorted({r['d_m'] for r in raw}):
        rr = [r for r in raw if r['d_m'] == distance]
        assert len(rr) in (3, 6)
        assert len({r['time_s'] for r in rr}) == 1, 'Equal times required for count/rate averaging equivalence.'
        def key(combo):
            # Equal exposures make count and rate rankings identical. Integer
            # arithmetic preserves exact ties in range and variance.
            counts = [r['counts'] for r in combo]
            total = sum(counts)
            return max(counts)-min(counts), sum((3*x-total)**2 for x in counts), tuple(r['source_row'] for r in combo)
        chosen = min(itertools.combinations(rr, 3), key=key)
        chosen = sorted(chosen, key=lambda r: r['source_row'])
        selected_rows.update(r['source_row'] for r in chosen)
        N = sum(r['counts'] for r in chosen)
        T = sum(r['time_s'] for r in chosen)
        C = N/T
        assert math.isclose(C, sum(r['rate_cps'] for r in chosen)/3, rel_tol=1e-13)
        sC = math.sqrt(N)/T
        sd = rr[0]['d_unc_m']
        rates = [r['rate_cps'] for r in chosen]
        model = mc[distance]
        pred = float(model['predicted_observed_rate'])
        predse = float(model['predicted_MC_se'])
        p = float(model['probability'])
        ideal = A*p+B/(1-tau*B)
        assert math.isclose(pred, ideal/(1+tau*ideal), rel_tol=1e-12)
        ratio = C/pred
        item = dict(d_m=distance, d_unc_m=sd, r_m=distance+fit['offset_m'],
                    n_available=len(rr), n_selected=3,
                    selected_source_rows=';'.join(str(r['source_row']) for r in chosen),
                    counts_total=N, time_total_s=T, mean_rate_cps=C,
                    nominal_poisson_rate_se_cps=sC,
                    selected_rate_range_cps=max(rates)-min(rates),
                    selected_rate_sample_sd_cps=math.sqrt(sum((x-C)**2 for x in rates)/2),
                    Cd2_m2_per_s=C*distance**2,
                    nominal_Cd2_se_m2_per_s=math.hypot(distance**2*sC, 2*C*distance*sd),
                    geant4_predicted_observed_rate_cps=pred,
                    geant4_MC_rate_se_cps=predse,
                    geant4_Cd2_m2_per_s=pred*distance**2,
                    measured_over_geant4=ratio,
                    nominal_ratio_se_counting_and_MC=ratio*math.hypot(sC/C, predse/pred))
        processed.append(item)
    assert len(processed) == 32 and len(raw) == 141 and len(selected_rows) == 96
    for r in raw:
        r['selected_for_plot'] = int(r['source_row'] in selected_rows)
    # Save both data products BEFORE plotting; the plotting phase re-reads these CSVs.
    write_csv(OUT / 'task16_all_measurements.csv', raw)
    write_csv(OUT / 'task16_selected_three.csv', processed)
    provenance = dict(source=str(SOURCE), source_sha256=original_hash,
        source_sheet=ws.title, raw_observations=len(raw), distances=len(processed),
        six_measurement_distances=sum(r['n_available']==6 for r in processed),
        selected_observations=len(selected_rows),
        selection='For each distance enumerate all triples. Minimize max(rate)-min(rate); ties: minimum sum of squared deviations; then earliest source-row tuple. Keep all measurements when only three exist. Selection can mix pre-return and post-return groups.',
        averaging='Equal individual exposures verified at each distance; arithmetic mean of three rates equals selected total counts / selected total exposure.',
        model_csv=str(mc_path), model_csv_sha256=hashlib.sha256(mc_path.read_bytes()).hexdigest(),
        model_normalization=A, normalization_refitted=False, offset_m=fit['offset_m'],
        threshold_keV=10, effective_recovery_us=fit['effective_recovery_us'],
        error_scope='Nominal Poisson and ruler errors for top data bars; nominal Poisson and MC errors for ratio bars. Selection bias, repositioning variation, normalization uncertainty and unmeasured apparatus systematics are excluded. MC band is fixed-normalization sampling SE only.',
        fit_statistics='No formal goodness-of-fit or p-value reported for the selected subset.',
        simulation_rerun=False)
    (OUT / 'processing_details.json').write_text(json.dumps(provenance, indent=2)+'\n')
    assert hashlib.sha256(SOURCE.read_bytes()).hexdigest() == original_hash
    print(json.dumps({'raw_records':len(raw), 'distance_points':len(processed),
        'six_measurement_distances':provenance['six_measurement_distances'],
        'normalization_held_fixed':A,
        'selected_examples':[r for r in processed if r['d_m'] in (.175,.2,.25,.275,.75)]},indent=2))


def plot():
    import numpy as np
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    # Plot only the just-saved CSV, rather than reusing in-memory extracted values.
    data = csv_rows(OUT / 'task16_selected_three.csv')
    def arr(key):
        return np.array([float(r[key]) for r in data])
    d, sd, u, su = [arr(k) for k in ['d_m','d_unc_m','Cd2_m2_per_s','nominal_Cd2_se_m2_per_s']]
    pred = arr('geant4_Cd2_m2_per_s')
    mcse = arr('geant4_MC_rate_se_cps')*d*d
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,'axes.spines.top':False,'axes.spines.right':False})
    fig, axes = plt.subplots(2, 1, figsize=(10.5,8), sharex=True,
        gridspec_kw={'height_ratios':[2.1,1]}, layout=None)
    fig.subplots_adjust(left=.095,right=.98,bottom=.13,top=.87,hspace=.12)
    fig.suptitle('Task 16: Geant4 versus selected measurements',fontsize=16,y=.97)
    fig.text(.5,.925,'Closest 3 of 6; all 3 otherwise  |  32 distances  |  Previous Geant4 normalization held fixed',ha='center',fontsize=10)
    axes[0].fill_between(d,pred-mcse,pred+mcse,color='#359b46',alpha=.2,label=r'Geant4 MC sampling SE ($1\sigma$)')
    axes[0].plot(d,pred,'o-',color='#29913d',lw=1.7,ms=3,label='Geant4 prediction')
    axes[0].errorbar(d,u,xerr=sd,yerr=su,fmt='o',color='#202020',ms=4,capsize=3,label='Selected measurements: mean of 3',zorder=5)
    axes[0].set_ylabel(r'$C d^2$ (m$^2$ s$^{-1}$)')
    axes[0].legend(loc='lower right',fontsize=9,framealpha=.94)
    axes[1].errorbar(d,arr('measured_over_geant4'),yerr=arr('nominal_ratio_se_counting_and_MC'),
        fmt='o',color='#286a9f',ms=4,capsize=3)
    axes[1].axhline(1,color='#777777',lw=1)
    axes[1].set_ylabel('Selected data / Geant4')
    axes[1].set_xlabel('Rail gap d (m)')
    for ax in axes:
        ax.grid(alpha=.18)
    axes[1].set_xlim(0,.875)
    fig.text(.095,.058,'Point bars: nominal counting + ruler (top); nominal counting + MC (ratio).',fontsize=9,color='#444444')
    fig.text(.095,.032,'Subset-selection and repositioning uncertainties are excluded. Model: r = d + 16 mm; 10 keV; recovery 2.00 us.',fontsize=9,color='#444444')
    for suffix in ('png','pdf'):
        fig.savefig(OUT/f'task16_selected_three_vs_geant4.{suffix}',dpi=200)
    plt.close(fig)
    print('Saved comparison PNG and PDF from the selected-data CSV.')


if __name__ == '__main__':
    {'extract':extract,'plot':plot}[sys.argv[1]]()
