"""Compare the requested geometry using far-only normalization and batch covariance."""
from pathlib import Path
import csv, hashlib, json, os, sys
import numpy as np
from scipy.interpolate import PchipInterpolator

W=Path(__file__).resolve().parent; ROOT=W.parents[1]
OUT=ROOT/'outputs/task16_offset21_shift31'; OUT.mkdir(exist_ok=True)
sys.path.insert(0,str(W.parent/'rigid_mount_resimulation'))
from task16_inputs import load,read
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(name,rr):
 with (OUT/name).open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rr[0]));w.writeheader();w.writerows(rr)
plan=json.loads((W/'production/plan.json').read_text())
assert sha(W/'geant_sensitivity.cc')==plan['source_sha256']
assert sha(W/'build/task16_sensitivity.app/Contents/MacOS/task16_sensitivity')==plan['binary_sha256']
v=load(); data=v['selected']; d=np.array(plan['distances']); M=len(d)
ix=np.array([np.where(v['d']==x)[0][0] for x in d]); r=d+.021
assert sha(Path(v['source']['source']))==plan['data_sha256']==v['source']['source_sha256']
vectors=[];complete=[]
for f in sorted((W/'production').glob('batch_[0-9][0-9].json')):
 meta=json.loads(f.read_text());assert meta['binary_sha256']==plan['binary_sha256']
 rr=read(f.with_suffix('.csv'));assert len(rr)==M*6
 vec=[]
 for x in d:
  q=[row for row in rr if float(row['distance_m'])==x]
  assert [float(row['threshold_keV']) for row in q]==[.1,5,10,20,40,60]
  pp=[float(row['probability']) for row in q]
  assert np.all(np.diff(pp)<=1e-16)
  assert all(abs(float(row['active_distance_m'])-x-.021)<1e-12 and float(row['height_mm'])==3 and float(row['lateral_x_mm'])==1 for row in q)
  vec.extend(pp)
  complete.extend(dict(batch=meta['replicate'],**row) for row in q)
 vectors.append(vec)
assert len(vectors)==plan['R']
vectors=np.array(vectors);p=vectors.mean(0).reshape(M,6)[:,2]
Vfull=np.cov(vectors,rowvar=False,ddof=1)/len(vectors)
ki=np.arange(M)*6+2;VP=Vfull[np.ix_(ki,ki)]
old=read(ROOT/'outputs/task16_offset19_shift3/comparison.csv')
assert np.array_equal(d,[float(q['d_m']) for q in old])
po=np.array([float(q['probability']) for q in old])
Vo=np.load(ROOT/'outputs/task16_offset19_shift3/covariances.npz')['probability_covariance_10keV']
net=data['net'][ix];Vy=data['Vy'][np.ix_(ix,ix)]
w=np.zeros(M);anchors=np.array([np.where(d==x)[0][0] for x in [.3,.5,.85]])
w[anchors]=1/3
H=np.eye(M)-np.outer(np.ones(M),w)
def cal(prob,vcov,offset):
 rr=d+offset
 g=PchipInterpolator(np.log(rr),np.log(prob)).derivative()(np.log(rr))/rr
 Vdist=np.diag((g*v['sd'])**2)+np.outer(g*v['soff'],g*v['soff'])
 V=Vy+vcov/np.outer(prob,prob)+Vdist
 A=float(np.exp(w@(np.log(net)-np.log(prob))))
 ratio=net/(A*prob);Vr=H@V@H.T
 return A,ratio,ratio*np.sqrt(np.maximum(0,np.diag(Vr))),Vr
A,ratio,sratio,Vratio=cal(p,VP,.021)
Ao,oldratio,soldratio,Voldratio=cal(po,Vo,.019)
oldfixedA=float(old[0]['normalization_far_only'])
sp=np.sqrt(np.maximum(0,np.diag(VP)))
rows=[]
for j,x in enumerate(d):
 rows.append(dict(d_m=x,axial_active_distance_m=r[j],transverse_shift_mm=float(np.sqrt(10)),transverse_x_mm=1,transverse_y_mm=3,
  center_distance_m=np.sqrt(r[j]**2+.003**2+.001**2),corrected_rate_cps=net[j],
  probability=p[j],probability_MC_se=sp[j],normalization_far_only=A,
  predicted_rate_cps=A*p[j],data_over_prediction=ratio[j],nominal_ratio_se=sratio[j],
  pointwise_nominal_z=(1-ratio[j])/sratio[j],within_nominal_1sigma=bool(abs(1-ratio[j])<=sratio[j]),
  baseline_probability=po[j],baseline_normalization_far_only=Ao,
  baseline_data_over_prediction=oldratio[j],baseline_nominal_ratio_se=soldratio[j],
  new_over_baseline_probability=p[j]/po[j],
  data_over_new_with_previous_fixed_amplitude=net[j]/(oldfixedA*p[j]),
  used_for_normalization=bool(j in anchors)))
direct=[]
for f in sorted((W/'direct').glob('batch_[0-9][0-9].json')):
 meta=json.loads(f.read_text());assert meta['binary_sha256']==plan['binary_sha256']
 direct.append(next(q for q in read(f.with_suffix('.csv')) if float(q['threshold_keV'])==10))
assert len(direct)==2
dp=float(np.mean([float(q['probability']) for q in direct]))
dse=float(np.sqrt(sum(float(q['direct_se'])**2 for q in direct))/len(direct))
dz=float((dp-p[0])/np.hypot(dse,sp[0]))
summary=dict(geometry=plan['geometry'],data_source=v['source']['source'],data_sha256=plan['data_sha256'],
 independent_batches=len(vectors),primary_events=plan['R']*plan['nsource'],
 staged_replays=plan['R']*M*6*plan['npop'],direct_validation_primary_events=200000,
 normalization_method=plan['comparison'],normalization=A,baseline_normalization=Ao,
 validation=dict(direct_probability=dp,direct_se=dse,smc_probability=float(p[0]),smc_se=float(sp[0]),combined_se_difference=dz),
 rows=rows,nominal_uncertainty='Full independent-batch covariance, counting/background/effective-recovery errors, original nominal rail/common-offset uncertainties; far-normalization correlation propagated. Does not include apparatus/model uncertainty or closest-three selection bias.',
 interpretation='User-updated recess dimensions and prior transverse offsets. Source and detector recesses and the x displacement changed together relative to the preceding model. Improvement alone does not establish physical dimensions or causal attribution.',
 original_results_unchanged=True)
write('comparison.csv',rows);write('complete_independent_batches.csv',complete)
(OUT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
(OUT/'run_plan.json').write_bytes((W/'production/plan.json').read_bytes())
np.savez_compressed(OUT/'covariances.npz',d_m=d,probability_covariance_10keV=VP,
 probability_covariance_all_thresholds=Vfull,data_over_model_log_covariance=Vratio,
 baseline_data_over_model_log_covariance=Voldratio,normalization_weights=w)
os.environ.setdefault('MPLCONFIGDIR',str(ROOT/'work/radioactivity/mplcache'))
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'pdf.fonttype':42,'axes.spines.top':False,'axes.spines.right':False})
fig,(ax,bx)=plt.subplots(2,1,figsize=(9.5,8),sharex=True,gridspec_kw={'height_ratios':[1.1,1]})
fig.subplots_adjust(left=.11,right=.97,top=.86,bottom=.19,hspace=.14)
ax.errorbar(d*100,net,yerr=net*np.sqrt(np.diag(Vy)),fmt='o',color='#202020',ms=5,label='Latest Task16 measurements',zorder=4)
ax.errorbar(d*100,Ao*po,yerr=Ao*np.sqrt(np.diag(Vo)),fmt='s',color='#9299a1',ms=4,label='Previous: detector/source recesses 2/5 mm, offset 19 mm')
ax.errorbar(d*100,A*p,yerr=A*sp,fmt='D',color='#b44824',ms=4,label='New: recesses 3/6 mm, offset 21 mm, x/y shift 1/3 mm')
ax.set_yscale('log');ax.set_xscale('log');ax.set_ylabel('Corrected count rate (s$^{-1}$)');ax.legend(fontsize=8.6)
bx.errorbar(d*100*.985,oldratio,yerr=soldratio,fmt='s',mfc='white',color='#9299a1',ms=4,capsize=2,label='Baseline')
bx.errorbar(d*100*1.015,ratio,yerr=sratio,fmt='D',color='#b44824',ms=4,capsize=2,label='Requested geometry')
bx.axhline(1,color='#606060',lw=1)
bx.set(xlabel='Recorded rail distance d (cm)',ylabel='Measured / predicted rate')
bx.set_ylim(min(.75,float(min(ratio-sratio))-.03),max(1.2,float(max(ratio+sratio))+.04))
bx.set_xticks([1,2.5,5,10,30,50,85]);bx.set_xticklabels(['1','2.5','5','10','30','50','85'])
for a in (ax,bx):a.grid(alpha=.18)
fig.suptitle('Effect of deeper source and detector recesses',fontsize=12.5,y=.965)
fig.text(.5,.91,'One amplitude per geometry, calibrated only at 30, 50 and 85cm; near points excluded',ha='center',fontsize=9)
fig.text(.11,.115,'Axis distance: r = d + (10 + 2 + 3 + 6) mm = d + 21 mm. Source recess 6 mm; detector recess 3 mm.',fontsize=8.2)
fig.text(.11,.077,'Detector and frame move together: x = 1 mm, y = 3 mm. Parallel planes; air transport; 10 keV threshold.',fontsize=8.2)
fig.text(.11,.039,'Nominal uncertainties shown; unmeasured apparatus effects and closest-three selection bias are excluded.',fontsize=8.2)
for ext in ['png','pdf']:fig.savefig(OUT/f'comparison.{ext}',dpi=180)
plt.close(fig)
notes='本轮检验用户更新尺寸：源凹深6mm、探测器凹深3mm，外部offset左10mm右2mm，因此r=d+21mm。探测器与入口框一起平移x=1mm、y=3mm；中心直线距离为sqrt(r^2+10mm^2)，两个平面平行。源原膜层位置保留，以加长铝孔板至4.7mm实现源凹深6mm；探测器入口框相应加深至3mm。\n\n'
notes+='分别用30、50、85cm三个远端点的log(C/p)等权平均确定一个整体幅度。近端没有参与标定；旧模型也按完全相同的方法重标定，旧模型为上一轮offset19mm、仅y错位3mm的模型。另在CSV保留沿用旧固定幅度的比较。\n\n'
for q in rows[:5]:notes+=f"d={q['d_m']*100:g}cm：旧模型实测/预测={q['baseline_data_over_prediction']:.3f}，新模型={q['data_over_prediction']:.3f}±{q['nominal_ratio_se']:.3f}。\n"
notes+=f'\n直接追踪与加速计算近端相差{dz:.2f}个合并标准误。\n'
notes+='\n这是根据已见数据提出的敏感性情景，不能将改善本身当作装置真实错位或实际offset的测量。两侧凹深及左右错位同时改变，不能据此分别确定贡献。名义误差不含全部系统不确定度，不报告正式拟合p值。\n'
(OUT/'analysis_zh.md').write_text(notes)
print(json.dumps(summary,indent=2))
