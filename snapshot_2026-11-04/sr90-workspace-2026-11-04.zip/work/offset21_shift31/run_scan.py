"""Predeclared sensitivity run; complete independent batches, no near-point fit."""
from pathlib import Path
import concurrent.futures, csv, hashlib, json, os, subprocess, sys, time

W = Path(__file__).resolve().parent
ROOT = W.parents[1]
BASE = Path('/Users/chenqiyue/Documents/Codex/2026-10-12/https-chatgpt-com-share-6acd35f5-5168/outputs/task16_geant4')
BIN = W/'build/task16_sensitivity.app/Contents/MacOS/task16_sensitivity'
SPEC = BASE/'inputs/spectra_unique.csv'
DATA = Path('/Users/chenqiyue/Library/CloudStorage/OneDrive-ImperialCollegeLondon/Radlab/task 16 data.xlsx')
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
phase = sys.argv[1] if len(sys.argv)>1 else 'production'
cfg = {
 'production': dict(R=8,nsource=400000,npop=16000,distances=[.01,.025,.05,.075,.1,.3,.5,.85],seed=1840110000,mode='smc'),
 'direct': dict(R=2,nsource=100000,npop=1000,distances=[.01],seed=1850110000,mode='direct'),
 'check': dict(R=1,nsource=200,npop=200,distances=[.01],seed=1860110000,mode='direct'),
}[phase]
out = W/phase
out.mkdir(exist_ok=True)
geometry = dict(active_plane_offset_mm=21,detector_center_x_mm=1,detector_center_y_mm=3,source_center_x_mm=0,source_center_y_mm=0,
 source_recess_mm=6,detector_recess_mm=3,source_bored_plate_thickness_mm=4.7,source_aperture_diameter_mm=11,
 emitter_diameter_mm=22,detector_size_mm=[10,10,.3],detector_opening_mm=[10,10],
 interpretation='Left external offset10mm, right external2mm, detector/source recesses3+6mm; total21mm. Detector and its frame translated together by x1mm and y3mm. Planes parallel.',
 other_assumptions='Retain inherited films at z0.25-1.3mm and extend source bored Al plate from z1.3 to6mm (4.7mm thick); detector frame3mm deep. Aperture sizes/materials and emission disk unchanged. Importance proposals retain full support and exact weight correction.')
plan = dict(**cfg,phase=phase,geometry=geometry,binary_sha256=sha(BIN),source_sha256=sha(W/'geant_sensitivity.cc'),
 spectrum_sha256=sha(SPEC),data_sha256=sha(DATA),
 comparison='Main comparison calibrates one common amplitude using only three far anchors30,50,85cm. Identical far-anchor log weights for both geometries. No near data used for calibration. Also report previous fixed amplitude.',
 error='Complete independently seeded batch covariance; replay counts are not independent primary emissions.')
pf=out/'plan.json'
if pf.exists(): assert json.loads(pf.read_text())==plan
else: pf.write_text(json.dumps(plan,indent=2)+'\n')
env=os.environ.copy()
env.pop('TASK16_GEOMETRY_VIEW',None);env.pop('TASK16_VIS_MACRO',None)
for key,name in [('G4LEDATA','EMLOW'),('G4LEVELGAMMADATA','PhotonEvaporation'),('G4RADIOACTIVEDATA','RadioactiveDecay'),('G4ENSDFSTATEDATA','ENSDFSTATE')]:
 env[key]=str(next((BASE.parents[1]/'.runtime/geant4/share/Geant4/data').glob(name+'*')))
def run(rep):
 seed=cfg['seed']+rep*100003
 target=out/f'batch_{rep:02d}.csv'; meta=target.with_suffix('.json')
 cmd=[str(BIN),str(SPEC),str(target),','.join(map(str,cfg['distances'])),str(cfg['nsource']),str(cfg['npop']),str(seed),'11','5.5',cfg['mode'],'10','10','21','3','1']
 if meta.exists():
  m=json.loads(meta.read_text());assert m['command']==cmd and m['binary_sha256']==plan['binary_sha256'];return
 start=time.time()
 with target.with_suffix('.log').open('w') as f: subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
 rows=list(csv.DictReader(target.open()))
 assert len(rows)==6*len(cfg['distances'])
 assert all(abs(float(q['active_distance_m'])-float(q['distance_m'])-.021)<1e-12 and float(q['height_mm'])==3 and float(q['lateral_x_mm'])==1 for q in rows)
 log=target.with_suffix('.log').read_text()
 assert not any(t in log for t in ['G4Exception','Overlap is detected','Fatal','ERROR'])
 meta.write_text(json.dumps(dict(command=cmd,seed=seed,replicate=rep,binary_sha256=plan['binary_sha256'],source_sha256=plan['source_sha256'],elapsed_s=time.time()-start),indent=2)+'\n')
 print(f'Completed {phase} batch {rep+1}/{cfg["R"]}, {time.time()-start:.1f}s',flush=True)
workers=int(sys.argv[2]) if len(sys.argv)>2 else 4
with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as pool: list(pool.map(run,range(cfg['R'])))
