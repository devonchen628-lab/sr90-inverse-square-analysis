"""Relevant geometry/provenance and transport consistency checks for this scenario."""
from pathlib import Path
import hashlib,json
import numpy as np
W=Path(__file__).resolve().parent;ROOT=W.parents[1]
OUT=ROOT/'outputs/task16_offset21_shift31'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
summary=json.loads((OUT/'summary.json').read_text())
oldplan=json.loads((ROOT/'work/offset19_shift3/production/plan.json').read_text())
assert sha(ROOT/'work/offset19_shift3/geant_sensitivity.cc')==oldplan['source_sha256']
assert sha(ROOT/'work/offset19_shift3/build/task16_sensitivity.app/Contents/MacOS/task16_sensitivity')==oldplan['binary_sha256']
for phase in ('production','direct','check'):
 for f in (W/phase).glob('batch_*.log'):
  log=f.read_text()
  assert 'source_depth_mm=6 source_wall_mm=4.7 detector_depth_mm=3' in log
  assert 'active_offset_mm=21 lateral_shift_mm=3 lateral_x_mm=1' in log
  assert not any(t in log for t in ['G4Exception','Overlap is detected','Fatal','ERROR'])
v=np.load(OUT/'covariances.npz')['probability_covariance_all_thresholds']
assert np.linalg.eigvalsh(v).min()>-1e-14*np.diag(v).max()
z=summary['validation']['combined_se_difference']
assert abs(z)<3,'Direct and staged estimates need further investigation'
result=dict(independent_batches=8,geometry_log_and_record_checks=True,prior_code_and_binary_preserved=True,
 covariance_psd_to_roundoff=True,latest_data_hash_verified=True,direct_vs_staged_combined_se_difference=z,
 pointwise_nominal_1sigma=[dict(d_cm=q['d_m']*100,ratio=q['data_over_prediction'],se=q['nominal_ratio_se'],within=q['within_nominal_1sigma']) for q in summary['rows']],
 caveat='Pointwise nominal comparisons are not a global goodness-of-fit test. Unmeasured apparatus uncertainties and selection bias are excluded.')
(OUT/'verification.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
