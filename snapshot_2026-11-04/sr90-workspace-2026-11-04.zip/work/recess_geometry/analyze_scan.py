"""Approved recessed geometry vs latest data; full independent-batch covariance."""
from pathlib import Path
import csv,hashlib,json,sys
import numpy as np
from scipy.interpolate import PchipInterpolator
W=Path(__file__).resolve().parent;ROOT=W.parents[1]
OUT=ROOT/'outputs/task16_recess_geometry';OUT.mkdir(parents=True,exist_ok=True)
sys.path.insert(0,str(W.parent/'rigid_mount_resimulation'))
from task16_inputs import load,read
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(name,rows):
 with (OUT/name).open('w',encoding='utf-8-sig',newline='') as f:
  wr=csv.DictWriter(f,fieldnames=list(rows[0]));wr.writeheader();wr.writerows(rows)
v=load();data=v['selected'];d=v['d'];r=v['r0'];M=len(d);weights=data['w'].copy()
plan=json.loads((W/'production/plan.json').read_text())
assert sha(Path(v['source']['source']))==v['source']['source_sha256']==plan['data_sha256']
assert sha(W/'geometry.json')==plan['geometry_sha256']
assert sha(W/'geant_recess.cc')==plan['source_code_sha256']
assert sha(W/'build/task16_recess.app/Contents/MacOS/task16_recess')==plan['binary_sha256']
assert np.array_equal(plan['distances'],d)
metas=sorted((W/'production').glob('batch_[0-9][0-9].json'))
assert len(metas)==plan['R']
vectors=[];complete=[];seeds=[]
for f in metas:
 meta=json.loads(f.read_text());seeds.append(meta['seed'])
 assert meta['binary_sha256']==plan['binary_sha256'] and meta['geometry_sha256']==plan['geometry_sha256']
 rr=read(f.with_suffix('.csv'));assert len(rr)==6*M
 vec=[]
 for x in d:
  dd=[q for q in rr if float(q['distance_m'])==x]
  assert [float(q['threshold_keV']) for q in dd]==[.1,5,10,20,40,60]
  pp=np.array([float(q['probability']) for q in dd])
  assert (pp>=0).all() and (np.diff(pp)<=1e-16).all()
  for q in dd:
   assert abs(float(q['active_distance_m'])-x-.016)<1e-12
   assert float(q['emitter_diameter_mm'])==22 and float(q['aperture_diameter_mm'])==11
   assert int(q['seed'])==meta['seed']
   complete.append(dict(batch=meta['replicate'],**q))
  vec.extend(pp)
 vectors.append(vec)
 log=f.with_suffix('.log').read_text()
 assert not any(t in log for t in ['G4Exception','Overlap is detected','Fatal','ERROR'])
assert len(set(seeds))==len(seeds)
vectors=np.array(vectors);P=vectors.mean(0).reshape(M,6)
Vfull=np.cov(vectors,rowvar=False,ddof=1)/len(vectors)
ix=np.arange(M)*6+2;p=P[:,2];VP=Vfull[np.ix_(ix,ix)]
sp=np.sqrt(np.maximum(0,np.diag(VP)));assert (p>0).all()
oldfolder=ROOT/'outputs/task16_ppt_geometry'
oldrows=read(oldfolder/'latest_data_comparison_32.csv')
assert np.array_equal(d,[float(q['d_m']) for q in oldrows])
po=np.array([float(q['probability']) for q in oldrows])
Vo=np.load(oldfolder/'covariances.npz')['probability_covariance_10keV']
so=np.sqrt(np.maximum(0,np.diag(Vo)))
def cal(prob,vcov):
 g=PchipInterpolator(np.log(r),np.log(prob)).derivative()(np.log(r))/r
 Vdist=np.diag((g*v['sd'])**2)+np.outer(g*v['soff'],g*v['soff'])
 V=data['Vy']+vcov/np.outer(prob,prob)+Vdist
 A=float(np.exp(weights@(np.log(data['net'])-np.log(prob))))
 H=np.eye(M)-np.outer(np.ones(M),weights)
 return dict(A=A,ratio=data['net']/(A*prob),V=V,Vratio=H@V@H.T,
  slogA=float(np.sqrt(weights@V@weights)),g=g)
c=cal(p,VP);co=cal(po,Vo);A=c['A'];Ao=co['A']
assert np.isclose(Ao,float(oldrows[0]['normalization']),rtol=1e-12)
u=A*p*r*r;su=A*sp*r*r;uo=Ao*po*r*r;suo=Ao*so*r*r
ud=data['u'];sud=np.sqrt(np.diag(data['Vu']))
ratio=c['ratio'];sr=ratio*np.sqrt(np.maximum(0,np.diag(c['Vratio'])))
factor=p/po
VF=VP/np.outer(po,po)+(np.outer(factor,factor)*Vo/np.outer(po,po))
sf=np.sqrt(np.maximum(0,np.diag(VF)))
rows=[]
for i,x in enumerate(d):
 rows.append(dict(d_m=x,r_m=r[i],selected_counts=int(data['N'][i]),selected_time_s=data['T'][i],
  raw_rate_cps=data['C'][i],corrected_rate_cps=data['net'][i],measured_u=ud[i],measured_u_se=sud[i],
  probability=p[i],probability_MC_se=sp[i],normalization=A,normalization_weights=weights[i],
  predicted_u=u[i],predicted_u_MC_se=su[i],data_over_prediction=ratio[i],data_over_prediction_se=sr[i],
  previous_probability=po[i],previous_probability_MC_se=so[i],previous_normalization=Ao,
  previous_predicted_u=uo[i],previous_data_over_prediction=co['ratio'][i],
  new_over_previous_probability=factor[i],new_over_previous_probability_se=sf[i],
  source_recess_mm=5,source_bored_plate_mm=3.7,detector_recess_mm=2,detector_opening_width_mm=10,
  detector_opening_height_mm=10,emitter_diameter_mm=22,source_aperture_diameter_mm=11))
write('latest_data_comparison_32.csv',rows)
write('complete_independent_batches.csv',complete)
mc=[]
for i,x in enumerate(d):
 for j,t in enumerate([.1,5,10,20,40,60]):
  k=6*i+j;mc.append(dict(d_m=x,r_m=r[i],threshold_keV=t,probability=P[i,j],
   probability_se=np.sqrt(max(0,Vfull[k,k])),independent_batches=len(vectors)))
write('monte_carlo_summary_32.csv',mc)
np.savez_compressed(OUT/'covariances.npz',d_m=d,probability_covariance_all_thresholds=Vfull,
 probability_covariance_10keV=VP,measured_u_covariance=data['Vu'],data_over_model_log_covariance=c['Vratio'],
 new_over_previous_probability_covariance=VF,previous_probability_covariance=Vo)
(OUT/'approved_geometry_input.json').write_bytes((W/'geometry.json').read_bytes())
reported_geometry=dict(plan['geometry'],status='User-approved geometry; full production scan completed',
 input_snapshot_sha256=plan['geometry_sha256'])
(OUT/'geometry.json').write_text(json.dumps(reported_geometry,indent=2)+'\n')
(OUT/'run_plan.json').write_bytes((W/'production/plan.json').read_bytes())
direct=[]
directplan=json.loads((W/'direct/plan.json').read_text())
for f in sorted((W/'direct').glob('batch_[0-9][0-9].json')):
 meta=json.loads(f.read_text());assert meta['binary_sha256']==plan['binary_sha256']
 direct.append(next(q for q in read(f.with_suffix('.csv')) if float(q['threshold_keV'])==10))
assert len(direct)==directplan['R']
dp=float(np.mean([float(q['probability']) for q in direct]))
dse=float(np.sqrt(sum(float(q['direct_se'])**2 for q in direct))/len(direct))
dz=float((dp-p[0])/np.hypot(dse,sp[0]))
summary=dict(number_of_distances=M,independent_batches=len(vectors),geometry=reported_geometry,
 primary_source_events=plan['R']*plan['nsource'],staged_replay_events=plan['R']*M*6*plan['npop'],
 validation_source_events=directplan['R']*directplan['nsource'],data_source=v['source']['source'],
 data_sha256=plan['data_sha256'],normalization=A,previous_normalization=Ao,
 normalization_log_standard_error=c['slogA'],
 normalization_method='One amplitude per geometry using identical previously frozen correlated-GLS weights. No distance, aperture, threshold or deadtime fit.',
 descriptive_log_ratio_RMS=float(np.sqrt(np.mean(np.log(ratio)**2))),
 previous_descriptive_log_ratio_RMS=float(np.sqrt(np.mean(np.log(co['ratio'])**2))),
 MC_relative_standard_error_range=[float(min(sp/p)),float(max(sp/p))],
 MC_relative_standard_error_at_85cm=float(sp[-1]/p[-1]),
 direct_validation=dict(distance_m=.01,probability=dp,standard_error=dse,production_probability=float(p[0]),
  production_standard_error=float(sp[0]),standardized_difference=dz),
 selected_rows=[q for q in rows if q['d_m'] in [.01,.025,.05,.1,.3,.5,.85]],
 closest_three_selection_retained=True,formal_goodness_of_fit_p_value=None,
 limitations=[
 'Detector opening10x10mm, aluminum material and outer frame30x30mm are assumptions in the approved geometry, not measured specifications.',
 'Source total depth5mm is achieved by retaining inherited foil/acrylic and shortening aluminum bored plate to3.7mm. Both source housing and detector entrance changed; their effects are not separately identified.',
 'r=d_rail+16mm is retained. Depth5mm+2mm is not added a second time; external face gap is d_rail+9mm. Rail-reference interpretation remains a systematic limitation.',
 'Source11mm aperture vs source-specific9.75mm drawing remains unresolved; internal emitting disk22mm retained. Active-material self absorption, ceramic support, entrance films and electronics response are uncalibrated.',
 'Effective recovery~2us need not be identical to complete counting-system deadtime;10keV remains an assumed count threshold.',
 'Data closest-three selection and repositioning spread are excluded from nominal error bars. Normalization is fitted to the same data, not independent activity or model validation.',
 'Complete-batch covariance captures sampling error conditional on the transport algorithm and apparatus model. Replays are not independent source decays.'])
(OUT/'analysis_summary.json').write_text(json.dumps(summary,indent=2)+'\n')

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'pdf.fonttype':42,'axes.spines.top':False,'axes.spines.right':False})
col='#8050ad'
fig,(ax,bx)=plt.subplots(2,1,figsize=(11.2,8.7),sharex=True,gridspec_kw={'height_ratios':[1.3,1]})
fig.subplots_adjust(left=.10,right=.98,top=.875,bottom=.22,hspace=.14)
ax.errorbar(d*100,u,yerr=su,fmt='s',ms=4,color=col,capsize=2,label='Geant4: source recess5mm + detector recess2mm')
ax.errorbar(d*100,ud,yerr=sud,fmt='o',ms=4,color='#202020',capsize=2,label='Latest Task16: closest-three mean',zorder=3)
ax.set_ylabel(r'$C_{\rm corrected}(d+16\,\mathrm{mm})^2$ (m$^2$ s$^{-1}$)');ax.legend(fontsize=9)
bx.errorbar(d*100,ratio,yerr=sr,fmt='o',ms=4,color=col,capsize=2)
bx.axhline(1,color='#888888',lw=1);bx.set(xlabel='Rail reading d (cm)',ylabel='Measured / predicted rate',xlim=(0,88))
for a in [ax,bx]:a.grid(alpha=.16)
fig.suptitle('Recessed geometry versus latest Task16 measurements',fontsize=15,y=.965)
fig.text(.5,.920,'32 simulated distances; air transport; one overall amplitude fitted; geometry held fixed',ha='center',fontsize=9.5)
fig.text(.10,.132,'Source:22mm emitting disk,11mm aperture,total recess5mm. Si:10 x10 x0.3mm, recessed2mm.',fontsize=8.2)
fig.text(.10,.093,'Detector opening10 x10mm and aluminum frame are assumptions. Distance r=d+16mm; no extra7mm added.',fontsize=8.1)
fig.text(.10,.054,'10keV count threshold; effective recovery correction unchanged. Bars exclude unmeasured apparatus and return-position effects.',fontsize=8)
fig.text(.10,.020,'Monte Carlo errors:12 independent complete batches. Closest-three selection retained; no formal goodness-of-fit p-value.',fontsize=8)
for ext in ['png','pdf']:fig.savefig(OUT/f'recess_geometry_vs_latest.{ext}',dpi=200)
plt.close(fig)

fig,(ax,bx)=plt.subplots(2,1,figsize=(11.2,8.5),sharex=True,gridspec_kw={'height_ratios':[1.2,1]})
fig.subplots_adjust(left=.10,right=.98,top=.87,bottom=.19,hspace=.15)
ax.errorbar(d*100,uo,yerr=suo,fmt='s',ms=3.5,color='#999999',capsize=2,label='Previous:source6.3mm; no detector frame')
ax.errorbar(d*100,u,yerr=su,fmt='s',ms=3.5,color=col,capsize=2,label='New:source5mm; detector recessed2mm')
ax.errorbar(d*100,ud,yerr=sud,fmt='o',ms=3.5,color='#202020',capsize=2,label='Latest measurements');ax.legend(fontsize=8.5)
ax.set_ylabel(r'$C_{\rm corrected}r^2$ (m$^2$ s$^{-1}$)')
bx.errorbar(d*100,factor,yerr=sf,fmt='o',ms=3.5,color=col,capsize=2)
bx.axhline(1,color='#888888',lw=1);bx.set(xlabel='Rail reading d (cm)',ylabel='New / previous count probability',xlim=(0,88))
for a in [ax,bx]:a.grid(alpha=.16)
fig.suptitle('Combined effect of the approved source and detector recess geometry',fontsize=14,y=.96)
fig.text(.5,.915,'Same emitting disk, source aperture, distance convention, threshold and calibration weights',ha='center',fontsize=9)
fig.text(.10,.110,'Upper:one fitted amplitude per model. Lower:unscaled probability ratio, including independent MC errors.',fontsize=8.3)
fig.text(.10,.069,'Two structures changed together; this comparison does not isolate the detector-side wall effect.',fontsize=8.3)
fig.text(.10,.030,'Source wall3.7mm reconciles5mm total recess with inherited foil/acrylic; detector opening and material remain assumptions.',fontsize=8)
for ext in ['png','pdf']:fig.savefig(OUT/f'recess_change_comparison.{ext}',dpi=200)
plt.close(fig)

notes='# 凹槽几何重跑：最新Task16数据\n\n'
notes+='本轮按用户确认的原生Geant4模型计算：源发射面至外侧入口5mm，探测器硅面凹入2mm。源端保留原膜层，铝孔板长度为3.7mm；新增探测器10×10mm方孔、30×30mm外框，暂按铝。入口尺寸、外框和材料属于模型假设，不能当成实测尺寸。\n\n'
notes+='源内部为22mm均匀发射圆盘，源出口直径11mm，硅敏感区10×10×0.3mm。r=d_rail+16mm保持不变，因此两个入口面间距为d_rail+9mm。5mm与2mm没有重复添加。与上一轮相比，源端和探测器端同时变化；未单独隔离各部分贡献。\n\n'
notes+='仅使用最新task 16 data.xlsx中此前导出的141次原始记录，32个距离继续采用最接近三次的均值，未混入旧23点或Book2。计数率按原来的有效恢复时间及背景修正。最接近三次的选择偏差及回位散布未计入名义误差条，不能据此报告严格的拟合p值。\n\n'
notes+='Geant4 Livermore输运、近似Sr/Y等权能谱；初级事件及后代在硅中的总沉积≥10keV计一次，另保存0.1、5、20、40、60keV结果。10keV未用数据调优，不等同已标定实际阈值。分阶段重放保留事件整体，12个独立完整批次估计含跨距离相关性的MC误差；不能将重放次数当成新增独立源衰变。\n\n'
notes+=f"新源事件{summary['primary_source_events']:,}次，分阶段重放{summary['staged_replay_events']:,}次；另有{summary['validation_source_events']:,}次近端直接追踪检查。近端直接与分阶段结果的标准化差为{dz:.2f}。\n\n"
notes+='新旧模型分别只拟合一个整体幅度，使用完全相同的既有权重。几何、距离、阈值、死时间均未拟合。幅度不是独立测得的活度；归一化后的中远端吻合也不是独立验证。\n\n'
notes+='图中误差条为名义1标准误。上图模拟误差条是在已拟合幅度条件下的MC标准误；实测误差包含计数、背景、有效恢复时间及原有距离不确定度。下图实测/预测比值传播了整体幅度估计带来的相关性。未测量的凹槽尺寸、材料和真实电子学响应等系统不确定度不在误差条内。\n\n'
notes+=f"MC相对标准误范围{min(sp/p)*100:.1f}%–{max(sp/p)*100:.1f}%，85cm为{sp[-1]/p[-1]*100:.1f}%。描述性log残差RMS：新模型{summary['descriptive_log_ratio_RMS']:.4f}，旧模型{summary['previous_descriptive_log_ratio_RMS']:.4f}；该指标不是正式显著性检验。\n\n"
for q in summary['selected_rows']:
 notes+=f"- d={q['d_m']*100:g}cm：实测/新模型={q['data_over_prediction']:.3f}±{q['data_over_prediction_se']:.3f}，旧模型={q['previous_data_over_prediction']:.3f}；新/旧原始概率={q['new_over_previous_probability']:.3f}±{q['new_over_previous_probability_se']:.3f}。\n"
notes+='\n限制：本轮没有匹配几何的真空对照；不能与旧几何的真空点相除来提取空气效应。源材料自吸收、真实遮光层和电子学响应仍未标定。详见analysis_summary.json中的limitations。\n'
(OUT/'analysis_zh.md').write_text(notes)
assert np.allclose(VP,VP.T,atol=1e-23)
assert np.linalg.eigvalsh(Vfull).min()>-1e-20
verification=dict(complete_batches=len(vectors),distances=M,thresholds=6,unique_seeds=True,
 data_hash_matches=True,geometry_hash_matches=True,binary_hash_matches=True,
 probabilities_monotonic_in_threshold=True,covariance_symmetric_and_PSD_to_roundoff=True,
 near_direct_standardized_difference=dz,near_direct_consistent_within_3_combined_SE=bool(abs(dz)<3),
 previous_normalization_reproduced=True,new_geometry_production_results=True)
(OUT/'verification.json').write_text(json.dumps(verification,indent=2)+'\n')
print(json.dumps({k:summary[k] for k in ['number_of_distances','independent_batches','normalization',
 'descriptive_log_ratio_RMS','previous_descriptive_log_ratio_RMS','MC_relative_standard_error_range',
 'direct_validation','selected_rows']},indent=2))
