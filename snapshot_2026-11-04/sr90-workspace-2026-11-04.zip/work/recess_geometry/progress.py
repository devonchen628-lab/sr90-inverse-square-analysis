from pathlib import Path
import json
W=Path(__file__).resolve().parent/'production'
complete=list(W.glob('batch_[0-9][0-9].json'))
print(f'Complete independent scans: {len(complete)}/12')
for f in sorted(W.glob('batch_*.log')):
 if f.with_suffix('.json').exists():continue
 text=f.read_text()
 assert not any(s in text for s in ['G4Exception','Overlap is detected','Fatal','ERROR']),str(f)
 lines=[s for s in text.splitlines() if s.startswith('DONE')]
 print(f.stem, f'{len(lines)}/32 distances',lines[-1] if lines else 'Generating source histories')
