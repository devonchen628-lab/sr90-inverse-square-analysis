"""Initialize or display the same recessed Geant4 geometry; no production scan."""
from pathlib import Path
import os, subprocess, sys
W=Path(__file__).resolve().parent
BASE=Path('/Users/chenqiyue/Documents/Codex/2026-10-12/https-chatgpt-com-share-6acd35f5-5168/outputs/task16_geant4')
P=BASE.parents[1]/'.runtime/geant4'
env=os.environ.copy()
for key,name in [('G4LEDATA','EMLOW'),('G4LEVELGAMMADATA','PhotonEvaporation'),('G4RADIOACTIVEDATA','RadioactiveDecay'),('G4ENSDFSTATEDATA','ENSDFSTATE')]:
    env[key]=str(next((P/'share/Geant4/data').glob(name+'*')))
mode=sys.argv[1] if len(sys.argv)>1 else 'view'
if mode=='view':
    env['TASK16_GEOMETRY_VIEW']='1'
    env['TASK16_VIS_MACRO']=str(W/'vis.mac')
    env['QT_QPA_PLATFORM_PLUGIN_PATH']=str(W/'qt_plugins/platforms')
    env['QT_PLUGIN_PATH']=str(W/'qt_plugins')
elif mode!='check':
    raise SystemExit('Expected view or check')
cmd=[str(W/'build/task16_recess.app/Contents/MacOS/task16_recess'),str(BASE/'inputs/spectra_unique.csv'),str(W/'initialization_check.csv'),'.01','200','100','1730100000','11','5.5','direct','10','10']
with (W/('viewer.log' if mode=='view' else 'initialization_check.log')).open('w') as log:
    result=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT)
if result.returncode:
    raise SystemExit(result.returncode)
if mode=='check':
    text=(W/'initialization_check.log').read_text()
    assert not any(s in text for s in ['G4Exception','Overlap is detected','Fatal','ERROR'])
    print('Recess geometry initialized, overlap checks passed, 200-event smoke run completed. Not a count prediction.')
