"""Fixed independent batches for the user-approved recessed geometry."""
from pathlib import Path
import concurrent.futures,csv,fcntl,hashlib,json,os,subprocess,sys,time
W=Path(__file__).resolve().parent
ROOT=W.parents[1]
BASE=Path('/Users/chenqiyue/Documents/Codex/2026-10-12/https-chatgpt-com-share-6acd35f5-5168/outputs/task16_geant4')
BIN=W/'build/task16_recess.app/Contents/MacOS/task16_recess'
SPEC=BASE/'inputs/spectra_unique.csv'
DATA=Path('/Users/chenqiyue/Library/CloudStorage/OneDrive-ImperialCollegeLondon/Radlab/task 16 data.xlsx')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
source=json.loads((ROOT/'outputs/task16_closest_three/processing_details.json').read_text())
assert sha(DATA)==source['source_sha256'],'Latest input changed; re-extract before running.'
ds=sorted({float(q['d_m']) for q in csv.DictReader((ROOT/'outputs/task16_closest_three/task16_selected_three.csv').open(encoding='utf-8-sig'))})
assert len(ds)==32
ENV=os.environ.copy()
ENV.pop('TASK16_GEOMETRY_VIEW',None);ENV.pop('TASK16_VIS_MACRO',None)
for key,name in [('G4LEDATA','EMLOW'),('G4LEVELGAMMADATA','PhotonEvaporation'),('G4RADIOACTIVEDATA','RadioactiveDecay'),('G4ENSDFSTATEDATA','ENSDFSTATE')]:
 ENV[key]=str(next((BASE.parents[1]/'.runtime/geant4/share/Geant4/data').glob(name+'*')))
phase=sys.argv[1] if len(sys.argv)>1 else 'production'
config={
 'production':dict(R=12,nsource=1000000,npop=12000,distances=ds,radius=11,seed=1740100000,mode='smc'),
 'direct':dict(R=2,nsource=100000,npop=1000,distances=[.01],radius=11,seed=1750100000,mode='direct'),
}[phase]
OUT=W/phase;OUT.mkdir(parents=True,exist_ok=True)
BH=sha(BIN);SH=sha(SPEC)
plan=dict(phase=phase,**config,binary_sha256=BH,spectrum_sha256=SH,data_sha256=sha(DATA),
 geometry_sha256=sha(W/'geometry.json'),geometry=json.loads((W/'geometry.json').read_text()),
 source_code_sha256=sha(W/'geant_recess.cc'),
 threshold_keV=10,aperture_radius_mm=5.5,detector_opening_mm=[10,10],offset_m=.016,
 pooling='All independently seeded complete batches retained; cross-distance covariance from full batch vectors. Replays are not independent source emissions.',
 comparison='Same latest Task16 closest-three selection and previous fixed calibration weights; no geometry/threshold/distance tuning.')
pf=OUT/'plan.json'
if pf.exists():assert json.loads(pf.read_text())==plan
else:pf.write_text(json.dumps(plan,indent=2)+'\n')
def run(rep):
 seed=config['seed']+rep*100003
 target=OUT/f'batch_{rep:02d}.csv';meta=target.with_suffix('.json')
 cmd=[str(BIN),str(SPEC),str(target),','.join(map(str,config['distances'])),str(config['nsource']),str(config['npop']),str(seed),'11','5.5',config['mode'],'10','10']
 if meta.exists():
  m=json.loads(meta.read_text());assert m['command']==cmd and m['binary_sha256']==BH;return
 assert sha(BIN)==BH and sha(W/'geometry.json')==plan['geometry_sha256']
 start=time.time()
 with target.with_suffix('.log').open('w') as log:subprocess.run(cmd,env=ENV,stdout=log,stderr=subprocess.STDOUT,check=True)
 rr=list(csv.DictReader(target.open()));assert len(rr)==6*len(config['distances'])
 assert all(float(q['aperture_diameter_mm'])==11 and float(q['emitter_diameter_mm'])==22 and float(q['detector_side_mm'])==10 for q in rr)
 text=target.with_suffix('.log').read_text()
 assert not any(s in text for s in ['G4Exception','Overlap is detected','Fatal','ERROR'])
 assert 'source_depth_mm=5 source_wall_mm=3.7 detector_depth_mm=2 detector_opening_mm=10x10' in text
 meta.write_text(json.dumps(dict(command=cmd,replicate=rep,seed=seed,binary_sha256=BH,spectrum_sha256=SH,
  geometry_sha256=plan['geometry_sha256'],elapsed_s=time.time()-start),indent=2)+'\n')
 print(f'Completed {phase} batch {rep+1}/{config["R"]}; {time.time()-start:.1f}s',flush=True)
def locked(rep):
 with (OUT/f'batch_{rep:02d}.lock').open('a') as f:
  fcntl.flock(f,fcntl.LOCK_EX);run(rep)
workers=int(sys.argv[2]) if len(sys.argv)>2 else 4
with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as pool:list(pool.map(locked,range(config['R'])))
