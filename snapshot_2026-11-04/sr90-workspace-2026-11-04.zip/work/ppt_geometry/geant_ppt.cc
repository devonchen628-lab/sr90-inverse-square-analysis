// PPT-constrained aperture/active area. Unspecified source layers are retained
// from the previously recorded source-5 scenario, not attributed to the PPT.
#include "smc_reuse_base.cc"
#include <chrono>

struct PPTModel { SMC c; double aperture_mm=5.5; };
class PPTGeometry:public G4VUserDetectorConstruction {
 PPTModel& a;
 public:explicit PPTGeometry(PPTModel& x):a(x){}
 G4VPhysicalVolume* Construct() override {
  auto& c=a.c;auto n=G4NistManager::Instance();auto air=n->FindOrBuildMaterial("G4_AIR");double W=c.world_half*m;
  auto world=new G4LogicalVolume(new G4Box("World",W,W,W),air,"World");
  auto pv=new G4PVPlacement(nullptr,{},world,"World",nullptr,false,0,true);
  auto al=n->FindOrBuildMaterial("G4_Al"),pmma=n->FindOrBuildMaterial("G4_PLEXIGLASS");
  auto box=[&](const G4String& name,double t,double z,G4Material* mat){
   auto lv=new G4LogicalVolume(new G4Box(name,25*mm,25*mm,t/2),mat,name);
   new G4PVPlacement(nullptr,{0,0,z},lv,name,world,false,0,true);
  };
  box("SourceAlFoil",.05*mm,.275*mm,al);box("SourceAcrylic",1*mm,.8*mm,pmma);
  auto tb=new G4Box("TopPlateBox",25*mm,25*mm,2.5*mm);
  auto hole=new G4Tubs("ExitHole",0,a.aperture_mm*mm,2.6*mm,0,twopi);
  auto top=new G4LogicalVolume(new G4SubtractionSolid("TopWithHole",tb,hole),al,"SourceTopPlate");
  new G4PVPlacement(nullptr,{0,0,3.8*mm},top,"SourceTopPlate",world,false,0,true);
  box("SourceBacking",1.5*mm,-1*mm,al);
  auto mother=world;double previous=0;
  for(unsigned i=0;i<c.planes.size();++i){
   double z=c.planes[i]*m,centre=(W+z)/2;auto name="Phase_"+std::to_string(i);
   auto lv=new G4LogicalVolume(new G4Box(name,W,W,(W-z)/2),air,name);
   new G4PVPlacement(nullptr,{0,0,centre-previous},lv,name,mother,false,0,true);
   mother=lv;previous=centre;
  }
  auto si=new G4LogicalVolume(new G4Box("Silicon",5*mm,5*mm,.15*mm),n->FindOrBuildMaterial("G4_Si"),"Silicon");
  new G4PVPlacement(nullptr,{0,0,c.r*m+.15*mm-previous},si,"Silicon",mother,false,0,true);
  return pv;
 }
};

int main(int argc,char** argv){
 if(argc<9){std::cerr<<"spectrum output distances nsource npop seed emitter_radius_mm aperture_radius_mm [smc|direct]\n";return 2;}
 PPTModel a;auto& c=a.c;c.nsource=std::stol(argv[4]);c.npop=std::stol(argv[5]);long seed=std::stol(argv[6]);
 c.source.radius_mm=std::stod(argv[7]);a.aperture_mm=std::stod(argv[8]);bool direct=argc>9&&std::string(argv[9])=="direct";
 // The legacy 4.875mm focus disk is an importance proposal only. Its exact
 // density correction is retained; it does not define this geometry's hole.
 if(c.source.radius_mm<4.875||a.aperture_mm<=0)throw std::runtime_error("Invalid PPT geometry/proposal support");
 c.source.source_case=true;c.source.smooth_importance=true;c.source.position_mix=.6;
 c.source.y_importance_cutoff=500;c.source.sr_sampling_fraction=.5;c.source.cut_mm=.01;
 c.planes={.006301};c.r=.9;c.uniform_mix=.1;c.tail_importance=1;
 std::ifstream spec(argv[1]);std::string line;std::getline(spec,line);
 while(std::getline(spec,line)){std::replace(line.begin(),line.end(),',',' ');std::istringstream f(line);int b;double E,F;f>>b>>E>>F;c.source.energy[b].push_back(E);c.source.cdf[b].push_back(F);}
 std::vector<double> ds;std::istringstream dl(argv[3]);while(std::getline(dl,line,','))ds.push_back(std::stod(line));
 if(direct&&ds.size()!=1)throw std::runtime_error("Direct validation uses one distance per process");
 auto planes=[&](double d){c.r=d+.016;double z=.006301,last=c.r-.001;c.planes={z};for(double f:{.25,.5,.75,.9})c.planes.push_back(z+f*(last-z));c.planes.push_back(last);};
 if(direct)planes(ds[0]);
 auto rm=new G4RunManager;G4Random::setTheSeed(seed);
 rm->SetUserInitialization(new PPTGeometry(a));rm->SetUserInitialization(new Physics(.01));
 rm->SetUserAction(new SMCGenerator(c));rm->SetUserAction(new SMCEvents(c));rm->SetUserAction(new SMCSteps(c));rm->SetUserAction(new SMCBoundaryBirths(c));
 G4EmParameters::Instance()->SetStepFunction(.1,10*um);rm->Initialize();
 auto start=std::chrono::steady_clock::now();std::vector<History> bank;
 if(!direct){c.stage=0;rm->BeamOn(c.nsource);bank=std::move(c.next);for(auto& h:bank)h.weight/=c.nsource;
  std::cout<<"SOURCE_BANK "<<bank.size()<<" original_events "<<c.nsource<<" elapsed_s "<<std::chrono::duration<double>(std::chrono::steady_clock::now()-start).count()<<std::endl;}
 std::ofstream out(argv[2]);out<<std::setprecision(15)<<"distance_m,active_distance_m,threshold_keV,probability,direct_se,nsource,npop,seed,emitter_diameter_mm,aperture_diameter_mm,detector_side_mm,source_yaw_deg,detector_yaw_deg,height_mm,mode\n";
 for(unsigned di=0;di<ds.size();++di){
  double d=ds[di];planes(d);c.score={};c.score_square={};
  if(direct){c.stage=-1;rm->BeamOn(c.nsource);}
  else {
   c.population=bank;c.stage=1;G4Random::setTheSeed(seed+1000000+di*10007);rm->ReinitializeGeometry(true);rm->Initialize();
   for(unsigned stage=1;stage<=c.planes.size();++stage){
    c.stage=stage;c.next.clear();if(c.population.empty())break;
    double total=0,focused=0;std::vector<double> focus;
    for(const auto& h:c.population){double v=importance(h,c);focus.push_back(v);total+=h.weight;focused+=h.weight*v;}
    c.selection.clear();c.cdf.clear();double sum=0;
    for(unsigned j=0;j<c.population.size();++j){double q=c.uniform_mix*c.population[j].weight/total+(1-c.uniform_mix)*c.population[j].weight*focus[j]/focused;c.selection.push_back(q);sum+=q;c.cdf.push_back(sum);}
    c.cdf.back()=1;rm->BeamOn(c.npop);
    if(stage<c.planes.size()){for(auto& h:c.next)h.weight/=c.npop;c.population=std::move(c.next);}
   }
  }
  double N=direct?c.nsource:c.npop;
  for(unsigned j=0;j<c.score.size();++j){
   double p=c.score[j]/N,se=direct?std::sqrt(std::max(0.,c.score_square[j]-c.score[j]*c.score[j]/N)/(N*(N-1))):0;
   out<<d<<','<<c.r<<','<<c.source.thresholds[j]<<','<<p<<','<<se<<','<<c.nsource<<','<<c.npop<<','<<seed<<','<<2*c.source.radius_mm<<','<<2*a.aperture_mm<<",10,0,0,0,"<<(direct?"direct":"smc")<<'\n';
  }
  out.flush();std::cout<<"DONE d "<<d<<" P10 "<<c.score[2]/N<<" elapsed_s "<<std::chrono::duration<double>(std::chrono::steady_clock::now()-start).count()<<std::endl;
 }
 delete rm;return 0;
}
