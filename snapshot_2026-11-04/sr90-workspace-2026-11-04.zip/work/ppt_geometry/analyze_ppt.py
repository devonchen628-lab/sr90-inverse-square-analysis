"""PPT geometry rerun: complete-batch errors, latest measurements only."""
from pathlib import Path
import csv,hashlib,json,sys
import numpy as np
from scipy.interpolate import PchipInterpolator
W=Path(__file__).resolve().parent;ROOT=W.parents[1];OUT=ROOT/'outputs/task16_ppt_geometry'
sys.path.insert(0,str(W.parent/'rigid_mount_resimulation'))
from task16_inputs import load,read

OUT.mkdir(parents=True,exist_ok=True)
(OUT/'geometry_parameters.csv').write_bytes((W/'geometry_parameters.csv').read_bytes())
def write(name,rows):
 with (OUT/name).open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

v=load();d=v['d'];r=v['r0'];data=v['selected'];M=len(d)
def batches(phase):
 folder=W/phase;plan=json.loads((folder/'plan.json').read_text());metas=sorted(folder.glob('batch_[0-9][0-9].json'))
 assert len(metas)==plan['R'],f'{phase}: complete fixed batch plan before analysis.'
 ds=np.array(plan['distances']);vectors=[];records=[];seeds=[]
 for f in metas:
  meta=json.loads(f.read_text());assert meta['binary_sha256']==plan['binary_sha256'];seeds.append(meta['seed'])
  rr=read(f.with_suffix('.csv'));assert len(rr)==len(ds)*6
  vector=[]
  for x in ds:
   dd=[q for q in rr if float(q['distance_m'])==x];assert len(dd)==6
   assert [float(q['threshold_keV']) for q in dd]==[.1,5,10,20,40,60]
   p=np.array([float(q['probability']) for q in dd]);assert (p>=0).all() and (np.diff(p)<=1e-16).all()
   for q in dd:
    assert float(q['aperture_diameter_mm'])==11 and float(q['emitter_diameter_mm'])==2*plan['radius']
    assert float(q['detector_side_mm'])==10 and abs(float(q['active_distance_m'])-x-.016)<1e-12
    assert all(float(q[k])==0 for k in ['source_yaw_deg','detector_yaw_deg','height_mm'])
    assert int(q['seed'])==meta['seed']
    records.append(dict(phase=phase,batch=meta['replicate'],**q))
   vector.extend(p)
  vectors.append(vector)
 assert len(seeds)==len(set(seeds))
 a=np.array(vectors);mean=a.mean(0);V=np.cov(a,rowvar=False,ddof=1)/len(a)
 return dict(plan=plan,d=ds,vectors=a,p=mean.reshape(len(ds),6),V=V,records=records)

main=batches('production');control=batches('disk11_control')
assert np.array_equal(main['d'],d)
assert main['plan']['data_sha256']==v['source']['source_sha256']
assert hashlib.sha256(Path(v['source']['source']).read_bytes()).hexdigest()==main['plan']['data_sha256']
assert main['plan']['ppt_sha256']==hashlib.sha256(Path('/Users/chenqiyue/Downloads/RadioactivitySetup.pptx').read_bytes()).hexdigest()
ix=np.arange(M)*6+2;p=main['p'][:,2];VP=main['V'][np.ix_(ix,ix)];sp=np.sqrt(np.maximum(0,np.diag(VP)))
assert (p>0).all()
def calibration(prob,Vprob):
 g=PchipInterpolator(np.log(r),np.log(prob)).derivative()(np.log(r))/r
 Vmc=Vprob/np.outer(prob,prob)
 Vdist=np.diag((g*v['sd'])**2)+np.outer(g*v['soff'],g*v['soff'])
 V=data['Vy']+Vmc+Vdist
 # Freeze the prior correlated-GLS calibration weights, so a change in the
 # normalization rule cannot masquerade as a geometry effect. Propagate the
 # NEW complete-batch covariance with these same fixed weights.
 weights=data['w'].copy()
 A=np.exp(weights@(np.log(data['net'])-np.log(prob)))
 H=np.eye(M)-np.outer(np.ones(M),weights)
 return dict(A=A,weights=weights,V=V,Vratio=H@V@H.T,slogA=np.sqrt(weights@V@weights),ratio=data['net']/(A*prob),g=g)
cal=calibration(p,VP);old=calibration(v['p0'],np.diag(v['sp0']**2));A=cal['A'];ratio=cal['ratio']
assert np.isclose(old['A'],data['A'],rtol=1e-12)
uy=A*p*r*r;usy=A*sp*r*r;old_u=old['A']*v['p0']*r*r
su=np.sqrt(np.diag(data['Vu']));sr=ratio*np.sqrt(np.maximum(0,np.diag(cal['Vratio'])))
factor=p/v['p0'];VF=VP/np.outer(v['p0'],v['p0'])+np.diag((factor*v['sp0']/v['p0'])**2)
jack=[]
for b in range(len(main['vectors'])):
 q=np.delete(main['vectors'][:,ix],b,axis=0).mean(0)
 jack.append(q)
jack=np.array(jack);Vjack=(len(jack)-1)/len(jack)*((jack-jack.mean(0)).T@(jack-jack.mean(0)))
assert np.allclose(VP,Vjack,rtol=1e-8,atol=1e-25)
mc_rows=[]
for i,x in enumerate(d):
 for j,t in enumerate([.1,5,10,20,40,60]):
  k=6*i+j;mc_rows.append(dict(d_m=x,r_m=r[i],threshold_keV=t,probability=main['p'][i,j],probability_se=np.sqrt(max(0,main['V'][k,k])),independent_batches=len(main['vectors'])))
write('monte_carlo_summary_32.csv',mc_rows)
rows=[]
for i,x in enumerate(d):
 rows.append(dict(d_m=x,r_m=r[i],selected_counts=int(data['N'][i]),selected_time_s=data['T'][i],raw_rate_cps=data['C'][i],corrected_rate_cps=data['net'][i],
  measured_u=data['u'][i],measured_u_se=su[i],probability=p[i],probability_MC_se=sp[i],normalization=A,normalization_weights=cal['weights'][i],
  predicted_u=uy[i],predicted_u_MC_se=usy[i],data_over_prediction=ratio[i],data_over_prediction_se=sr[i],
  previous_probability=v['p0'][i],previous_probability_se=v['sp0'][i],previous_reference_u=old_u[i],previous_normalization=old['A'],
  aperture_change_probability_ratio=factor[i],aperture_change_ratio_se=np.sqrt(max(0,VF[i,i])),emitter_diameter_mm=22,aperture_diameter_mm=11,detector_side_mm=10))
write('latest_data_comparison_32.csv',rows)
write('complete_independent_batches.csv',main['records']+control['records'])
control_rows=[]
for i,x in enumerate(control['d']):
 j=int(np.flatnonzero(d==x)[0]);k=i*6+2;q=control['p'][i,2];sq=np.sqrt(max(0,control['V'][k,k]));f=q/p[j]
 sf=f*np.hypot(sq/q,sp[j]/p[j])
 control_rows.append(dict(d_m=x,main_emitter_diameter_mm=22,alternative_emitter_diameter_mm=11,aperture_diameter_mm=11,
  alternative_probability=q,alternative_probability_se=sq,alternative_over_main_probability=f,ratio_se=sf))
write('effective_disk11_control.csv',control_rows)
np.savez_compressed(OUT/'covariances.npz',d_m=d,probability_covariance_all_thresholds=main['V'],probability_covariance_10keV=VP,
 measured_u_covariance=data['Vu'],data_over_model_log_covariance=cal['Vratio'],geometry_change_factor_covariance=VF,
 alternative_covariance_all_thresholds=control['V'])

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'pdf.fonttype':42,'axes.spines.top':False,'axes.spines.right':False})
fig,(ax,bx)=plt.subplots(2,1,figsize=(11.2,8.8),sharex=True,gridspec_kw={'height_ratios':[1.3,1]})
fig.subplots_adjust(left=.10,right=.98,top=.875,bottom=.22,hspace=.14)
ax.errorbar(d*100,uy,yerr=usy,fmt='s',ms=4,color='#27834b',capsize=2,label='Geant4 rerun: PPT aperture diameter 11 mm',zorder=2)
ax.errorbar(d*100,data['u'],yerr=su,fmt='o',ms=4,color='#202020',capsize=2,label='Latest Task16 data: closest-three mean',zorder=3)
ax.set_ylabel(r'$C_{\rm corrected}(d+16\,\mathrm{mm})^2$ (m$^2$ s$^{-1}$)');ax.legend(fontsize=9,loc='best')
bx.errorbar(d*100,ratio,yerr=sr,fmt='o',ms=4,color='#27834b',capsize=2);bx.axhline(1,color='#888888',lw=1)
bx.set(xlabel='Recorded gap d (cm)',ylabel='Measured / predicted rate',xlim=(0,88))
for a in [ax,bx]:a.grid(alpha=.16)
fig.suptitle('PPT geometry rerun versus latest Task16 measurements',fontsize=15,y=.965)
fig.text(.5,.920,'32 actual Geant4 distances; air transport; one fitted overall amplitude; geometry not fitted',ha='center',fontsize=9.5)
fig.text(.10,.132,'PPT: 11 mm aperture, 10 x 10 mm active detector, aligned parallel planes. Internal emitter: prior 22 mm source drawing.',fontsize=8)
fig.text(.10,.093,'Distance: recorded d + measured 16 mm recess offset. No extra gap or assumed angular misalignment.',fontsize=8.1)
fig.text(.10,.054,'Inherited source layers and 10 keV counting threshold remain assumptions; bars exclude unmeasured apparatus systematics.',fontsize=8)
fig.text(.10,.020,'Latest table only; closest-three selection retained. MC errors from 12 independent complete batches; no formal fit p-value.',fontsize=8)
for ext in ['png','pdf']:fig.savefig(OUT/f'ppt_geometry_vs_latest.{ext}',dpi=200)
plt.close(fig)

fig,(ax,bx)=plt.subplots(2,1,figsize=(11.2,8.3),sharex=True,gridspec_kw={'height_ratios':[1.2,1]});fig.subplots_adjust(left=.10,right=.98,top=.87,bottom=.18,hspace=.15)
ax.errorbar(d*100,old_u,yerr=old['A']*v['sp0']*r*r,fmt='s',ms=3.5,color='#999999',capsize=2,label='Previous aperture 9.75 mm')
ax.errorbar(d*100,uy,yerr=usy,fmt='s',ms=3.5,color='#27834b',capsize=2,label='PPT aperture 11 mm')
ax.errorbar(d*100,data['u'],yerr=su,fmt='o',ms=3.5,color='#202020',capsize=2,label='Latest measurements');ax.legend(fontsize=8.5)
ax.set_ylabel(r'$C_{\rm corrected}r^2$ (m$^2$ s$^{-1}$)')
bx.errorbar(d*100,factor,yerr=np.sqrt(np.maximum(0,np.diag(VF))),fmt='o',ms=3.5,color='#27834b',capsize=2)
bx.axhline(1,color='#888888',lw=1);bx.set(xlabel='Recorded gap d (cm)',ylabel='New / old count probability',xlim=(0,88))
for a in [ax,bx]:a.grid(alpha=.16)
fig.suptitle('Effect of replacing the aperture geometry with the PPT dimension',fontsize=14,y=.96)
fig.text(.5,.915,'Same inherited source layers and 22 mm emitting disk; no alignment or distance parameters fitted',ha='center',fontsize=9)
fig.text(.10,.100,'Upper: one overall amplitude per geometry; prior calibration weights fixed identically for both curves.',fontsize=8.4)
fig.text(.10,.054,'Lower: unscaled per-source-event probability ratio, including MC errors. A larger aperture also changes the total acceptance.',fontsize=8.2)
for ext in ['png','pdf']:fig.savefig(OUT/f'aperture_change_comparison.{ext}',dpi=200)
plt.close(fig)

direct=[]
for f in sorted((W/'direct').glob('batch_*.csv')):
 direct.append(next(q for q in read(f) if float(q['threshold_keV'])==10))
dp=np.mean([float(q['probability']) for q in direct]);dse=np.sqrt(sum(float(q['direct_se'])**2 for q in direct))/len(direct)
pilot=np.array([[float(q['probability']) for q in read(f) if float(q['threshold_keV'])==10] for f in sorted((W/'pilot').glob('batch_*.csv'))])
direct_z=(dp-pilot[:,0].mean())/np.hypot(dse,pilot[:,0].std(ddof=1)/np.sqrt(len(pilot)))
direct_final_z=(dp-p[0])/np.hypot(dse,sp[0])
summary=dict(main_plan=main['plan'],control_plan=control['plan'],data_source=v['source']['source'],data_source_sha256=main['plan']['data_sha256'],
 number_of_distances=M,independent_batches=len(main['vectors']),new_source_events=main['plan']['R']*main['plan']['nsource']+control['plan']['R']*control['plan']['nsource'],
 staged_replay_events=main['plan']['R']*M*6*main['plan']['npop']+control['plan']['R']*len(control['d'])*6*control['plan']['npop'],
 normalization=A,normalization_log_standard_error=cal['slogA'],previous_normalization_same_method=old['A'],
 normalization_method='One weighted log-amplitude; correlated-GLS calibration weights frozen from the previous analysis and used identically for both geometries. New full MC covariance propagated. No shape, geometry or threshold fitting.',
 MC_relative_se_range=[float(min(sp/p)),float(max(sp/p))],MC_relative_se_at_85cm=float(sp[-1]/p[-1]),
 direct_validation=dict(distance_m=.01,direct_probability=dp,direct_se=dse,pilot_smc_probability=float(pilot[:,0].mean()),scaled_difference=float(direct_z),production_probability=float(p[0]),production_scaled_difference=float(direct_final_z)),
 closest_three_selection_retained=True,formal_fit_p_value=None,
 descriptive_log_ratio_RMS=float(np.sqrt(np.mean(np.log(ratio)**2))),
 selected_rows=[q for q in rows if q['d_m'] in [.01,.025,.05,.1,.3,.5,.85]],effective_disk_control=control_rows,
 limitations=['PPT labels a visible circular source region, not the buried radioactive material. The main model interprets 11mm as the aperture, retaining the prior source-5 drawing for the 22mm internal emitter.',
  'The inspected source-specific exploded drawing explicitly gives 9.75mm hole diameter and 22mm radioactive-material diameter. This differs from the PPT 11mm visible-circle label; the PPT scenario is not demonstrated to be a more accurate actual-device specification.',
  'The 11mm internal emitting disk is a separately labelled interpretation control at six distances, not a measured source parameter.',
  'Source-layer materials/thicknesses remain the previous scenario; active-layer self-absorption and detector entrance/threshold response are uncalibrated.',
  'PPT rail/posts have no numerical dimensions or material specification, so they constrain alignment but were not invented as scattering volumes.',
  'Data selection and repositioning systematics are excluded from nominal bars; one amplitude fitted to the same data is shape comparison, not independent activity validation.',
  'Finite independent batches estimate correlated MC uncertainty. Local scatter of Monte Carlo points is not automatically physical curvature.'])
(OUT/'analysis_summary.json').write_text(json.dumps(summary,indent=2)+'\n')
notes='''# 按PPT几何重跑：最新Task16数据

## 实际使用的尺寸与来源

PPT唯一一页标注源正面圆形区域直径11mm、探测器敏感区10×10mm，并画出同轴平行布置。主模型将11mm解释为正面出射圆口，内部22mm放射层沿用此前源5拆解图与确认记录。PPT没有给出内部放射层尺寸，不能将11mm无条件解释成内部放射层。另做有效发射区直径11mm、圆口直径11mm的6距离对照，明确作为另一种解释假设。

本轮还直接查看了原始源拆解图：明确标注Hole Diameter 9.75mm，以及Radioactive Material Diameter 22mm。PPT的11mm正面圆形区域与该孔径标注不同，可能不是同一几何边界，也可能只是示意尺寸；PPT本身不能裁定。按用户要求，本轮仍用11mm圆口作为名义尺寸情景，但不将其宣称为比源专用拆解图更准确的实测尺寸。

发射面到硅片前表面间距为r=d+16mm，16mm沿用用户此前确认的源侧7mm与探测器侧9mm退缩；不是PPT提供的数值。源内部封装厚度不再额外加入16mm。所有几何同轴、平行，没有5mm高差、5°偏转、底部转轴臂或额外5.2mm间距。

继承的0.05mm铝箔、1mmPMMA、5mm带孔铝上盖、1.5mm铝背板及50mm方形外轮廓，属于此前源组件情景，未伪称PPT给出了这些参数。硅片厚度300微米沿用实验讲义。放射层材料自吸收、真实探测器窗口与响应仍未标定。

PPT中轨道和支杆没有给出材料、宽度、高度等数值，因此本轮用其确定理想相对布局，未凭示意外观臆造轨道/支杆的粒子散射体。

## 计算和实验处理

Geant4真实输运，Livermore电磁物理、近似Sr/Y等权发射谱；原始事件及后代作为一个整体，硅片总沉积≥10keV计一次。六个阈值结果均保存，展示10keV预定定义，没有根据吻合程度挑阈值。分阶段源库重复使用提高计算效率，误差由独立完整批次之间的概率向量估计，保留跨距离协方差。

仅使用最新task 16 data.xlsx，继续按用户先前规则每距离取最接近的三次；没有混入旧23点或Book2。实验计数率按约1.999微秒有效恢复时间与共同背景修正。半刻度±0.5mm按均匀范围处理，公共16mm偏移标准不确定度0.577mm保留相关性。未把选择偏差与额外回位散布伪装进统计误差。

整体归一化仅有一项：保留此前含共同距离误差的GLS标定权重，分别对新旧概率求实测/概率对数比的加权平均。两条曲线用完全相同的固定权重，旧曲线归一化与此前一致，避免把标定方式变化混入几何效应。新模型的完整MC协方差仍用于误差传播；未拟合半径、角度、距离或阈值。新旧未缩放的每源事件概率比另列。归一化不是独立测得的源活度。本轮不报告正式拟合p值。

## 结果

'''
notes+=f"主模型12个完整批次，逐距离概率的相对MC标准误范围{100*min(sp/p):.1f}%–{100*max(sp/p):.1f}%；85cm为{100*sp[-1]/p[-1]:.1f}%。直接追踪近端对照与正式SMC的标准化差为{direct_final_z:.2f}，与试运行SMC为{direct_z:.2f}。\n\n"
for q in summary['selected_rows']:notes+=f"- d={100*q['d_m']:g}cm：实测/新预测={q['data_over_prediction']:.3f}±{q['data_over_prediction_se']:.3f}；新/旧每源事件计数概率={q['aperture_change_probability_ratio']:.3f}±{q['aperture_change_ratio_se']:.3f}。\n"
notes+='\n六点有效发射区解释对照详见effective_disk11_control.csv；其内部直径不是实测值，不将该对照与数据吻合作为尺寸证据。\n'
notes+='\n本轮为新几何的空气计算。此前真空结果采用9.75mm孔径，不能直接拿它与本轮11mm孔径空气结果作空气/真空比；介质对照应使用完全匹配的几何。\n'
(OUT/'analysis_zh.md').write_text(notes)
print(json.dumps({k:summary[k] for k in ['number_of_distances','independent_batches','new_source_events','staged_replay_events','normalization','MC_relative_se_range','MC_relative_se_at_85cm','direct_validation','descriptive_log_ratio_RMS']},indent=2))
