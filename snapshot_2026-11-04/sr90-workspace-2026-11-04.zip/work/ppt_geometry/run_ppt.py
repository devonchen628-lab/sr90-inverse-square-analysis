"""Frozen source geometry, reproducible independent complete Geant4 batches."""
from pathlib import Path
import concurrent.futures,csv,fcntl,hashlib,json,os,subprocess,sys,time
W=Path(__file__).resolve().parent
BASE=Path('/Users/chenqiyue/Documents/Codex/2026-10-12/https-chatgpt-com-share-6acd35f5-5168/outputs/task16_geant4')
BIN=W.parent/'air_vacuum_check/vacuum_scan/build/task16_ppt';SPEC=BASE/'inputs/spectra_unique.csv'
PPT=Path('/Users/chenqiyue/Downloads/RadioactivitySetup.pptx')
DATA=Path('/Users/chenqiyue/Library/CloudStorage/OneDrive-ImperialCollegeLondon/Radlab/task 16 data.xlsx')
ENV=os.environ.copy()
for key,name in [('G4LEDATA','EMLOW'),('G4LEVELGAMMADATA','PhotonEvaporation'),('G4RADIOACTIVEDATA','RadioactiveDecay'),('G4ENSDFSTATEDATA','ENSDFSTATE')]:
 ENV[key]=str(next((BASE.parents[1]/'.runtime/geant4/share/Geant4/data').glob(name+'*')))
phase=sys.argv[1] if len(sys.argv)>1 else 'production'
ds=sorted({float(q['distance_m']) for q in csv.DictReader((BASE/'results/book2_dense_comparison/mc_summary_32_distances.csv').open())})
config={
 'pilot':dict(R=4,nsource=100000,npop=3000,distances=[.01,.1,.5,.85],radius=11,seed=1690100000,mode='smc'),
 'pilot_tail':dict(R=4,nsource=100000,npop=3000,distances=[.85],radius=11,seed=1692100000,mode='smc'),
 'direct':dict(R=2,nsource=100000,npop=1000,distances=[.01],radius=11,seed=1720100000,mode='direct'),
 'production':dict(R=12,nsource=1000000,npop=12000,distances=ds,radius=11,seed=1700100000,mode='smc'),
 'disk11_control':dict(R=8,nsource=300000,npop=10000,distances=[.01,.025,.05,.1,.5,.85],radius=5.5,seed=1710100000,mode='smc')
}[phase]
OUT=W/phase;OUT.mkdir(parents=True,exist_ok=True)
BH=hashlib.sha256(BIN.read_bytes()).hexdigest();SH=hashlib.sha256(SPEC.read_bytes()).hexdigest()
plan=dict(phase=phase,**config,aperture_radius_mm=5.5,detector_side_mm=10,offset_m=.016,threshold_keV=10,
 binary_sha256=BH,spectrum_sha256=SH,ppt_sha256=hashlib.sha256(PPT.read_bytes()).hexdigest(),data_sha256=hashlib.sha256(DATA.read_bytes()).hexdigest(),
 source_provenance=dict(ppt='11mm visible circular source region interpreted as aperture; 10x10mm detector active area; aligned parallel arrangement.',
  prior_source_drawing='Main 22mm emitting layer retained from previously supplied source-5 exploded drawing; internal dimensions not specified by PPT.',
  alternative='11mm uniform emitting disk is an explicitly assumed interpretation, tested at six actual distances.',
  inherited='0.05mm Al foil, 1mm PMMA, 5mm Al upper plate, 1.5mm Al backing; same approximate beta spectra and Livermore EM.',
  metrology='16mm=9mm detector recess+7mm source recess from prior confirmed rail references; internal source layers not added a second time.',
  limitations='Active material self-absorption and detector entrance/window/threshold remain uncalibrated. No measured misalignment; zero height/yaw/base-pitch.'),
 pooling='Every completed independent batch retained; covariance across distances/thresholds from complete batch vectors. No conditional replay-count SE.')
pf=OUT/'plan.json'
if pf.exists():assert json.loads(pf.read_text())==plan
else:pf.write_text(json.dumps(plan,indent=2)+'\n')
def run(rep):
 seed=config['seed']+rep*100003;target=OUT/f'batch_{rep:02d}.csv';meta=target.with_suffix('.json')
 cmd=[str(BIN),str(SPEC),str(target),','.join(map(str,config['distances'])),str(config['nsource']),str(config['npop']),str(seed),str(config['radius']),'5.5',config['mode']]
 if meta.exists():
  m=json.loads(meta.read_text());assert m['command']==cmd and m['binary_sha256']==BH;return
 start=time.time()
 with target.with_suffix('.log').open('w') as f:subprocess.run(cmd,env=ENV,stdout=f,stderr=subprocess.STDOUT,check=True)
 rr=list(csv.DictReader(target.open()));assert len(rr)==6*len(config['distances'])
 assert all(float(q['aperture_diameter_mm'])==11 and float(q['emitter_diameter_mm'])==2*config['radius'] and float(q['detector_side_mm'])==10 for q in rr)
 text=target.with_suffix('.log').read_text();assert not any(s in text for s in ['G4Exception','Overlap is detected','Fatal','ERROR'])
 meta.write_text(json.dumps(dict(command=cmd,replicate=rep,seed=seed,binary_sha256=BH,spectrum_sha256=SH,elapsed_s=time.time()-start),indent=2)+'\n')
 print(f'Completed {phase} batch {rep+1}/{config["R"]}; {time.time()-start:.1f}s',flush=True)
def run_locked(rep):
 with (OUT/f'batch_{rep:02d}.lock').open('a') as lock:
  fcntl.flock(lock,fcntl.LOCK_EX)
  run(rep)
if __name__=='__main__':
 workers=int(sys.argv[2]) if len(sys.argv)>2 else 4
 with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as pool:list(pool.map(run_locked,range(config['R'])))
