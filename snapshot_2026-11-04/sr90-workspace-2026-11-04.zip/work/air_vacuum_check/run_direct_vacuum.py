"""Independent direct-transport vacuum controls; preserve every completed run."""
from pathlib import Path
import concurrent.futures
import csv
import hashlib
import json
import os
import subprocess
import sys
import time

BASE=Path('/Users/chenqiyue/Documents/Codex/2026-10-12/https-chatgpt-com-share-6acd35f5-5168/outputs/task16_geant4')
OUT=Path('/Users/chenqiyue/Documents/Codex/2026-10-29/r/work/air_vacuum_check/direct_vacuum')
OUT.mkdir(parents=True,exist_ok=True)
ENV=os.environ.copy()
PREFIX=BASE.parents[1]/'.runtime/geant4'
for key,name in [('G4LEDATA','EMLOW'),('G4LEVELGAMMADATA','PhotonEvaporation'),('G4RADIOACTIVEDATA','RadioactiveDecay'),('G4ENSDFSTATEDATA','ENSDFSTATE')]:
    matches=list((PREFIX/'share/Geant4/data').glob(name+'*'))
    if matches:ENV[key]=str(matches[0])
BINARY=BASE/'build/task16_smc_medium'
BINARY_HASH=hashlib.sha256(BINARY.read_bytes()).hexdigest()
SPECTRUM=BASE/'inputs/spectra_unique.csv'

def run(job):
    d,rep=job
    name=f'd{round(d*1e6):06d}_r{rep:02d}'
    target=OUT/(name+'.csv')
    meta=OUT/(name+'.json')
    seed=2071000000+round(d*1e4)*101+rep*100003
    cmd=[str(BINARY),str(SPECTRUM),str(target),str(d),'500000','25000',str(seed),'direct','.1','4','.01','6','1','vacuum']
    if target.exists() and meta.exists():
        saved=json.loads(meta.read_text())
        assert saved['command']==cmd and saved['binary_sha256']==BINARY_HASH
        return
    start=time.time()
    with (OUT/(name+'.log')).open('w') as f:
        subprocess.run(cmd,env=ENV,stdout=f,stderr=subprocess.STDOUT,check=True)
    rows=list(csv.DictReader(target.open()))
    assert len(rows)==6
    point=next(r for r in rows if float(r['threshold_keV'])==10)
    meta.write_text(json.dumps(dict(distance_m=d,replicate=rep,seed=seed,source_events=500000,
        medium='vacuum',mode='direct',command=cmd,binary_sha256=BINARY_HASH,
        spectrum_sha256=hashlib.sha256(SPECTRUM.read_bytes()).hexdigest(),
        elapsed_seconds=time.time()-start),indent=2)+'\n')
    print(f'Completed d={d:g} m, replicate={rep}, p={float(point["probability"]):.6g}, elapsed={time.time()-start:.1f}s',flush=True)

if __name__=='__main__':
    jobs=([( .8,rep) for rep in range(8,16)] if '--extra-far' in sys.argv
          else [(d,rep) for rep in range(8) for d in [.1,.3,.8]])
    t0=time.time()
    with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool:
        list(pool.map(run,jobs))
    print(f'Finished {len(jobs)} independent runs, {len(jobs)*500000:,} source electrons; elapsed={time.time()-t0:.1f}s',flush=True)
