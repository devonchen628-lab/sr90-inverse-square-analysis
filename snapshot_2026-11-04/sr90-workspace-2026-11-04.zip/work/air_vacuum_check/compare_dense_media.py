"""Dense vacuum / air comparison with covariance from shared source histories."""
from pathlib import Path
import csv,json,math,hashlib,sys
import numpy as np
from compare_media import read,normalized

ROOT=Path('/Users/chenqiyue/Documents/Codex/2026-10-29/r')
BASE=Path('/Users/chenqiyue/Documents/Codex/2026-10-12/https-chatgpt-com-share-6acd35f5-5168/outputs/task16_geant4')
WORK=ROOT/'work/air_vacuum_check'
PRECISION='--precision' in sys.argv
OUT=ROOT/('outputs/task16_air_vacuum_precision32' if PRECISION else 'outputs/task16_air_vacuum_dense32')
OUT.mkdir(parents=True,exist_ok=True)

def write(name,rows):
    with (OUT/name).open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

fit=json.loads((BASE/'results/book2_dense_comparison/fit_summary.json').read_text())
A=next(q['normalization'] for q in fit['reports'] if q['threshold_keV']==10)
tau=fit['effective_recovery_us']*1e-6;stau=fit['recovery_fit_only_se_us']*1e-6
B=fit['background_rate'];sB=fit['background_rate_se'];offset=fit['offset_m']
data=read(ROOT/'outputs/task16_closest_three/task16_selected_three.csv')
d=np.array([float(q['d_m']) for q in data]);r=d+offset
C=np.array([float(q['mean_rate_cps']) for q in data]);sC=np.array([float(q['nominal_poisson_rate_se_cps']) for q in data])
sd=np.array([float(q['d_unc_m']) for q in data])
net=C/(1-tau*C)-B/(1-tau*B);u=net*r*r
V=np.diag((r*r*sC/(1-tau*C)**2)**2+(2*r*net*sd)**2)
db=-r*r*sB/(1-tau*B)**2;dt=r*r*stau*(C*C/(1-tau*C)**2-B*B/(1-tau*B)**2)
V+=np.outer(db,db)+np.outer(dt,dt)
ref=int(np.where(np.isclose(d,.1))[0][0]);dn,dV=normalized(u,V,ref)
air=[q for q in read(BASE/'results/book2_dense_comparison/mc_summary_32_distances.csv') if float(q['threshold_keV'])==10]
assert np.array_equal([float(q['distance_m']) for q in air],d)
pa=np.array([float(q['probability']) for q in air]);sa=np.array([float(q['se']) for q in air])
ua=A*pa*r*r;Va=np.diag((A*sa*r*r)**2);an,aV=normalized(ua,Va,ref)

old_scan_metas=sorted((WORK/'scan_dense32').glob('run_*_filter1.json'))
precision_metas=sorted((WORK/'scan_precision64').glob('run_[0-9][0-9].json')) if PRECISION else []
assert len(old_scan_metas)==8
if PRECISION:assert len(precision_metas)==64,'Complete the fixed extension before plotting.'
metas=old_scan_metas+precision_metas
scan=[];records=[];seeds=[];total_n=0;event_squares=[]
for p in metas:
    m=json.loads(p.read_text());seeds.append(m['seed']);total_n+=m['source_events']
    rows=[q for q in read(p.with_suffix('.csv')) if float(q['threshold_keV'])==10]
    assert np.array_equal([float(q['distance_m']) for q in rows],d)
    assert len(rows)==32 and m['source_events']==(500000 if p in old_scan_metas else 1000000)
    assert m['binary_sha256']==hashlib.sha256((WORK/'vacuum_scan/build/task16_vacuum_scan').read_bytes()).hexdigest()
    scan.append([float(q['probability']) for q in rows])
    n=m['source_events']
    event_squares.append([n*(n-1)*float(q['unconditional_iid_se'])**2+n*float(q['probability'])**2 for q in rows])
    for q in rows:
        records.append(dict(distance_m=float(q['distance_m']),replicate=m['replicate'],seed=m['seed'],source_events=m['source_events'],probability=float(q['probability']),unconditional_iid_se=float(q['unconditional_iid_se']),source_exit_histories=int(q['source_exit_histories']),accepted_histories=int(q['accepted_histories']),shared_library_across_distances=True,metadata=str(p)))
assert len(set(seeds))==len(metas)
scan=np.array(scan)
# Pair the eight old 0.5M-event libraries into four equal 1M-event units.
# They are independent; this permits the usual complete-unit covariance.
if PRECISION:scan=np.concatenate([scan[:8].reshape(4,2,len(d)).mean(axis=1),scan[8:]],axis=0)
scan_mean=scan.mean(axis=0)
scan_cov=np.cov(scan,rowvar=False,ddof=1)/len(scan)
assert total_n==(68000000 if PRECISION else 4000000)
event_iid_se=np.sqrt(np.maximum(0,(np.sum(event_squares,axis=0)-total_n*scan_mean**2)/(total_n*(total_n-1))))

# Incorporate the three existing direct controls with fixed source-event
# weights. Their independent variances add only on the diagonal. Do not
# choose inverse-variance weights from noisy estimates of those variances.
old=read(ROOT/'outputs/task16_air_vacuum_comparison/vacuum_direct_summary.csv')
old_map={float(q['distance_m']):q for q in old}
weights=np.ones(len(d));pv=scan_mean.copy();old_diag=np.zeros(len(d))
old_events=np.zeros(len(d),dtype=int);old_reps=np.zeros(len(d),dtype=int)
for i,x in enumerate(d):
    if x in old_map:
        q=old_map[x];old_events[i]=int(q['source_events']);old_reps[i]=int(q['replicates'])
        weights[i]=total_n/(total_n+old_events[i])
        pv[i]=weights[i]*scan_mean[i]+(1-weights[i])*float(q['probability'])
        old_diag[i]=((1-weights[i])*float(q['se']))**2
Vp=np.outer(weights,weights)*scan_cov+np.diag(old_diag)
assert np.min(np.linalg.eigvalsh(Vp))>-1e-18
sv=np.sqrt(np.diag(Vp));uv=A*pv*r*r
Vu=Vp*np.outer(A*r*r,A*r*r);vn,vV=normalized(uv,Vu,ref)
assert np.isfinite(pv).all() and (pv>0).all()

rows=[]
for i,x in enumerate(d):
    ratio=pa[i]/pv[i]
    rows.append(dict(d_m=x,r_m=r[i],threshold_keV=10,
        data_corrected_u=u[i],data_corrected_u_se=math.sqrt(V[i,i]),data_relative_to_10cm=dn[i],data_relative_se=math.sqrt(max(0,dV[i,i])),
        air_probability=pa[i],air_probability_se=sa[i],air_corrected_u=ua[i],air_relative_to_10cm=an[i],air_relative_se=math.sqrt(max(0,aV[i,i])),
        vacuum_probability=pv[i],vacuum_probability_se=sv[i],vacuum_corrected_u=uv[i],vacuum_corrected_u_se=math.sqrt(Vu[i,i]),
        vacuum_relative_to_10cm=vn[i],vacuum_relative_se=math.sqrt(max(0,vV[i,i])),
        air_over_vacuum=ratio,air_over_vacuum_delta_method_se=ratio*math.hypot(sa[i]/pa[i],sv[i]/pv[i]),
        vacuum_relative_MC_se=sv[i]/pv[i],air_relative_MC_se=sa[i]/pa[i],vacuum_meets_5pct_target=bool(sv[i]/pv[i]<=.05),scan_source_events=total_n,scan_covariance_units=len(scan),
        old_direct_source_events=int(old_events[i]),old_direct_batches=int(old_reps[i]),scan_combination_weight=weights[i],
        scan_probability=scan_mean[i],scan_probability_se=math.sqrt(scan_cov[i,i]),scan_pooled_event_iid_se=event_iid_se[i],zero_scan_batches=int(sum(scan[:,i]==0))))
write('matched_media_comparison_32_distances.csv',rows)
write('vacuum_scan_independent_batches.csv',records)
np.savez_compressed(OUT/'vacuum_covariance.npz',distance_m=d,probability_covariance=Vp,corrected_u_covariance=Vu,normalized_u_covariance=vV,source_scan_probability_covariance=scan_cov)
covrows=[]
for i,x in enumerate(d):
    for j,y in enumerate(d):
        covrows.append(dict(d_i_m=x,d_j_m=y,probability_covariance=Vp[i,j],corrected_u_covariance=Vu[i,j],normalized_u_covariance=vV[i,j]))
write('vacuum_covariance.csv',covrows)

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11})
fig,(top,ax)=plt.subplots(2,1,figsize=(10.5,8.8),sharex=True)
fig.subplots_adjust(left=.095,right=.98,top=.875,bottom=.17,hspace=.12)
for axis,ydata,ydse,yair,yase,yvac,yvse in [
    (top,u,np.sqrt(np.diag(V)),ua,np.sqrt(np.diag(Va)),uv,np.sqrt(np.diag(Vu))),
    (ax,dn,np.sqrt(np.maximum(0,np.diag(dV))),an,np.sqrt(np.maximum(0,np.diag(aV))),vn,np.sqrt(np.maximum(0,np.diag(vV))))]:
    axis.errorbar(100*d,yvac,yerr=yvse,fmt='D',ms=4,mfc='white',mew=.9,color='#cf791b',ecolor='#d9a067',capsize=2,lw=.9,label='Geant4: vacuum (32 distances)',zorder=2)
    axis.errorbar(100*d,yair,yerr=yase,fmt='s',ms=3.7,color='#2c9346',capsize=2,lw=.8,label='Geant4: air (32 distances)',zorder=3)
    axis.errorbar(100*d,ydata,yerr=ydse,fmt='o',ms=3.5,color='#202020',capsize=2,lw=.8,label='Corrected measurements',zorder=4)
    axis.grid(alpha=.15);axis.spines['top'].set_visible(False);axis.spines['right'].set_visible(False)
top.set_ylabel(r'$C_{\rm corrected}r^2$ (m$^2$ s$^{-1}$)')
top.legend(fontsize=9,loc='best')
ax.axhline(1,color='#999999',lw=1);ax.axvline(10,color='#bbbbbb',ls=':',lw=1)
ax.set(xlabel='Rail gap d (cm)',ylabel='Relative to d = 10 cm',xlim=(0,88))
fig.suptitle('Matched Geant4 air / vacuum comparison: 32 distances',fontsize=15,y=.96)
fig.text(.5,.915,'Same source capsule, 10 x 10 x 0.3 mm Si, r = d + 16 mm, 10 keV threshold',ha='center',fontsize=10)
fig.text(.095,.108,'Top: same previous source normalization. Bottom: each series divided by its own 10 cm value.',fontsize=8.4)
fig.text(.095,.074,f'Bars: standard errors. Vacuum uses {len(scan)} independent equal-event units; shared-distance covariance is retained.',fontsize=8.3)
fig.text(.095,.040,'Selected closest-three measurements; selection, repositioning and apparatus-model uncertainties are excluded.',fontsize=8.3)
fig.savefig(OUT/'air_vacuum_32_distances.png',dpi=200)
fig.savefig(OUT/'air_vacuum_32_distances.pdf');plt.close(fig)

validation=[]
for x in [.1,.3,.8]:
    i=int(np.where(np.isclose(d,x))[0][0]);q=old_map[x]
    denom=math.hypot(math.sqrt(scan_cov[i,i]),float(q['se']))
    validation.append(dict(d_m=x,scan_mean=scan_mean[i],old_direct_mean=float(q['probability']),difference_over_combined_se=(scan_mean[i]-float(q['probability']))/denom))
summary=dict(n_distances=len(d),scan_source_events=total_n,additional_source_events_this_extension=64000000 if PRECISION else 4000000,independent_source_libraries=len(metas),equal_event_covariance_units=len(scan),
    source_libraries_reused_across_distances=True,source_event_count_not_multiplied_by_distances=True,
    existing_independent_direct_source_events=sum(int(q['source_events']) for q in old),
    vacuum_se_method=f'Sample covariance of {len(scan)} independent equal-event probability vectors, divided by {len(scan)}; fixed source-event weighted pooling of independent existing direct controls at 0.1/0.3/0.8 m.',
    normalization=A,normalization_refitted=False,threshold_keV=10,offset_m=offset,
    validation_against_existing_direct=validation,relative_MC_se_range=[float(min(sv/pv)),float(max(sv/pv))],
    scan_pooled_event_relative_se_range=[float(min(event_iid_se/scan_mean)),float(max(event_iid_se/scan_mean))],
    precision_target_met=bool(max(sv/pv)<=.05),
    points_meeting_5pct_target=int(sum(sv/pv<=.05)),
    limitations='Nominal 10 keV threshold and apparatus-material assumptions remain. Errors exclude unknown common distance zero, selection and repositioning errors. No formal goodness-of-fit claim.',
    selected_rows=[rows[i] for i in range(len(d)) if d[i] in [.1,.3,.8]])
(OUT/'comparison_details.json').write_text(json.dumps(summary,indent=2)+'\n')
notes=f'''# 32距离空气／真空对照

真空补至32个与原空气、实测完全对应的距离。新增8个独立源历史库，每库500,000个初始源事件，总计4,000,000个真实新增源事件；每个库用于全部32个距离的真空输运，不能算成128,000,000个独立事件。所有完成批次保留，不删异常值或零值。

封装输运至z=6.301 mm出口平面，保留同一源事件的全部粒子及其原重要性权重，再在各距离用Geant4计算Si能量沉积。在真空中不穿过Si的前向直线轨迹可以直接记零；任何后向状态均保留。源封装和Si相互作用仍由Geant4输运。已完成有／无直线预筛选的对照；独立旧普通输运对照也保留。

误差由8个独立库的完整32维概率向量的样本协方差除以8得到。10、30、80 cm另有旧普通输运控制；按各自真实源事件数预设权重合并，独立方差加到协方差对角线。归一化误差保留共同10 cm分母及跨距离相关性。完整协方差另存CSV及NPZ。只有8个新独立库，不能依靠该低秩估计做严格多点拟合优度检验。

模型源封装、10×10×0.3 mm Si、r=d+16 mm、名义10 keV阈值与之前相同。上图两介质用相同旧源归一化，没有重新拟合。下图各序列除以自身10 cm值。每个菱形均为实际模拟点，未用插值或平滑生成数据。

数据仍按用户之前要求采用最近三次筛选；误差没有涵盖筛选、回位、未知公共距离零点和装置模型误差。统计误差为条件标准误差，不能当作完整模型准确度。真空仍保留封装和有限几何，Cr²不必恒定；空气和真空的差异才是本模型中改变空气介质的净影响。
'''
if PRECISION:
    notes=f'''# 提高统计量后的32距离空气／真空对照

本轮固定增加64个独立批次，每批1,000,000个初始源事件，总计64,000,000个。全部批次保留，包含零计数或高权重批次。加上原有8批各500,000个事件，源历史扫描总共68,000,000个真实源事件。这些历史各用于32距离，不能将其乘32后称为独立源事件数。

统计时将原有8个半百万批次顺序两两合成4个百万事件单元，与新增64个百万事件单元一起构成68个独立等事件数单元。采用其32维概率向量的样本协方差除以68。另保留10/30/80 cm处原普通输运控制，按源事件数预设权重合并，独立控制的方差只加在协方差对角线上。图中误差由独立单元间差异估计，同时另存单事件权重二阶矩给出的标准误差作诊断。归一化误差保留共同10 cm分母及跨距离相关性。

源、封装、Si、r=d+16 mm、名义10 keV阈值及源归一化均不变。封装到出口后真空输运的方法与上一版相同。所有菱形来自真实Geant4计算，没有插值、平滑或依实验数据调整真空曲线。旧版本保留。

本轮目标是真空各点相对抽样标准误差不超过5%，不是将误差人为设为同一数值。空气仍用原32点模拟。实验仍按先前指定的最近三次筛选，误差未包含筛选、回位、公共距离零点或模型材料/阈值误差；当前比较不提供完整模型准确度或正式拟合优度结论。
'''
(OUT/'comparison_notes_zh.md').write_text(notes)
print(json.dumps({k:v for k,v in summary.items() if k!='selected_rows'},indent=2))
