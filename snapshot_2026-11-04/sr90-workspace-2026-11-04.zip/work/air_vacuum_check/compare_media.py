"""Compare matched Geant4 media; keep the same normalization and threshold."""
from pathlib import Path
import csv
import hashlib
import json
import math
import numpy as np

ROOT=Path('/Users/chenqiyue/Documents/Codex/2026-10-29/r')
BASE=Path('/Users/chenqiyue/Documents/Codex/2026-10-12/https-chatgpt-com-share-6acd35f5-5168/outputs/task16_geant4')
RUNS=ROOT/'work/air_vacuum_check/direct_vacuum'
OUT=ROOT/'outputs/task16_air_vacuum_comparison'
OUT.mkdir(exist_ok=True,parents=True)

def read(path):
    with path.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))

def write(name,rows):
    with (OUT/name).open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

def normalized(values,cov,ref):
    j=np.eye(len(values))/values[ref]
    j[:,ref]-=values/values[ref]**2
    return values/values[ref],j@cov@j.T

def main():
    fit=json.loads((BASE/'results/book2_dense_comparison/fit_summary.json').read_text())
    A=next(r['normalization'] for r in fit['reports'] if r['threshold_keV']==10)
    tau=fit['effective_recovery_us']*1e-6;stau=fit['recovery_fit_only_se_us']*1e-6
    B=fit['background_rate'];sB=fit['background_rate_se'];offset=fit['offset_m']
    data=read(ROOT/'outputs/task16_closest_three/task16_selected_three.csv')
    d=np.array([float(r['d_m']) for r in data]);r=d+offset
    C=np.array([float(a['mean_rate_cps']) for a in data]);sC=np.array([float(a['nominal_poisson_rate_se_cps']) for a in data])
    sd=np.array([float(a['d_unc_m']) for a in data])
    net=C/(1-tau*C)-B/(1-tau*B)
    u=net*r*r
    V=np.diag((r*r*sC/(1-tau*C)**2)**2+(2*r*net*sd)**2)
    db=-r*r*sB/(1-tau*B)**2;dt=r*r*stau*(C*C/(1-tau*C)**2-B*B/(1-tau*B)**2)
    V+=np.outer(db,db)+np.outer(dt,dt)
    ref=int(np.where(np.isclose(d,.1))[0][0]);dn,dV=normalized(u,V,ref)
    air=[a for a in read(BASE/'results/book2_dense_comparison/mc_summary_32_distances.csv') if float(a['threshold_keV'])==10]
    assert [float(a['distance_m']) for a in air]==list(d)
    pa=np.array([float(a['probability']) for a in air]);sa=np.array([float(a['se']) for a in air])
    ua=A*pa*r*r;Va=np.diag((A*sa*r*r)**2);an,aV=normalized(ua,Va,ref)
    records=[];vac=[]
    for dist in [.1,.3,.8]:
        metas=sorted(RUNS.glob(f'd{round(dist*1e6):06d}_r*.json'))
        assert len(metas)>=8,f'Incomplete direct controls at {dist}: {len(metas)}'
        vals=[];ses=[];events=[]
        for p in metas:
            cfg=json.loads(p.read_text());row=next(a for a in read(p.with_suffix('.csv')) if float(a['threshold_keV'])==10)
            assert cfg['medium']=='vacuum' and cfg['mode']=='direct' and int(row['nsource'])==500000
            assert float(row['offset_m'])==offset and float(row['world_half_m'])==4 and float(row['cut_mm'])==.01
            vals.append(float(row['probability']));ses.append(float(row['conditional_replay_se']));events.append(int(row['nsource']))
            records.append(dict(distance_m=dist,replicate=cfg['replicate'],seed=cfg['seed'],source_events=events[-1],probability=vals[-1],direct_iid_event_se=ses[-1],mode='direct',medium='vacuum',metadata=str(p)))
        vals=np.array(vals);ses=np.array(ses);n=np.array(events);N=int(n.sum());P=float(vals.mean());R=len(vals)
        se_between=float(vals.std(ddof=1)/np.sqrt(R))
        squares=np.sum(n*(n-1)*ses**2+n*vals**2)
        se_iid=float(np.sqrt(max(0,(squares-N*P*P)/(N*(N-1)))))
        # Mean uncertainty estimated between independent complete runs. The
        # pooled iid-event result is retained as a diagnostic, not cherry-picked.
        vac.append(dict(distance_m=dist,probability=P,se=se_between,pooled_iid_se=se_iid,
            relative_se=se_between/P if P else None,replicates=R,source_events=N,
            zero_replicas=int(sum(vals==0)),minimum_replica=float(vals.min()),maximum_replica=float(vals.max())))
    vd=np.array([a['distance_m'] for a in vac]);vr=vd+offset
    pv=np.array([a['probability'] for a in vac]);sv=np.array([a['se'] for a in vac])
    uv=A*pv*vr*vr;Vv=np.diag((A*sv*vr*vr)**2);vn,vV=normalized(uv,Vv,0)
    comparison=[]
    for i,x in enumerate(vd):
        ix=int(np.where(np.isclose(d,x))[0][0])
        ratio=pa[ix]/pv[i]
        ratio_se=ratio*math.hypot(sa[ix]/pa[ix],sv[i]/pv[i])
        comparison.append(dict(d_m=x,r_m=vr[i],data_corrected_u=u[ix],data_corrected_u_se=math.sqrt(V[ix,ix]),
            data_relative_to_10cm=dn[ix],data_relative_se=math.sqrt(max(0,dV[ix,ix])),
            air_probability=pa[ix],air_probability_se=sa[ix],vacuum_probability=pv[i],vacuum_probability_se=sv[i],
            air_corrected_u=ua[ix],vacuum_corrected_u=uv[i],
            air_relative_to_10cm=an[ix],air_relative_se=math.sqrt(max(0,aV[ix,ix])),
            vacuum_relative_to_10cm=vn[i],vacuum_relative_se=math.sqrt(max(0,vV[i,i])),
            air_over_vacuum=ratio,air_over_vacuum_delta_method_se=ratio_se,
            vacuum_relative_MC_se=sv[i]/pv[i],vacuum_independent_replicates=vac[i]['replicates']))
    write('matched_media_comparison.csv',comparison)
    write('vacuum_direct_independent_runs.csv',records)
    write('vacuum_direct_summary.csv',vac)
    plotrows=[]
    for i,x in enumerate(d):
        plotrows.append(dict(d_m=x,data_relative_to_10cm=dn[i],data_relative_se=math.sqrt(max(0,dV[i,i])),
            air_relative_to_10cm=an[i],air_relative_se=math.sqrt(max(0,aV[i,i])),
            data_corrected_u=u[i],air_corrected_u=ua[i]))
    write('comparison_plot_data.csv',plotrows)
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11})
    fig,(top,ax)=plt.subplots(2,1,figsize=(10,8.3),sharex=True,gridspec_kw={'height_ratios':[1,1]})
    fig.subplots_adjust(left=.095,right=.98,top=.87,bottom=.17,hspace=.12)
    top.errorbar(100*d,ua,yerr=np.sqrt(np.diag(Va)),fmt='s',ms=3.5,color='#2c9346',capsize=2,alpha=.85,label='Geant4: air')
    top.errorbar(100*d,u,yerr=np.sqrt(np.diag(V)),fmt='o',ms=4,color='#202020',capsize=2,label='Corrected measurements',zorder=4)
    top.errorbar(100*vd,uv,yerr=np.sqrt(np.diag(Vv)),fmt='D',ms=6,mfc='white',color='#d38225',capsize=5,lw=1.5,label='Geant4: vacuum, new direct controls',zorder=5)
    top.set_ylabel(r'$C_{\rm corrected}r^2$ (m$^2$ s$^{-1}$)')
    top.legend(loc='best',fontsize=9)
    ax.errorbar(100*d,an,yerr=np.sqrt(np.maximum(0,np.diag(aV))),fmt='s',ms=3.5,color='#2c9346',capsize=2,alpha=.85,label='Geant4: air (32 distances)')
    ax.errorbar(100*d,dn,yerr=np.sqrt(np.maximum(0,np.diag(dV))),fmt='o',ms=4,color='#202020',capsize=2,label='Measurements: distance, recovery and background corrected',zorder=4)
    ax.errorbar(100*vd,vn,yerr=np.sqrt(np.maximum(0,np.diag(vV))),fmt='D',ms=6,mfc='white',color='#d38225',capsize=5,lw=1.5,label='Geant4: vacuum (new independent direct runs)',zorder=5)
    ax.axhline(1,color='#999999',lw=1);ax.axvline(10,color='#bbbbbb',ls=':',lw=1)
    ax.set(xlabel='Rail gap d (cm)',ylabel='Relative to d = 10 cm',xlim=(0,88))
    for axis in [top,ax]:
        axis.grid(alpha=.15);axis.spines['top'].set_visible(False);axis.spines['right'].set_visible(False)
    fig.suptitle('Does air transport explain the remaining distance dependence?',fontsize=15,y=.96)
    fig.text(.5,.915,'Same source case, 10 x 10 x 0.3 mm Si, r = d + 16 mm, 10 keV threshold',ha='center',fontsize=10)
    fig.text(.095,.105,'Top: same previous source normalization for both media. Bottom: each series divided by its own 10 cm value.',fontsize=8.5)
    fig.text(.095,.068,'Bars: counting / ruler and independent MC sampling SE; shared zero-offset and apparatus-model errors are excluded.',fontsize=8.2)
    fig.text(.095,.032,'Measurements retain the requested closest-three selection; selection / repositioning uncertainty is excluded.',fontsize=8.2)
    fig.savefig(OUT/'air_vacuum_vs_measurements.png',dpi=190)
    fig.savefig(OUT/'air_vacuum_vs_measurements.pdf')
    plt.close(fig)
    summary=dict(geometry='Same source capsule, silicon geometry, +16 mm offset, 10 keV scoring threshold; only medium changed. Direct controls use same executable as earlier vacuum SMC.',
        normalization=A,normalization_refitted=False,shape_reference_gap_m=.1,
        new_vacuum_source_events=sum(a['source_events'] for a in vac),
        new_vacuum_replicates=sum(a['replicates'] for a in vac),
        vacuum_se_method='SD of complete independent direct-run probabilities / sqrt(replicates). Zeros and high-weight runs are retained.',
        note='The earlier 100,000-event pilot is a separate diagnostic and is not one of the equal-sized 500,000-event primary replicas.',
        input_data_csv=str(ROOT/'outputs/task16_closest_three/task16_selected_three.csv'),
        limitations='Threshold and some source/detector material inputs remain assumptions. No exact statistical confidence or absolute activity inference is made from the selected measurements.',comparison=comparison)
    raw=read(ROOT/'outputs/task16_closest_three/task16_all_measurements.csv')
    complete_u={}
    for x in [.1,.3,.8]:
        rr=[a for a in raw if float(a['d_m'])==x]
        rate=sum(int(a['counts']) for a in rr)/sum(float(a['time_s']) for a in rr)
        complete_u[x]=(rate/(1-tau*rate)-B/(1-tau*B))*(x+offset)**2
    summary['all_measurements_sensitivity']={str(x):complete_u[x]/complete_u[.1] for x in [.1,.3,.8]}
    (OUT/'comparison_details.json').write_text(json.dumps(summary,indent=2)+'\n')
    print(json.dumps(summary,indent=2))

if __name__=='__main__':main()
