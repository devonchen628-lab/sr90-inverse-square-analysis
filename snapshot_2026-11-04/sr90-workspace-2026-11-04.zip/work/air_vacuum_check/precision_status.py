"""Read-only progress and variance diagnostics; never selects batches."""
from pathlib import Path
import csv,json,time
import numpy as np
W=Path(__file__).resolve().parent
metas=sorted((W/'scan_precision64').glob('run_[0-9][0-9].json'))
print('Completed fixed-extension batches:',len(metas),'/64')
plan=W/'scan_precision64/run_plan.json'
print('Elapsed seconds:',round(time.time()-plan.stat().st_mtime))
rows=[];ns=[];ss=[]
for p in sorted((W/'scan_dense32').glob('run_*_filter1.json'))+metas:
    m=json.loads(p.read_text());n=m['source_events'];ns.append(n)
    a=[q for q in csv.DictReader(p.with_suffix('.csv').open()) if float(q['threshold_keV'])==10]
    rows.append([float(q['probability']) for q in a])
    ss.append([n*(n-1)*float(q['unconditional_iid_se'])**2+n*float(q['probability'])**2 for q in a])
n=np.array(ns);x=np.array(rows);N=n.sum();p=np.average(x,axis=0,weights=n)
event=np.sqrt(np.maximum(0,(np.sum(ss,axis=0)-N*p*p)/(N*(N-1))))
sigma=np.einsum('b,bi,bj->ij',n,x-p,x-p)/(len(x)-1)
batch=np.sqrt(np.diag(sigma)/N)
print('Total scan source events:',N)
print('Max relative SE: batches %.2f%%; event weights %.2f%%'%(100*max(batch/p),100*max(event/p)))
for d in [.1,.3,.5,.7,.75,.8,.85]:
    i=next(i for i,q in enumerate(a) if float(q['distance_m'])==d)
    print('d %.2f: u %.4f, batch-SE %.2f%%, event-SE %.2f%%'%(d,p[i]*(d+.016)**2*16081638.00229673,100*batch[i]/p[i],100*event[i]/p[i]))
