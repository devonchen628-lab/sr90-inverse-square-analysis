"""Fixed 64 x 1M-event precision extension; retain every completed batch."""
from pathlib import Path
import concurrent.futures,csv,hashlib,json,os,subprocess,time

BASE=Path('/Users/chenqiyue/Documents/Codex/2026-10-12/https-chatgpt-com-share-6acd35f5-5168/outputs/task16_geant4')
WORK=Path(__file__).resolve().parent
BIN=WORK/'vacuum_scan/build/task16_vacuum_scan'
SPEC=BASE/'inputs/spectra_unique.csv'
OUT=WORK/'scan_precision64'
OUT.mkdir(exist_ok=True)
ENV=os.environ.copy()
for key,name in [('G4LEDATA','EMLOW'),('G4LEVELGAMMADATA','PhotonEvaporation'),('G4RADIOACTIVEDATA','RadioactiveDecay'),('G4ENSDFSTATEDATA','ENSDFSTATE')]:
    ENV[key]=str(next((BASE.parents[1]/'.runtime/geant4/share/Geant4/data').glob(name+'*')))
BH=hashlib.sha256(BIN.read_bytes()).hexdigest()
SH=hashlib.sha256(SPEC.read_bytes()).hexdigest()
distances=sorted({float(r['distance_m']) for r in csv.DictReader((BASE/'results/book2_dense_comparison/mc_summary_32_distances.csv').open())})
plan=dict(new_batches=64,source_events_per_batch=1000000,distances_m=distances,
    seed_formula='1873000000 + replicate * 100003',target_max_relative_sampling_se=.05,
    rule='Complete the entire fixed extension. Retain zeros and high-weight batches. Assess precision after all batches complete.',
    binary_sha256=BH,spectrum_sha256=SH,shared_source_library_across_distances=True)
planfile=OUT/'run_plan.json'
if planfile.exists():assert json.loads(planfile.read_text())==plan
else:planfile.write_text(json.dumps(plan,indent=2)+'\n')

def run(rep):
    seed=1873000000+rep*100003
    name=f'run_{rep:02d}'
    target=OUT/(name+'.csv');meta=OUT/(name+'.json')
    cmd=[str(BIN),str(SPEC),str(target),','.join(map(str,distances)),'1000000',str(seed),'1']
    if target.exists() and meta.exists():
        m=json.loads(meta.read_text());assert m['command']==cmd and m['binary_sha256']==BH
        return
    start=time.time()
    with (OUT/(name+'.log')).open('w') as f:
        subprocess.run(cmd,env=ENV,stdout=f,stderr=subprocess.STDOUT,check=True)
    rows=list(csv.DictReader(target.open()));assert len(rows)==192
    assert all(int(q['nsource'])==1000000 for q in rows)
    meta.write_text(json.dumps(dict(command=cmd,binary_sha256=BH,spectrum_sha256=SH,source_events=1000000,seed=seed,replicate=rep,elapsed_s=time.time()-start,shared_source_library_across_distances=True),indent=2)+'\n')
    print(f'Completed batch {rep+1}/64; elapsed {time.time()-start:.1f}s',flush=True)

if __name__=='__main__':
    with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool:list(pool.map(run,range(64)))
    print('Fixed extension complete: 64,000,000 new independent source events, each evaluated at 32 distances.',flush=True)
