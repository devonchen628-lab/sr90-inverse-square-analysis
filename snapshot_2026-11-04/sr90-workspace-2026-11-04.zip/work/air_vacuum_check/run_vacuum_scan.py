"""Independent complete source libraries, reused across vacuum distances."""
from pathlib import Path
import concurrent.futures,csv,hashlib,json,os,subprocess,sys,time
BASE=Path('/Users/chenqiyue/Documents/Codex/2026-10-12/https-chatgpt-com-share-6acd35f5-5168/outputs/task16_geant4')
WORK=Path(__file__).resolve().parent
BIN=WORK/'vacuum_scan/build/task16_vacuum_scan'
SPEC=BASE/'inputs/spectra_unique.csv'
ENV=os.environ.copy()
for key,name in [('G4LEDATA','EMLOW'),('G4LEVELGAMMADATA','PhotonEvaporation'),('G4RADIOACTIVEDATA','RadioactiveDecay'),('G4ENSDFSTATEDATA','ENSDFSTATE')]:
    ENV[key]=str(next((BASE.parents[1]/'.runtime/geant4/share/Geant4/data').glob(name+'*')))
BH=hashlib.sha256(BIN.read_bytes()).hexdigest()
SH=hashlib.sha256(SPEC.read_bytes()).hexdigest()
validation='--validate' in sys.argv
OUT=WORK/('scan_validation' if validation else 'scan_dense32')
OUT.mkdir(exist_ok=True)
distances=([.01,.025,.1,.3,.8] if validation else sorted({float(r['distance_m']) for r in csv.DictReader((BASE/'results/book2_dense_comparison/mc_summary_32_distances.csv').open())}))

def run(job):
    rep,prefilter=job
    seed=1963000000+rep*100003
    n=100000 if validation else 500000
    name=f'run_{rep:02d}_filter{prefilter}'
    target=OUT/(name+'.csv'); meta=OUT/(name+'.json')
    cmd=[str(BIN),str(SPEC),str(target),','.join(map(str,distances)),str(n),str(seed),str(prefilter)]
    if target.exists() and meta.exists():
        m=json.loads(meta.read_text());assert m['command']==cmd and m['binary_sha256']==BH
        return
    t=time.time()
    with (OUT/(name+'.log')).open('w') as f:
        subprocess.run(cmd,env=ENV,stdout=f,stderr=subprocess.STDOUT,check=True)
    rows=list(csv.DictReader(target.open()));assert len(rows)==6*len(distances)
    meta.write_text(json.dumps(dict(command=cmd,binary_sha256=BH,spectrum_sha256=SH,source_events=n,seed=seed,replicate=rep,prefilter=prefilter,elapsed_s=time.time()-t,shared_source_library_across_distances=True),indent=2)+'\n')
    print(f'Finished independent batch {rep}, filter={prefilter}, {len(distances)} distances, {time.time()-t:.1f}s',flush=True)

if __name__=='__main__':
    jobs=[(0,1),(0,0)] if validation else [(r,1) for r in range(8)]
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:list(pool.map(run,jobs))
