from pathlib import Path
from pypdf import PdfReader
import openpyxl, zipfile, xml.etree.ElementTree as ET, json

out=Path(__file__).parent
rad=Path('/Users/chenqiyue/Library/CloudStorage/OneDrive-ImperialCollegeLondon/Radlab')
base=Path('/Users/chenqiyue/Documents/2025-/Imperial College/Physics/Yr2 Lab')
for folder in [base/'1_Radioactivity', base/'Imperial_lab_report']:
    for p in folder.rglob('*.pdf'):
        if 'Local Rules' in p.name or 'nist_' in p.name: continue
        reader=PdfReader(p)
        text='\n'.join(f'\n=== PAGE {i+1} ===\n'+(page.extract_text() or '') for i,page in enumerate(reader.pages))
        (out/(p.stem+'.txt')).write_text(text)
        print(p.name,len(reader.pages),'pages',len(text),'chars')
with zipfile.ZipFile(rad/'Document.docx') as z:
    root=ET.fromstring(z.read('word/document.xml'))
    ns={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}
    text='\n'.join(''.join(p.itertext()) for p in [])
    text='\n'.join(''.join(t.text or '' for t in p.findall('.//w:t',ns)) for p in root.findall('.//w:p',ns))
    (out/'Document.txt').write_text(text)
    print('Document.docx:',text)
for p in rad.glob('*.xlsx'):
    wb=openpyxl.load_workbook(p,data_only=False)
    cached=openpyxl.load_workbook(p,data_only=True)
    lines=[]
    for ws in wb:
        lines.append(f'SHEET {ws.title} {ws.max_row} rows {ws.max_column} cols')
        for row in ws:
            cells=[]
            for c in row:
                if c.value is not None:
                    val=str(c.value)
                    if c.data_type=='f':val+=f' [cached={cached[ws.title][c.coordinate].value}]'
                    cells.append(f'{c.coordinate}={val}')
            if cells:lines.append(' | '.join(cells))
    (out/(p.stem+'_xlsx.txt')).write_text('\n'.join(lines))
    print(p.name, '\n'.join(lines[:8]))
    (out/(p.stem+'_values.json')).write_text(json.dumps({ws.title:list(ws.values) for ws in cached},default=str))
