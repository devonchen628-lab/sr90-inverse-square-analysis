from pathlib import Path
import os
os.environ['MPLCONFIGDIR']=str(Path(__file__).parent/'mplcache')
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

d=np.linspace(.01,.9,1500)
offset=.01
mu=.15
geometry=(d/(d+offset))**2
loss=np.exp(-mu*d)
combined=geometry*loss
fig,ax=plt.subplots(figsize=(9,4.8),layout='constrained')
ax.axvspan(.25,.50,color='#e9eef4',label='Example of an apparently flat interval')
ax.axhline(1,color='#666666',ls=':',lw=1.4,label='Ideal constant K')
ax.plot(d,geometry,color='#29815e',lw=2,label='Distance-offset factor')
ax.plot(d,loss,color='#b76c24',lw=2,label='Illustrative distance-dependent loss')
ax.plot(d,combined,color='#234d8a',lw=2.6,label='Combined U/K')
peak=(-offset+np.sqrt(offset**2+8*offset/mu))/2
val=(peak/(peak+offset))**2*np.exp(-mu*peak)
ax.annotate('Locally almost flat,\nbut about 10% below K',xy=(peak,val),xytext=(.47,.55),arrowprops={'arrowstyle':'->','color':'#234d8a'},color='#234d8a',fontsize=11)
ax.set(xlim=(0,.9),ylim=(0,1.06),xlabel='Reported source-detector distance d (m)',ylabel='Normalized factors and U/K',title='Illustration only: a plateau can conceal opposing systematic effects')
ax.legend(frameon=False,fontsize=9,loc='lower right')
ax.grid(alpha=.15)
ax.spines[['top','right']].set_visible(False)
fig.supxlabel(r'Hypothetical model: U/K = [d/(d + 0.010 m)]² exp[−(0.15 m⁻¹)d]. Not fitted to experimental data.',fontsize=9)
out=Path(__file__).parents[2]/'outputs/plateau_compensation_illustration.png'
fig.savefig(out,dpi=180)
mask=(d>=.25)&(d<=.5)
print({'peak_distance_m':float(peak),'peak_U_over_K':float(val),'plateau_range_U_over_K':[float(combined[mask].min()),float(combined[mask].max())]})
