from pathlib import Path
import csv,json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import NullFormatter
root=Path('/Users/chenqiyue/Documents/Codex/2026-10-29/r'); out=root/'outputs/task16_three_steps';out.mkdir(exist_ok=True)
source=root/'output/pdf/radioactivity_report/data/pooled_measurements.csv'
with source.open() as f:rows=list(csv.DictReader(f))
def a(k):return np.array([float(q[k]) for q in rows])
d=a('d_m'); raw=a('raw_rate_cps'); count=a('total_counts'); t=a('total_time_s'); scale=a('scatter_scale'); C=a('corrected_rate_cps'); se=a('corrected_rate_se'); sd=.0005/np.sqrt(3); delta=.021
assert len(d)==32 and int(sum(a('number_of_records')))==141
u1=raw*d*d; u2=C*d*d; u3=C*(d+delta)**2
se_raw=scale*np.sqrt(count)/t
v1=np.sqrt((d*d*se_raw)**2+(2*d*raw*sd)**2)
v2=np.sqrt((d*d*se)**2+(2*d*C*sd)**2)
v3=np.sqrt(((d+delta)**2*se)**2+(2*(d+delta)*C*sd)**2)
idx=np.flatnonzero(np.isclose(d,.3))[0]; K=u1[idx]
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10.5,'axes.titlesize':12,'axes.labelsize':10.5,'xtick.labelsize':9,'ytick.labelsize':9,'axes.spines.right':False,'axes.spines.top':False,'svg.fonttype':'none'})
blue='#215c82'; orange='#be632f'; green='#327664'
fig,axs=plt.subplots(1,3,figsize=(14.5,4.8),sharex=True,sharey=True,layout='constrained')
configs=[(u1,v1,blue,'1  Original measurement',r'$C_{\rm raw}d^2$','Recorded rate and rail distance'),(u2,v2,orange,'2  Correct the count rate',r'$C_{\rm corr}d^2$','Background + effective recovery'),(u3,v3,green,'3  Use active-plane distance',r'$C_{\rm corr}(d+21\,\mathrm{mm})^2$','Assumed offset: 21 mm')]
for ax,(u,e,col,title,formula,sub) in zip(axs,configs):
 ax.errorbar(d*100,u,yerr=e,fmt='o',ms=4,elinewidth=.8,capsize=2,color=col,zorder=3)
 ax.axhline(K,ls='--',lw=1,color='#77828b',alpha=.8,zorder=1)
 ax.set_xscale('log');ax.set_xlim(.8,100);ax.set_ylim(0,23)
 ax.set_xticks([1,2.5,5,10,20,50,85],labels=['1','2.5','5','10','20','50','85']);ax.xaxis.set_minor_formatter(NullFormatter())
 ax.grid(color='#d9e0e5',alpha=.65,linewidth=.6);ax.set_title(title,loc='left',fontweight='bold',pad=17)
 ax.text(.01,1.015,formula+'   |   '+sub,transform=ax.transAxes,ha='left',va='bottom',fontsize=9,color='#3d4851')
 ax.set_xlabel('Recorded rail distance $d$ (cm; log scale)')
axs[0].set_ylabel(r'Rate $\times$ distance$^2$ (m$^2$ s$^{-1}$)')
fig.suptitle('How each correction changes the measured distance product',fontsize=16,fontweight='bold',x=.013,ha='left')
fig.text(.013,-.035,'All 141 measurements pooled into 32 distances. Dashed line: original value at 30 cm, a common visual reference (not a fit).',ha='left',fontsize=9,color='#4b5962')
fig.text(.013,-.08,'Bars are conditional 1σ errors; the common, unmeasured offset uncertainty is not included. Source–detector offset = 21 mm is an assumption.',ha='left',fontsize=9,color='#4b5962')
fig.savefig(out/'three_steps_comparison.png',dpi=220,bbox_inches='tight');fig.savefig(out/'three_steps_comparison.svg',bbox_inches='tight');plt.close(fig)
for k,(u,e,col,title,formula,sub) in enumerate(configs,1):
 fig,ax=plt.subplots(figsize=(7.3,4.8),layout='constrained');ax.errorbar(d*100,u,yerr=e,fmt='o',ms=4.5,elinewidth=.85,capsize=2,color=col,label='Pooled measurements');ax.axhline(K,ls='--',lw=1,color='#77828b',label='Common reference: original at 30 cm (not a fit)')
 ax.set_xscale('log');ax.set_xlim(.8,100);ax.set_ylim(0,23);ax.set_xticks([1,2.5,5,10,20,50,85],labels=['1','2.5','5','10','20','50','85']);ax.xaxis.set_minor_formatter(NullFormatter());ax.grid(color='#d9e0e5',alpha=.65,linewidth=.6);ax.set_title(title+'\n'+formula+'  |  '+sub,loc='left',pad=10);ax.set_xlabel('Recorded rail distance $d$ (cm; log scale)');ax.set_ylabel(r'Rate $\times$ distance$^2$ (m$^2$ s$^{-1}$)');ax.legend(loc='lower right',frameon=False,fontsize=8.7)
 fig.savefig(out/f'step_{k}.png',dpi=220,bbox_inches='tight');fig.savefig(out/f'step_{k}.svg',bbox_inches='tight');plt.close(fig)
print(json.dumps({'raw_nearest':u1[0],'corrected_nearest':u2[0],'offset_nearest':u3[0],'corrected_rate_pct':100*(C[0]/raw[0]-1),'reference_raw_30cm':K,'points':len(d)},indent=2))
