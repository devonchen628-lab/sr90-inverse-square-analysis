from pathlib import Path
import csv
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
root=Path('/Users/chenqiyue/Documents/Codex/2026-10-29/r');out=root/'outputs/task16_raw_cd2';out.mkdir(exist_ok=True)
with (root/'output/pdf/radioactivity_report/data/pooled_measurements.csv').open() as f: rows=list(csv.DictReader(f))
def a(k):return np.array([float(q[k]) for q in rows])
d=a('d_m');c=a('raw_rate_cps');N=a('total_counts');t=a('total_time_s');scale=a('scatter_scale');sd=.0005/np.sqrt(3)
u=c*d*d;err=np.sqrt((d*d*scale*np.sqrt(N)/t)**2+(2*d*c*sd)**2)
assert len(d)==32 and int(sum(a('number_of_records')))==141
plt.rcParams.update({'font.family':'DejaVu Sans','axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'none','font.size':11})
fig,ax=plt.subplots(figsize=(8.2,5.2),layout='constrained')
ax.errorbar(d*100,u,yerr=err,fmt='o',color='#1c658c',markersize=4.7,elinewidth=1,capsize=2,label='Measured data (all repeats pooled)')
ax.set(xlim=(0,90),ylim=(0,15),xlabel='Recorded rail distance $d$ (cm)',ylabel=r'$C_{\mathrm{raw}}d^2$ (m$^2$ s$^{-1}$)',title=r'Raw count-rate product $C_{\mathrm{raw}}d^2$');ax.grid(alpha=.19);ax.legend(frameon=False,loc='lower right',fontsize=10)
for e in ['png','svg']:fig.savefig(out/f'raw_cd2.{e}',dpi=230,bbox_inches='tight')
