from pathlib import Path
from collections import defaultdict
import hashlib,json,math
from openpyxl import load_workbook
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
source=Path('/Users/chenqiyue/Library/CloudStorage/OneDrive-ImperialCollegeLondon/Radlab/task 16 data.xlsx')
root=Path('/Users/chenqiyue/Documents/Codex/2026-10-29/r');out=root/'outputs/task16_last_three';out.mkdir(exist_ok=True)
sheet=load_workbook(source,data_only=True,read_only=True)['Sheet1'];groups=defaultdict(list);lastd=None
def num(v):
 if v is None or not str(v).strip():return None
 return float(str(v).strip())
for row_idx,row in enumerate(sheet.iter_rows(min_row=2,values_only=True),start=2):
 d=num(row[0]);n=num(row[2]);t=num(row[4]);
 if d is not None:lastd=d
 if n is not None:
  if lastd is None or t is None or n<0 or t<=0:raise ValueError(f'Invalid record row {row_idx}')
  groups[lastd].append(dict(source_row=row_idx,counts=int(n),exposure_s=t,rate_cps=n/t))
points=[]
for d,readings in sorted(groups.items()):
 if len(readings) not in (3,6):raise ValueError(f'Unexpected {len(readings)} records at {d} m')
 selected=readings[-3:];N=sum(z['counts'] for z in selected);T=sum(z['exposure_s'] for z in selected);rate=N/T
 Q=sum((z['counts']-rate*z['exposure_s'])**2/(rate*z['exposure_s']) for z in selected);inflation=max(1.,math.sqrt(Q/2));se_rate=math.sqrt(N)/T*inflation;sd=.0005/math.sqrt(3);u=rate*d*d;se_u=math.hypot(d*d*se_rate,2*d*rate*sd)
 points.append(dict(d_m=d,n_available=len(readings),selected_rows=[z['source_row'] for z in selected],selected_records=selected,total_counts=N,total_time_s=T,raw_rate_cps=rate,pearson_Q=Q,repeat_scatter_factor=inflation,u_raw=u,u_standard_error=se_u))
assert len(points)==32 and sum(p['n_available'] for p in points)==141 and sum(len(p['selected_records']) for p in points)==96
(out/'selection_details.json').write_text(json.dumps(dict(source=str(source),source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),sheet='Sheet1',selection='last three records in worksheet row order at each distance; for three records all three retained',observations=96,distances=32,distance_standard_uncertainty_m=.0005/math.sqrt(3),uncertainty='Poisson rate standard error multiplied by max(1,sqrt(Q/2)); rail reading assumed uniform ±0.5mm, propagated to Cd²; common offset and other systematics excluded',points=points),ensure_ascii=False,indent=2)+'\n')
x=np.array([p['d_m']*100 for p in points]);y=np.array([p['u_raw'] for p in points]);e=np.array([p['u_standard_error'] for p in points]);plt.rcParams.update({'font.family':'DejaVu Sans','axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'none','font.size':11})
fig,ax=plt.subplots(figsize=(8.2,5.2),layout='constrained');ax.errorbar(x,y,yerr=e,fmt='o',color='#1c658c',markersize=4.7,elinewidth=1,capsize=2,label='Last three measurements at each distance');ax.set(xlim=(0,90),ylim=(0,15),xlabel='Recorded rail distance $d$ (cm)',ylabel=r'$C_{\mathrm{raw}}d^2$ (m$^2$ s$^{-1}$)',title=r'Raw $C_{\mathrm{raw}}d^2$: last three readings');ax.grid(alpha=.19);ax.legend(frameon=False,loc='lower right',fontsize=10)
for ext in ('png','svg'):fig.savefig(out/f'raw_cd2_last_three.{ext}',dpi=230,bbox_inches='tight')
print(json.dumps({'n_points':len(points),'source_count':sum(p['n_available'] for p in points),'selected':96,'example_2p5cm_rows':points[1]['selected_rows'],'example_2p5cm_u':points[1]['u_raw']},ensure_ascii=False))
