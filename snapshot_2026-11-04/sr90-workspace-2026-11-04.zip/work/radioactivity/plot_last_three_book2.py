from pathlib import Path
import json,math,hashlib
import numpy as np
from openpyxl import load_workbook
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
root=Path('/Users/chenqiyue/Documents/Codex/2026-10-29/r');out=root/'outputs/task16_last_three_book2';out.mkdir(exist_ok=True)
s=Path('/Users/chenqiyue/Library/CloudStorage/OneDrive-ImperialCollegeLondon/Radlab/Book2.xlsx');sheet=load_workbook(s,data_only=False,read_only=True)['Sheet1']
assert sheet['F2'].value=='=C2/E2*A2^2' and sheet['G2'].value=='=F2*SQRT(1/C2+(2*B2/A2)^2)'
assert set(float(sheet.cell(i,2).value) for i in range(2,34))=={.0005}
prev=json.loads((root/'outputs/task16_last_three/selection_details.json').read_text());pts=prev['points'];assert len(pts)==32
sigma_d=.0005
for p in pts:
 d=p['d_m'];N=p['total_counts'];u=p['u_raw'];p['book2_u_unc']=u*math.sqrt(1/N+(2*sigma_d/d)**2);p['book2_rate_poisson_se']=math.sqrt(N)/p['total_time_s'];p['previous_unc']=p['u_standard_error']
details={'uncertainty_method_source':str(s),'book2_sha256':hashlib.sha256(s.read_bytes()).hexdigest(),'formula':'u = N/T*d^2; sigma_u = u*sqrt(1/N + (2*sigma_d/d)^2)','sigma_d_m':sigma_d,'assumptions':'Book2 treats 0.5 mm directly as the propagated distance uncertainty; no empirical repeat-scatter multiplier. Relative uncertainty does not include other common systematics.','data_source':prev['source'],'data_sha256':prev['source_sha256'],'selection':prev['selection'],'points':pts}
(out/'calculation_details.json').write_text(json.dumps(details,ensure_ascii=False,indent=2)+'\n')
x=np.array([p['d_m']*100 for p in pts]);y=np.array([p['u_raw'] for p in pts]);e=np.array([p['book2_u_unc'] for p in pts]);plt.rcParams.update({'font.family':'DejaVu Sans','axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'none','font.size':11})
fig,ax=plt.subplots(figsize=(8.2,5.2),layout='constrained');ax.errorbar(x,y,yerr=e,fmt='o',color='#1c658c',markersize=4.7,elinewidth=1,capsize=2,label='Last three measurements; Book2 uncertainty');ax.set(xlim=(0,90),ylim=(0,15),xlabel='Recorded rail distance $d$ (cm)',ylabel=r'$C_{\mathrm{raw}}d^2$ (m$^2$ s$^{-1}$)',title=r'Raw $C_{\mathrm{raw}}d^2$: Book2 uncertainty method');ax.grid(alpha=.19);ax.legend(frameon=False,loc='lower right',fontsize=10)
for ext in ('png','svg'):fig.savefig(out/f'raw_cd2_book2_uncertainty.{ext}',dpi=230,bbox_inches='tight')
for p in pts:
 if p['d_m'] in [.01,.55,.75,.85]:print(p['d_m'],p['u_raw'],p['previous_unc'],p['book2_u_unc'])
