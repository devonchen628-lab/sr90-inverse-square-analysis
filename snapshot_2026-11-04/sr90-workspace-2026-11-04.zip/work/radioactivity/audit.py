import os
from pathlib import Path
os.environ['MPLCONFIGDIR']=str(Path(__file__).parent/'mplcache')
import json,csv,re
import numpy as np
from scipy.stats import chi2,poisson
from scipy.optimize import least_squares
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

root=Path('/Users/chenqiyue/Library/CloudStorage/OneDrive-ImperialCollegeLondon/Radlab')
work=Path(__file__).parent
out=work.parent.parent/'outputs'
summary={}
def load(stem):
    rows=json.loads((work/(stem+'_values.json')).read_text())['Sheet1'][1:]
    obs=[r for r in rows if isinstance(r[1],(int,float)) and isinstance(r[4],(int,float)) and isinstance(r[5],(int,float)) and str(r[0]).lower()!='background']
    arr=np.array([[r[i] for i in (1,2,4,5)] for r in obs],float)
    x,sx,t,n=arr[np.argsort(arr[:,0])].T
    return dict(x=x,sx=sx,t=t,n=n,y=n/t,s=np.sqrt(n)/t)
al=load('Task19');cu=load('task20')
def constant(d,start):
    m=d['x']>=start
    n,t=d['n'][m],d['t'][m]
    c=n.sum()/t.sum();mu=t*c
    dev=2*np.sum(n*np.log(n/mu)-(n-mu))
    return {'start_mm':start,'points':int(m.sum()),'rate':c,'sigma':np.sqrt(n.sum())/t.sum(),'deviance':dev,'dof':len(n)-1,'p':chi2.sf(dev,len(n)-1)}
summary['Al']={'points':len(al['x']),'count_sum':float(al['n'].sum()),'time_sum':float(al['t'].sum()),'tail':[constant(al,s) for s in [3.75,3.84,3.88,4.04]],'main_relative_error_range':[float(np.min(al['s'][al['x']<=2.8]/al['y'][al['x']<=2.8])),float(np.max(al['s'][al['x']<=2.8]/al['y'][al['x']<=2.8]))]}
summary['Cu']={'points':len(cu['x']),'tail':[constant(cu,s) for s in [1.27,1.96,2.5]]}
summary['Al_supplement']=[dict(x=float(al['x'][i]),N=float(al['n'][i]),t=float(al['t'][i]),rate=float(al['y'][i]),sigma=float(al['s'][i])) for i in np.where(al['t']==300)[0]]
summary['Cu_linear_endpoint_tests']=[]
for ids in [[1,2,3],[2,3,4],[3,4,5]]:
    x,y,s=[cu[k][ids] for k in ('x','y','s')]
    M=np.c_[x,np.ones(len(x))];Mw=M/s[:,None]
    slope,inter=np.linalg.lstsq(Mw,y/s,rcond=None)[0]
    chisq=np.sum(((y-(slope*x+inter))/s)**2)
    tail=summary['Cu']['tail'][1]['rate']
    endpoint=(tail-inter)/slope
    summary['Cu_linear_endpoint_tests'].append(dict(start=x[0],end=x[-1],chi2=chisq,dof=1,p=chi2.sf(chisq,1),intersection=endpoint))
summary['Al_endpoint_window_diagnostic']=[]
for lo,hi in [(3.18,3.64),(3.37,3.64),(3.51,3.75),(3.53,3.75)]:
    m=(al['x']>=lo)&(al['x']<=hi)
    x,y,s,sx=[al[k][m] for k in ('x','y','s','sx')]
    M=np.c_[x,np.ones(len(x))]
    initial=np.linalg.lstsq(M/s[:,None],y/s,rcond=None)[0]
    fit=least_squares(lambda v:(y-M@v)/np.sqrt(s*s+(v[0]*sx)**2),initial)
    slope,inter=fit.x;ch=np.sum(fit.fun**2);dof=len(x)-2
    endpoint=(2.62-inter)/slope;R=.27*endpoint
    E=np.sqrt(((R/.11+1)**2-1)/22.4)
    summary['Al_endpoint_window_diagnostic'].append(dict(start=lo,end=hi,points=int(m.sum()),chi2=ch,dof=dof,p=chi2.sf(ch,dof),intersection_mm=endpoint,energy_MeV_DIAGNOSTIC_ONLY=E))

def crossing(d,rho,q):
    T=d['y']/d['y'][0];idx=np.where((T[:-1]>=q)&(T[1:]<=q))[0][0]
    f=(np.log(q)-np.log(T[idx]))/(np.log(T[idx+1])-np.log(T[idx]))
    return rho/10*(d['x'][idx]+f*(d['x'][idx+1]-d['x'][idx]))
summary['attenuation_levels_raw_log_interpolation']={k:{str(q):crossing(d,rho,q) for q in [.5,.1,.01]} for k,d,rho in [('Al',al,2.70),('Cu',cu,8.96)]}

# Read raw cycle counts only, excluding the exported frequency table.
count_stats={}
for p in root.glob('*.csv'):
    text=p.read_text(encoding='utf-8-sig')
    if 'SampleIndex,Count' not in text:continue
    raw=text.split('SampleIndex,Count',1)[1].split('# Count distribution histogram')[0]
    data=np.array([float(line.split(',')[1]) for line in raw.strip().splitlines() if re.match(r'^\d+,\d+',line)])
    mean=data.mean();var=data.var(ddof=1)
    # Group all possible Poisson outcomes into expected counts of >=5.
    bins=[];lo=0;acc=0
    for k in range(int(poisson.ppf(1-1e-12,mean))+1):
        acc+=len(data)*poisson.pmf(k,mean)
        if acc>=5:
            bins.append([lo,k,acc]);lo=k+1;acc=0
    bins[-1][1]=np.inf
    bins[-1][2]=len(data)*poisson.sf(bins[-1][0]-1,mean)
    obs=np.array([np.sum((data>=a)&(data<=b)) for a,b,_ in bins]);exp=np.array([v[2] for v in bins])
    chisq=np.sum((obs-exp)**2/exp);dof=len(bins)-2
    count_stats[p.name]=dict(n=len(data),mean=mean,variance=var,fano=var/mean,chi2=chisq,dof=dof,p=chi2.sf(chisq,dof),expected_min=exp.min())
summary['count_statistics']=count_stats

with (root/'Task16.csv').open(encoding='utf-8-sig') as f:rows=list(csv.DictReader(f))
dist=np.array([[float(r[k]) for k in ['d','d_unc','n','t']] for r in rows if r['d']!='Background'])
d,sd,n,t=dist.T;rate=n/t;u=rate*d*d
su=np.sqrt((d*d/t)**2*n+(2*rate*d*sd)**2)
summary['distance']={'points':len(d),'u_peak':float(u.max()),'d_peak':float(d[np.argmax(u)]),'u_last':float(u[-1]),'sigma_last':float(su[-1]),'range_m':[float(d.min()),float(d.max())]}
for low,high in [(.15,.5),(.25,.5)]:
    mask=(d>=low)&(d<=high)
    w=1/su[mask]**2;mu=np.sum(w*u[mask])/sum(w)
    ch=np.sum(((u[mask]-mu)/su[mask])**2)
    summary['distance'][f'constant_{low}_{high}']=dict(mean=mu,sigma=1/np.sqrt(sum(w)),chi2=ch,dof=int(mask.sum()-1),p=chi2.sf(ch,mask.sum()-1))
summary['angle_uncertainty_issue']={'at_0deg_stored':.696060342,'correct':np.sqrt(3876)/20,'factor':np.sqrt(20)}
summary['interval_files']={}
for p in [root/'Task13.csv',*root.glob('Task14*.csv')]:
    text=p.read_text();rows=list(csv.reader(text.split('BinIndex,Count',1)[1].strip().splitlines()))
    a=np.array(rows,int)
    summary['interval_files'][p.name]=dict(bins=len(a),total_histogram_counts=int(a[:,1].sum()),first_nonzero_bin=int(a[np.flatnonzero(a[:,1])[0],0]),note='Bin width and overflow mapping not explicitly saved in CSV')
(work/'audit_results.json').write_text(json.dumps(summary,indent=2))
print(json.dumps(summary,indent=2))

plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False})
fig,axs=plt.subplots(2,2,figsize=(11.5,8),layout='constrained')
colors=['#176b99','#c46c28']
for label,data,rho,c in [('Al',al,2.70,colors[0]),('Cu',cu,8.96,colors[1])]:
    axs[0,0].errorbar(data['x'],data['y'],xerr=data['sx'],yerr=data['s'],fmt='o',ms=3.5,capsize=2,color=c,label=label)
    T=data['y']/data['y'][0]
    sT=T*np.sqrt(1/data['n']+1/data['n'][0]);sT[0]=0
    axs[0,1].errorbar(data['x']*rho/10,T,xerr=data['sx']*rho/10,yerr=sT,fmt='o-',lw=.7,ms=3.5,capsize=2,color=c,label=label)
axs[0,0].set(yscale='log',xlabel='Absorber thickness (mm)',ylabel='Raw count rate (counts/s)',title='A. Absorption curves, including all Al additions')
axs[0,1].set(yscale='log',xlabel=r'Areal density (g cm$^{-2}$)',ylabel=r'Raw transmission $C/C_0$',xlim=(-.03,1.4),ylim=(1e-4,1.5),title='B. Same areal density does not fully collapse curves')
base=al['t']!=300;extra=~base
for m,label,c in [(base,'Original scan',colors[0]),(extra,'Added 300 s measurements','#942e63')]:
    axs[1,0].errorbar(al['x'][m],al['y'][m],xerr=al['sx'][m],yerr=al['s'][m],fmt='o',ms=4,capsize=3,label=label,color=c)
tail=constant(al,3.84)
axs[1,0].axhline(tail['rate'],color='#555555',ls='--',lw=1,label=f"Tail estimate: {tail['rate']:.3f} counts/s")
axs[1,0].axhline(5/60,color='#333333',ls=':',lw=1,label='No-source background: 0.083 counts/s')
axs[1,0].set(xlim=(3.1,5.1),ylim=(0,8),xlabel='Aluminium thickness (mm)',ylabel='Raw count rate (counts/s)',title='C. Al tail is far above no-source background')
axs[1,1].errorbar(d,u,xerr=sd,yerr=su,fmt='o',ms=3.5,capsize=2,color=colors[0])
axs[1,1].set(xlabel='Source-detector distance (m)',ylabel=r'$C d^2$ (counts m$^2$/s)',title='D. Distance scan resolves systematic curvature')
for ax in axs.flat:ax.grid(alpha=.2)
for ax in axs.flat[:3]:ax.legend(frameon=False,fontsize=8,loc='best')
fig.suptitle('Radioactivity data audit | 29 October 2026',fontsize=15)
fig.supxlabel('Raw rates; no dead-time correction. Thickness errors as supplied. Lines in B guide the eye.',fontsize=9)
fig.savefig(out/'radioactivity_data_audit.png',dpi=180)
plt.close(fig)
