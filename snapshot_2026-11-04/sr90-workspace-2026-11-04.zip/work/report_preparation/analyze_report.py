"""Reproducible report analysis; all recorded repeats are retained as the primary data."""
from pathlib import Path
import csv,hashlib,json,os,shutil,sys
import numpy as np
from scipy.interpolate import PchipInterpolator
from scipy.stats import chi2
ROOT=Path('/Users/chenqiyue/Documents/Codex/2026-10-29/r')
P=ROOT/'output/pdf/radioactivity_report'
sys.path.insert(0,str(ROOT/'work/rigid_mount_resimulation'))
from task16_inputs import load,read
v=load(); d=v['d']; data=v['all']; C=data['net']; Vy=data['Vy']
source=Path(v['source']['source'])
assert hashlib.sha256(source.read_bytes()).hexdigest()==v['source']['source_sha256']
anchor_distances=[.3,.5,.85]
models={}
configs=[('G0','task16_recess_geometry','latest_data_comparison_32.csv',.016,0,0,5,2),
 ('G1','task16_offset19_shift3','comparison.csv',.019,0,3,5,2),
 ('G2','task16_offset21_shift31','comparison.csv',.021,1,3,6,3)]
for key,folder,name,offset,dx,dy,sdepth,ddepth in configs:
 rr=read(ROOT/'outputs'/folder/name)
 md=np.array([float(q['d_m']) for q in rr]);idx=np.array([np.where(d==x)[0][0] for x in md])
 p=np.array([float(q['probability']) for q in rr])
 VP=np.load(ROOT/'outputs'/folder/'covariances.npz')['probability_covariance_10keV']
 w=np.array([1/3 if x in anchor_distances else 0 for x in md])
 assert np.isclose(w.sum(),1)
 H=np.eye(len(md))-np.outer(np.ones(len(md)),w)
 r=md+offset
 g=PchipInterpolator(np.log(r),np.log(p)).derivative()(np.log(r))/r
 # Only the characterized independent rail-reading standard uncertainty is probabilistic.
 # Uncalibrated common offsets and dimensions are explored as scenarios, not assigned a prior.
 Vruler=np.diag((g*v['sd'])**2)
 V=Vy[np.ix_(idx,idx)]+VP/np.outer(p,p)+Vruler
 A=float(np.exp(w@(np.log(C[idx])-np.log(p))))
 R=C[idx]/(A*p);Vr=H@V@H.T;sr=R*np.sqrt(np.maximum(0,np.diag(Vr)))
 selected=v['selected'];As=float(np.exp(w@(np.log(selected['net'][idx])-np.log(p))))
 Rs=selected['net'][idx]/(As*p)
 near=[dict(d_cm=float(x*100),ratio=float(R[i]),se=float(sr[i]),nominal_z=float((1-R[i])/sr[i]),
  selected_three_ratio=float(Rs[i])) for i,x in enumerate(md) if x<=.1]
 models[key]=dict(d=md,idx=idx,p=p,VP=VP,A=A,R=R,sr=sr,Vratio=Vr,offset=offset,dx=dx,dy=dy,
  source_recess=sdepth,detector_recess=ddepth,near=near,selected_normalization=As)
 np.savez_compressed(P/'data'/f'{key}_model.npz',d_m=md,probability=p,probability_covariance=VP,
  normalization_weights=w,ratio_covariance_log=Vr)
 shutil.copy2(ROOT/'outputs'/folder/'run_plan.json',P/'data'/f'{key}_simulation_plan.json')

raw=read(ROOT/'outputs/task16_closest_three/task16_all_measurements.csv')
rows=[]
for i,x in enumerate(d):
 rr=[q for q in raw if float(q['d_m'])==x]
 n=sum(int(q['counts']) for q in rr);t=sum(float(q['time_s']) for q in rr)
 rows.append(dict(d_m=float(x),number_of_records=len(rr),total_counts=n,total_time_s=t,
  raw_rate_cps=float(data['C'][i]),corrected_rate_cps=float(C[i]),
  corrected_rate_se=float(C[i]*np.sqrt(Vy[i,i])),scatter_scale=float(data['birge'][i]),
  u_recorded=float(data['C'][i]*x*x),u_offset21=float(C[i]*(x+.021)**2)))
with (P/'data/pooled_measurements.csv').open('w',newline='') as f:
 wr=csv.DictWriter(f,fieldnames=list(rows[0]));wr.writeheader();wr.writerows(rows)
shutil.copy2(ROOT/'outputs/task16_closest_three/task16_all_measurements.csv',P/'data/raw_measurements.csv')
shutil.copy2(ROOT/'work/radioactivity/new_deadtime_results.json',P/'data/recovery_fit.json')
shutil.copy2(ROOT/'work/return_rate/results.json',P/'data/return_checks.json')
dead=json.loads((P/'data/recovery_fit.json').read_text())
returns=json.loads((P/'data/return_checks.json').read_text())
summary=dict(primary_data='All141 observations, pooled by distance; no closest-three selection in main analysis.',
 source=str(source),source_sha256=v['source']['source_sha256'],distances=len(d),observations=len(raw),
 individual_exposure_range_s=[min(float(q['time_s']) for q in raw),max(float(q['time_s']) for q in raw)],
 count_uncertainty='Poisson rate SE inflated by max(1,sqrt(PearsonQ/(m-1))) across repeats at each distance; common background and recovery-fit errors propagated.',
 distance_uncertainty='Independent rail reading uniform +/-0.5mm, standard uncertainty0.5/sqrt3mm. No invented probability distribution for uncertain common offsets; explicit geometry scenarios.',
 nominal_statistical_limit='Scenario parameters and detector response are conditional. Pointwise nominal intervals are not a global goodness-of-fit or causal test.',
 max_absolute_all_vs_selected_rate_change_pct=float(max(abs(data['net']/v['selected']['net']-1))*100),
 max_near_all_vs_selected_rate_change_pct=float(max(abs(data['net'][d<=.1]/v['selected']['net'][d<=.1]-1))*100),
 max_data_scatter_scale=float(max(data['birge'])),nearest=rows[0],furthest=rows[-1],
 deadtime=dead,repeatability=dict(pairs=len(returns['pairs']),Q=returns['between_chi2'],df=returns['between_df'],p=returns['between_p']),
 models={k:{q:m[q] for q in ['A','offset','dx','dy','source_recess','detector_recess','near','selected_normalization']} for k,m in models.items()})
summary['nearest_correction_pct']=float((C[0]/data['C'][0]-1)*100)
summary['raw_u_max']=max(rows,key=lambda q:q['u_recorded'])
summary['latest_near_ratio_range']=[float(min(models['G2']['R'][:5])),float(max(models['G2']['R'][:5]))]
threshold_rows=read(ROOT/'outputs/task16_recess_geometry/monte_carlo_summary_32.csv')
threshold_checks=[]
af=np.isin(d,anchor_distances)
for threshold in [.1,5,10,20,40,60]:
 pp=np.array([float(q['probability']) for q in threshold_rows if float(q['threshold_keV'])==threshold])
 norm=float(np.exp(np.mean(np.log(C[af]/pp[af]))))
 threshold_checks.append(dict(threshold_keV=threshold,nearest_ratio=float(C[0]/(norm*pp[0]))))
summary['threshold_sensitivity_G0_far_calibrated']=threshold_checks
summary['minimum_pooled_counts']=float(min(data['N']))
(P/'data/analysis_summary.json').write_text(json.dumps(summary,indent=2)+'\n')

os.environ['MPLCONFIGDIR']=str(ROOT/'work/radioactivity/mplcache')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':7.5,'axes.labelsize':8,'legend.fontsize':6.6,
 'xtick.labelsize':7,'ytick.labelsize':7,'pdf.fonttype':42,'axes.spines.top':False,'axes.spines.right':False,
 'lines.linewidth':1.0,'axes.linewidth':.6})
grey='#8c9399';blue='#205c8e';orange='#b84f28';green='#287c62'
# Figure1: direct representation of the original anomaly and the updated distance definition.
fig,ax=plt.subplots(figsize=(3.43,2.40));fig.subplots_adjust(left=.16,right=.98,bottom=.19,top=.96)
r=d+.021;u=C*r*r
Vu=Vy*np.outer(u,u)+np.diag((2*r*C*v['sd'])**2)
ax.errorbar(d*100,data['C']*d*d,yerr=np.sqrt((d*d*np.sqrt(data['N'])/data['T'])**2+(2*d*data['C']*v['sd'])**2),
 fmt='.',ms=3,color=grey,elinewidth=.6,label=r'Recorded $C_{\rm obs}d^2$')
ax.errorbar(d*100,u,yerr=np.sqrt(np.diag(Vu)),fmt='o',ms=2.5,color=blue,elinewidth=.6,capsize=1,
 label=r'Corrected $C(d+21\,\mathrm{mm})^2$')
m=models['G2'];ir=m['idx'];uu=m['A']*m['p']*(m['d']+.021)**2
ax.errorbar(m['d']*100,uu,yerr=m['A']*np.sqrt(np.diag(m['VP']))*(m['d']+.021)**2,
 fmt='D',ms=3,color=orange,mfc='white',elinewidth=.7,capsize=1,label='Geant4, geometry G2')
ax.set_xscale('log');ax.set_xticks([1,5,20,85]);ax.set_xticklabels(['1','5','20','85'])
ax.set(xlabel='Recorded separation d (cm)',ylabel=r'Rate $\times$ distance$^2$ (m$^2$ s$^{-1}$)',ylim=(0,26))
ax.legend(loc='lower center',frameon=False);ax.grid(alpha=.15)
for ext in ('pdf','png'):fig.savefig(P/'images'/f'distance_response.{ext}',dpi=250)
plt.close(fig)

# Figure2: hold out all near points; independent return-to-position check below.
fig,(ax,bx)=plt.subplots(2,1,figsize=(3.43,3.04),gridspec_kw={'height_ratios':[1.25,1]},sharex=False)
fig.subplots_adjust(left=.16,right=.98,bottom=.15,top=.98,hspace=.46)
for key,col,marker in [('G0',grey,'s'),('G1',green,'^'),('G2',orange,'D')]:
 m=models[key];near=m['d']<=.1
 ax.errorbar(m['d'][near]*100,m['R'][near],yerr=m['sr'][near],fmt=marker,ms=3,
  mfc='white' if key=='G0' else col,color=col,capsize=1,elinewidth=.65,label=key)
ax.axhline(1,color='#444444',lw=.8);ax.set(xlim=(0,11),ylim=(.55,1.08),ylabel='Data / model',xlabel='Recorded separation d (cm)')
ax.legend(frameon=False,ncol=3,loc='lower right',handlelength=1);ax.grid(alpha=.15)
ax.text(.02,.96,'(a)',transform=ax.transAxes,va='top',fontsize=8)
pp=returns['pairs']
bx.errorbar([q['d']*100 for q in pp],[q['change_pct'] for q in pp],yerr=[q['change_se_pct'] for q in pp],
 fmt='o',ms=2.5,color=blue,capsize=1,elinewidth=.65)
bx.axhline(0,color='#444444',lw=.8);bx.set(xlim=(0,51),ylim=(-6,10),ylabel='Return change (%)',xlabel='Recorded separation d (cm)')
bx.text(.02,.96,'(b)',transform=bx.transAxes,va='top',fontsize=8);bx.grid(alpha=.15)
for ext in ('pdf','png'):fig.savefig(P/'images'/f'held_out_residuals.{ext}',dpi=250)
plt.close(fig)
print(json.dumps({k:summary[k] for k in ['nearest_correction_pct','max_absolute_all_vs_selected_rate_change_pct','max_near_all_vs_selected_rate_change_pct','repeatability','latest_near_ratio_range','models']},indent=2))
