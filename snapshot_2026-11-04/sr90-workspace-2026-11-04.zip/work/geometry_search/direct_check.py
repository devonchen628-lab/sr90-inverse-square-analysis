from pathlib import Path
import os,sys,json,csv,subprocess,concurrent.futures,time
import numpy as np
from search import ROOT,W,OUT,BIN,SPEC,env,case_name,get
r=json.loads((OUT/'refined_results.json').read_text())[0]; c=(r['offset_mm'],r['vertical_y_mm'],r['source_aperture_diameter_mm']/2)
def run(z):
 dist,rep=z;dr=W/'direct'/case_name(c);dr.mkdir(parents=True,exist_ok=True);f=dr/f'd{int(dist*1000)}_r{rep}.csv';seed=2100000000+int(dist*1000)*10000+rep*11003
 cmd=[str(BIN),str(SPEC),str(f),str(dist),'150000','1000',str(seed),'11',str(c[2]),'direct','10','10',str(c[0]),str(c[1]),'1']
 with f.with_suffix('.log').open('w') as log:subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
 text=f.with_suffix('.log').read_text();assert not any(t in text for t in ['G4Exception','Overlap is detected','Fatal','ERROR'])
 print('DIRECT',dist,rep,flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:list(ex.map(run,[(d,i) for d in [.01,.1] for i in [0,1]]))
out=[]
for dist,i in [(.01,0),(.1,4)]:
 vals=[]
 for rep in [0,1]:
  f=W/'direct'/case_name(c)/f'd{int(dist*1000)}_r{rep}.csv';row=next(x for x in csv.DictReader(f.open()) if float(x['threshold_keV'])==10);vals.append((float(row['probability']),float(row['direct_se'])))
 p=np.mean([x[0] for x in vals]);se=np.sqrt(sum(x[1]**2 for x in vals))/2;sp=r['probability'][i];ss=r['probability_se'][i];out.append(dict(distance_cm=dist*100,direct_probability=p,direct_se=se,staged_probability=sp,staged_se=ss,combined_standard_errors=(p-sp)/np.hypot(se,ss)))
(OUT/'direct_validation.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
