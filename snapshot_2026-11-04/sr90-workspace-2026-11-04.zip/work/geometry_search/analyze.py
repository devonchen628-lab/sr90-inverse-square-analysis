from pathlib import Path
import sys,csv,json,os
import numpy as np
from scipy.interpolate import PchipInterpolator
ROOT=Path('/Users/chenqiyue/Documents/Codex/2026-10-29/r');W=ROOT/'work/geometry_search';OUT=ROOT/'outputs/task16_geometry_search'
sys.path.insert(0,str(W));from search import get,score,d,case_name
sys.path.insert(0,str(ROOT/'work/rigid_mount_resimulation'));from task16_inputs import load
v=load(); md=np.array(d); idx=np.array([np.where(v['d']==x)[0][0] for x in md]); C=v['all']['net'][idx]; Vy=v['all']['Vy'][np.ix_(idx,idx)]; w=np.array([0]*5+[1/3]*3); H=np.eye(8)-np.outer(np.ones(8),w)
selected=json.loads((OUT/'refine_cases.json').read_text());results=[]
tau=1.9987336691853628e-6; bg=8/60
raw_c=v['all']['C'][idx]
for case in selected:
 c=tuple(case); precision=get(c,'precision'); phase='precision' if len(precision)>=4 else 'refine';batch=get(c,phase); p=batch.mean(axis=0); cov=np.cov(batch,rowvar=False,ddof=1)/len(batch); A=np.exp(w@(np.log(C)-np.log(p))); ratio=C/(A*p)
 g=PchipInterpolator(np.log(md+c[0]/1000),np.log(p)).derivative()(np.log(md+c[0]/1000))/(md+c[0]/1000)
 V=Vy+cov/np.outer(p,p)+np.diag((g*v['sd'])**2);r_cov=H@V@H.T; err=ratio*np.sqrt(np.maximum(0,np.diag(r_cov)));rms=float(np.sqrt(np.mean(np.log(ratio[:5])**2)))
 results.append(dict(offset_mm=c[0],left_external_offset_mm=c[0]-11,right_external_offset_mm=2,detector_recess_mm=3,source_recess_mm=6,lateral_x_mm=1,vertical_y_mm=c[1],source_aperture_diameter_mm=2*c[2],emitting_disk_diameter_mm=22,detector_active_mm=[10,10,.3],detector_entrance_mm=[10,10],normalization=float(A),near_log_rms=rms,distances_cm=(md*100).tolist(),measured_rates=C.tolist(),raw_rates=raw_c.tolist(),predicted_raw_rates=((A*p+bg/(1-tau*bg))/(1+tau*(A*p+bg/(1-tau*bg)))).tolist(),probability=p.tolist(),probability_se=np.sqrt(np.diag(cov)).tolist(),predicted_rates=(A*p).tolist(),ratio=ratio.tolist(),ratio_se=err.tolist(),batch_count=len(batch),phase=phase,nsource_per_batch=(400000 if phase=='precision' else 150000),prediction_covariance=cov.tolist()))
results.sort(key=lambda x:x['near_log_rms']); (OUT/'refined_results.json').write_text(json.dumps(results,indent=2))
with (OUT/'refined_comparisons.csv').open('w',newline='') as f:
 fields=['case','offset_mm','left_external_offset_mm','vertical_y_mm','lateral_x_mm','source_aperture_diameter_mm','d_cm','raw_data_cps','predicted_raw_cps','corrected_data_cps','simulation_cps','data_over_simulation','conditional_se','anchor'];o=csv.DictWriter(f,fieldnames=fields);o.writeheader()
 for r in results:
  for i in range(8):o.writerow(dict(case=case_name((r['offset_mm'],r['vertical_y_mm'],r['source_aperture_diameter_mm']/2)),offset_mm=r['offset_mm'],left_external_offset_mm=r['left_external_offset_mm'],vertical_y_mm=r['vertical_y_mm'],lateral_x_mm=1,source_aperture_diameter_mm=r['source_aperture_diameter_mm'],d_cm=r['distances_cm'][i],raw_data_cps=r['raw_rates'][i],predicted_raw_cps=r['predicted_raw_rates'][i],corrected_data_cps=r['measured_rates'][i],simulation_cps=r['predicted_rates'][i],data_over_simulation=r['ratio'][i],conditional_se=r['ratio_se'][i],anchor=i>=5))
sc=json.loads((OUT/'screen.json').read_text())
with (OUT/'screen_results.csv').open('w',newline='') as f:
 fields=['offset_mm','vertical_mm','lateral_mm','aperture_diameter_mm','score_log_rms']+[f'ratio_{n}cm' for n in ['1','2p5','5','7p5','10','30','50','85']];o=csv.DictWriter(f,fieldnames=fields);o.writeheader()
 for s in sc:o.writerow(dict(offset_mm=s['offset_mm'],vertical_mm=s['vertical_mm'],lateral_mm=s['lateral_mm'],aperture_diameter_mm=2*s['aperture_radius_mm'],score_log_rms=s['score_log_rms'],**{fields[5+i]:x for i,x in enumerate(s['ratios'])}))
os.environ.setdefault('MPLCONFIGDIR','/private/tmp/radio-mpl');import matplotlib;matplotlib.use('Agg');import matplotlib.pyplot as plt
plt.rcParams.update({'font.size':11,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42})
best=results[0]; fig,(ax,bx)=plt.subplots(2,1,figsize=(9,7.2),sharex=True,gridspec_kw={'height_ratios':[1.1,1]});fig.subplots_adjust(left=.13,right=.97,top=.88,bottom=.14,hspace=.15)
raw=v['all'];ax.errorbar(v['d']*100,raw['net'],yerr=raw['net']*np.sqrt(np.diag(raw['Vy'])),fmt='o',ms=3.5,color='#235e83',label='Measurements (all repeats)',capsize=1)
ax.errorbar(md*100,best['predicted_rates'],yerr=np.array(best['probability_se'])*best['normalization'],fmt='s',mfc='white',ms=5,color='#c15431',capsize=2,label='Geant4: best refined scenario')
holdpath=OUT/'holdout_results.json'
if holdpath.exists():
 hold=json.loads(holdpath.read_text());hx=np.array([q['d_cm'] for q in hold]);hy=np.array([q['predicted_cps'] for q in hold]);he=np.array([q['MC_se'] for q in hold])*best['normalization']
 ax.errorbar(hx,hy,yerr=he,fmt='x',ms=5,color='#704695',capsize=2,label='Additional simulated distances')
ax.set_xscale('log');ax.set_yscale('log');ax.set_ylabel('Corrected rate (counts / s)');ax.legend(frameon=False);ax.grid(alpha=.15)
for j,r in enumerate(results[:3]):bx.errorbar(md[:5]*100*(1+(j-1)*.018),r['ratio'][:5],yerr=r['ratio_se'][:5],fmt=['o','s','^'][j],ms=4,capsize=2,label=f"offset {r['offset_mm']} mm, y {r['vertical_y_mm']} mm, aperture {r['source_aperture_diameter_mm']:g} mm")
if holdpath.exists():
 bx.errorbar(hx,[q['data_over_simulation'] for q in hold],yerr=[q['conditional_standard_error'] for q in hold],fmt='x',ms=5,color='#704695',capsize=2,label='Additional distances (not selected)')
bx.axhline(1,color='#444',ls='--',lw=1);bx.set(xlabel='Recorded distance d (cm)',ylabel='Measured / simulated',xlim=(.85,100));bx.set_xticks([1,2.5,5,10,30,50,85],labels=['1','2.5','5','10','30','50','85']);bx.grid(alpha=.15);bx.legend(frameon=False,fontsize=8,loc='best');fig.suptitle('Geometry search: near-field shape after far-point scaling',fontsize=14);fig.text(.13,.045,'Far scale points: 30, 50 and 85 cm. Scenarios selected using the near data; error bars omit unknown apparatus systematics.',fontsize=8)
fig.savefig(OUT/'geometry_search_comparison.png',dpi=200)
print(json.dumps(results[:3],indent=2))

# Threshold sensitivity reuses the same primary histories; these are correlated scenarios.
thresholds=[.1,5.,10.,20.,40.,60.]; threshold_results=[]
for r in results:
 c=(r['offset_mm'],r['vertical_y_mm'],r['source_aperture_diameter_mm']/2); vec=[]
 for f in sorted((W/r['phase']/case_name(c)).glob('batch_*.json')):
  rr=list(csv.DictReader(f.with_suffix('.csv').open()));vec.append([[float(next(x['probability'] for x in rr if abs(float(x['distance_m'])-di)<1e-9 and float(x['threshold_keV'])==t)) for t in thresholds] for di in md])
 mat=np.array(vec).mean(axis=0)
 for j,t in enumerate(thresholds):
  pp=mat[:,j];aa=np.exp(w@(np.log(C)-np.log(pp)));rat=C/(aa*pp);threshold_results.append(dict(offset_mm=c[0],vertical_mm=c[1],aperture_diameter_mm=2*c[2],threshold_keV=t,log_rms=float(np.sqrt(np.mean(np.log(rat[:5])**2))),near_ratios=rat[:5].tolist()))
(OUT/'threshold_sensitivity.json').write_text(json.dumps(threshold_results,indent=2))
