from pathlib import Path
import json
from search import run,OUT
c=(25,3,5.5);f=OUT/'refine_cases.json'; rr=json.loads(f.read_text());
if list(c) not in rr:rr.append(list(c));f.write_text(json.dumps(rr,indent=2))
for i in range(6):run(c,i,150000,6000,'refine')
