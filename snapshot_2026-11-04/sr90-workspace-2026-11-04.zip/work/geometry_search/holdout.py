from pathlib import Path
import os,sys,json,csv,subprocess,concurrent.futures,time
import numpy as np
from search import ROOT,W,OUT,BIN,SPEC,env,case_name
sys.path.insert(0,str(ROOT/'work/rigid_mount_resimulation'));from task16_inputs import load
r=json.loads((OUT/'refined_results.json').read_text())[0];c=(r['offset_mm'],r['vertical_y_mm'],r['source_aperture_diameter_mm']/2);ds=np.array([.125,.175,.25,.375,.6,.75])
def run(rep):
 dr=W/'holdout'/case_name(c);dr.mkdir(parents=True,exist_ok=True);f=dr/f'batch_{rep}.csv';seed=2140000000+rep*100003
 cmd=[str(BIN),str(SPEC),str(f),','.join(map(str,ds)),'150000','6000',str(seed),'11',str(c[2]),'smc','10','10',str(c[0]),str(c[1]),'1']
 with f.with_suffix('.log').open('w') as log:subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
 t=f.with_suffix('.log').read_text();assert not any(x in t for x in ['G4Exception','Overlap is detected','Fatal','ERROR']);print('HOLDOUT',rep,flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:list(ex.map(run,range(4)))
vec=[]
for rep in range(4):
 f=W/'holdout'/case_name(c)/f'batch_{rep}.csv';rows=list(csv.DictReader(f.open()));vec.append([float(next(z['probability'] for z in rows if abs(float(z['distance_m'])-di)<1e-9 and float(z['threshold_keV'])==10)) for di in ds])
vec=np.array(vec);p=vec.mean(axis=0);cov=np.cov(vec,rowvar=False,ddof=1)/len(vec);A=r['normalization'];v=load();idx=np.array([np.where(v['d']==x)[0][0] for x in ds]);C=v['all']['net'][idx]
# Far-scale uncertainty, including shared experimental and simulation fluctuations; independent holdout batches.
aidx=np.array([np.where(v['d']==x)[0][0] for x in [.3,.5,.85]]); weights=np.ones(3)/3; pc=np.array(r['probability']);Vmc=np.array(r['prediction_covariance']); Vanchor=v['all']['Vy'][np.ix_(aidx,aidx)]+Vmc[5:,5:]/np.outer(pc[5:],pc[5:]);slogA=np.sqrt(weights@Vanchor@weights)
out=[]
for j,x in enumerate(ds):
 rat=C[j]/(A*p[j]);se=rat*np.sqrt(v['all']['Vy'][idx[j],idx[j]]+cov[j,j]/p[j]**2+slogA**2);out.append(dict(d_cm=100*x,corrected_data_cps=C[j],predicted_cps=A*p[j],data_over_simulation=rat,conditional_standard_error=se,MC_probability=p[j],MC_se=np.sqrt(cov[j,j])))
(OUT/'holdout_results.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
