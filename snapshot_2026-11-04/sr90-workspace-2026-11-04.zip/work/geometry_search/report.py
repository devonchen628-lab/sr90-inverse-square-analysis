from pathlib import Path
import json,csv
P=Path('/Users/chenqiyue/Documents/Codex/2026-10-29/r/outputs/task16_geometry_search')
r=json.loads((P/'refined_results.json').read_text());b=r[0];v=json.loads((P/'direct_validation.json').read_text());h=json.loads((P/'holdout_results.json').read_text());th=json.loads((P/'threshold_sensitivity.json').read_text());tb=[x for x in th if x['offset_mm']==b['offset_mm'] and x['vertical_mm']==b['vertical_y_mm'] and x['aperture_diameter_mm']==b['source_aperture_diameter_mm']]
s='# Task 16: Geant4 条件扫描与对照\n\n'
s+='## 问题与方法\n\n60 组（距离偏移 17、21、25、29、33 mm；竖直错位 0、3、6、9 mm；源出口直径 8、11、14 mm），横向另一方向固定 1 mm。每组 1 次低统计筛选，筛选前 12 组加已用基准进行两次独立复跑，最后前五组加两个额外选择的对照进行 6 次独立复跑。筛选有随机波动，不保证找到连续参数空间全局最优。\n\n'
s+='使用 Task16 全部 141 个记录按距离汇总、背景和约 2 μs 恢复时间修正的数据。每组对 30、50、85 cm 三点作一个共同幅度定标，按五个近点的 log(实测/模拟) 均方根评估形状。近点参与模型选择，不是独立验证；随后另外模拟 12.5、17.5、25、37.5、60、75 cm 点进行独立距离检验。这些距离没有用于参数排名，但来自同一实验扫描。\n\n'
s+=f"## 精算中近点得分最好的组合\n\n- 轴向活性面距离：r = d + {b['offset_mm']} mm。\n- 按右外部偏移 2 mm、探测器凹陷 3 mm、源凹陷 6 mm 的设定，剩余左外部偏移为 {b['left_external_offset_mm']} mm。\n- 两个横向方向的源与探测器中心错位：x = 1 mm、y = {b['vertical_y_mm']} mm。探测器和入口框一起平移，面平行。\n- 源出口直径 {b['source_aperture_diameter_mm']:g} mm；发射圆片直径 22 mm（建模假设）。\n- 探测器有效面 10 × 10 mm²、有效厚度 0.3 mm；入口 10 × 10 mm²。\n- 空气中传输；Geant4 11.4.3，Livermore 电磁物理；近似等权 90Sr / 90Y β 能谱；假定源箔、亚克力与铝框；同一初级粒子及其子代在硅中沉积至少 10 keV 计一次。阈值不是独立测得的电子学阈值。\n- 多数候选 6 个独立批次，每批次 150,000 个初级历史；高精度候选另使用 4 批、每批 400,000 个初级历史；后续 4 批未完成，本结果保留蒙特卡罗统计限制；每个粒子历史经加权重采样，重采样不能当作独立源衰变。\n- 总归一化 A = {b['normalization']:.5g}（模型比例因子，不能直接当作已经独立测定的源活度）。\n\n"
s+='| d (cm) | 修正实测 (s⁻¹) | 定标后模拟 (s⁻¹) | 实测 / 模拟 ± 条件标准误 | 用途 |\n|---:|---:|---:|---:|---|\n'
for i,d in enumerate(b['distances_cm']):s+=f"| {d:g} | {b['measured_rates'][i]:.2f} | {b['predicted_rates'][i]:.2f} | {b['ratio'][i]:.3f} ± {b['ratio_se'][i]:.3f} | {'用于筛选' if i<5 else '定标'} |\n"
s+='\n预测原始计数率的对照（在模拟预测上加入背景并按非延展死时间近似折回观测率）：\n\n| d (cm) | 原始实测 (s⁻¹) | 预测原始计数 (s⁻¹) |\n|---:|---:|---:|\n'
for i,d in enumerate(b['distances_cm']):s+=f"| {d:g} | {b['raw_rates'][i]:.2f} | {b['predicted_raw_rates'][i]:.2f} |\n"
s+='\n误差是给定模型条件下的统计标准误，包含独立批次 Monte Carlo、计数及定标相关性、已表征的 rail 读数；不包含真实孔径、offset、错位、材料、阈值和电子学等未知系统误差，不能用它断言全部物理误差已在 1σ 内。\n\n'
s+='## 单因素对照\n\n以下比较每对只改变一个输入；每组各自用同一三个远点定标。数值为最近点实测/模拟，不确定度尚未包含共同几何系统误差。\n\n'
for off,y,diam in [(29,0,8),(29,0,11),(29,0,14),(21,3,11),(25,3,11)]:
 q=next(x for x in r if x['offset_mm']==off and x['vertical_y_mm']==y and x['source_aperture_diameter_mm']==diam)
 s+=f"- offset {off} mm，y {y} mm，源孔直径 {diam} mm：{q['ratio'][0]:.3f} ± {q['ratio_se'][0]:.3f}。\n"
s+='\n前 3 项比较源孔径；后 2 项比较 offset。由于每组都重新做远点定标，变化反映整个近远距离响应的形状，而不是只反映近点绝对接收率。\n\n'
s+='## 未用于筛选的中间距离\n\n| d (cm) | 修正实测 (s⁻¹) | 模拟 (s⁻¹) | 实测 / 模拟 ± 近似条件标准误 |\n|---:|---:|---:|---:|\n'
for x in h:s+=f"| {x['d_cm']:g} | {x['corrected_data_cps']:.2f} | {x['predicted_cps']:.2f} | {x['data_over_simulation']:.3f} ± {x['conditional_standard_error']:.3f} |\n"
s+='\n这些点使用独立模拟批次；近似误差含定标尺度与统计波动，但未包含共同几何系统误差，也未完整处理实验背景与定标的数据相关性和 rail 误差。\n\n## 模拟技术复核\n\n'
for x in v:s+=f"- d = {x['distance_cm']:g} cm：直接追踪与加速重采样的预测相差 {x['combined_standard_errors']:.2f} 个合并统计标准误。\n"
s+='\n相同几何下改变硅沉积硬阈值，近点实测/模拟：\n\n'
for x in tb:s+=f"- {x['threshold_keV']:g} keV："+', '.join(f'{z:.3f}' for z in x['near_ratios'])+'。\n'
s+='\n## 解释限制\n\n候选几何是利用相同实验数据事后筛选出的假设，几何、源发射分布、材料和电子学响应会互相补偿。几组组合都可能接近数据；数值最好不等于真实 setup。若最佳参数远离实测尺寸，不能仅因曲线贴合就修改实验记录。必须独立测量有效面距离、源孔及对中情况，再检查计数率线性。未做所有 32 个测距点的仿真，也未扫描源谱、材料厚度、探测器阈值之外的响应或所有倾斜角；不能声称穷尽了所有解释。\n'
(P/'analysis_zh.md').write_text(s)
