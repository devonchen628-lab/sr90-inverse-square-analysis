from pathlib import Path
import os,sys,json,csv,time,itertools,subprocess,concurrent.futures,hashlib
import numpy as np
ROOT=Path('/Users/chenqiyue/Documents/Codex/2026-10-29/r'); W=ROOT/'work/geometry_search'; OUT=ROOT/'outputs/task16_geometry_search'
BIN=ROOT/'work/offset21_shift31/build/task16_sensitivity.app/Contents/MacOS/task16_sensitivity'
BASE=Path('/Users/chenqiyue/Documents/Codex/2026-10-12/https-chatgpt-com-share-6acd35f5-5168'); SPEC=BASE/'outputs/task16_geant4/inputs/spectra_unique.csv'; G=BASE/'.runtime/geant4/share/Geant4/data'
env=os.environ.copy()
for key,n in [('G4LEDATA','EMLOW'),('G4LEVELGAMMADATA','PhotonEvaporation'),('G4RADIOACTIVEDATA','RadioactiveDecay'),('G4ENSDFSTATEDATA','ENSDFSTATE')]:env[key]=str(next(G.glob(n+'*')))
for k in ('TASK16_GEOMETRY_VIEW','TASK16_VIS_MACRO'):env.pop(k,None)
d=[.01,.025,.05,.075,.1,.3,.5,.85]
def case_name(c):return 'off%02d_y%02d_ap%02d'% (c[0],c[1],round(c[2]*2))
def run(c,rep,n,pop,phase):
 name=case_name(c);dr=W/phase/name;dr.mkdir(parents=True,exist_ok=True);target=dr/f'batch_{rep:02d}.csv'; meta=target.with_suffix('.json')
 seed=({'screen':1900000000,'mid':1950000000,'refine':2000000000,'precision':2050000000}[phase])+int(c[0])*100000+int(c[1])*2000+round(c[2]*2)*100+rep*100003
 cmd=[str(BIN),str(SPEC),str(target),','.join(map(str,d)),str(n),str(pop),str(seed),'11',str(c[2]),'smc','10','10',str(c[0]),str(c[1]),'1']
 if meta.exists():
  m=json.loads(meta.read_text());assert m['cmd']==cmd;return
 start=time.time()
 with target.with_suffix('.log').open('w') as f:subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
 rows=list(csv.DictReader(target.open()));assert len(rows)==48 and all(float(x['probability'])>=0 for x in rows)
 log=target.with_suffix('.log').read_text();assert not any(x in log for x in ('G4Exception','Overlap is detected','Fatal','ERROR'))
 meta.write_text(json.dumps({'cmd':cmd,'elapsed_s':time.time()-start,'seed':seed},indent=2)); print('DONE',phase,name,rep,round(time.time()-start,1),flush=True)
def get(c,phase):
 out=[]
 for f in sorted((W/phase/case_name(c)).glob('batch_*.json')):
  rows=list(csv.DictReader(f.with_suffix('.csv').open()));out.append([float(next(x['probability'] for x in rows if abs(float(x['distance_m'])-di)<1e-9 and float(x['threshold_keV'])==10)) for di in d])
 return np.array(out)
def score(c,phase):
 v=get(c,phase);p=v.mean(axis=0); raw=list(csv.DictReader((ROOT/'output/pdf/radioactivity_report/data/pooled_measurements.csv').open())); data=np.array([float(next(x['corrected_rate_cps'] for x in raw if abs(float(x['d_m'])-di)<1e-9)) for di in d]);A=np.exp(np.mean(np.log(data[5:]/p[5:]))); ratio=data/(A*p);return np.mean(np.log(ratio[:5])**2)**.5,A,ratio
cases=list(itertools.product([17,21,25,29,33],[0,3,6,9],[4.,5.5,7.]))
if __name__=='__main__':
 phase=sys.argv[1]
 if phase=='screen':
  todo=[(c,0,40000,2200,'screen') for c in cases]
  with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:list(ex.map(lambda args:run(*args),todo))
  rr=[]
  for c in cases:
   sc,A,ratio=score(c,'screen');rr.append(dict(offset_mm=c[0],vertical_mm=c[1],lateral_mm=1,aperture_radius_mm=c[2],score_log_rms=sc,ratios=ratio.tolist(),A=A))
  rr.sort(key=lambda q:q['score_log_rms']);(OUT/'screen.json').write_text(json.dumps(rr,indent=2)); print('SCREEN TOP',json.dumps(rr[:8]),flush=True)
 elif phase=='mid':
  rr=json.loads((OUT/'screen.json').read_text()); chosen=[(int(x['offset_mm']),int(x['vertical_mm']),x['aperture_radius_mm']) for x in rr[:12]]
  chosen += [(21,3,5.5)];chosen=list(dict.fromkeys(chosen));(OUT/'mid_cases.json').write_text(json.dumps(chosen,indent=2))
  todo=[(c,k,100000,5000,'mid') for c in chosen for k in range(2)]
  with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:list(ex.map(lambda args:run(*args),todo))
  vals=[]
  for c in chosen:
   sc,A,ratio=score(c,'mid');vals.append(dict(offset_mm=c[0],vertical_mm=c[1],aperture_radius_mm=c[2],score_log_rms=sc,ratios=ratio.tolist(),A=A))
  vals.sort(key=lambda x:x['score_log_rms']);(OUT/'mid_results.json').write_text(json.dumps(vals,indent=2));print('MID TOP',json.dumps(vals[:6]),flush=True)
 elif phase=='refine':
  rr=json.loads((OUT/'mid_results.json').read_text());chosen=[(int(x['offset_mm']),int(x['vertical_mm']),x['aperture_radius_mm']) for x in rr[:5]]
  chosen += [(21,3,5.5)];chosen=list(dict.fromkeys(chosen));(OUT/'refine_cases.json').write_text(json.dumps(chosen,indent=2))
  todo=[(c,k,150000,6000,'refine') for c in chosen for k in range(6)]
  with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:list(ex.map(lambda args:run(*args),todo))
  print('REFINE COMPLETE',flush=True)
