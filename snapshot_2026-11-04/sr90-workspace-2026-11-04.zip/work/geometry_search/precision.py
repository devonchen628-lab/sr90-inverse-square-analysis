import concurrent.futures,json
from search import run,OUT
r=json.loads((OUT/'refined_results.json').read_text())[0]; c=(r['offset_mm'],r['vertical_y_mm'],r['source_aperture_diameter_mm']/2)
(OUT/'precision_case.json').write_text(json.dumps(c))
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:list(ex.map(lambda i:run(c,i,400000,16000,'precision'),range(8)))
