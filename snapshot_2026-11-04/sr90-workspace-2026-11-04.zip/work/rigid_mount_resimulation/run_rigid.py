"""Fixed complete 32-distance Geant4 resimulation constrained to rigid posts."""
from pathlib import Path
import concurrent.futures,csv,hashlib,json,os,subprocess,sys,time
W=Path(__file__).resolve().parent
BASE=Path('/Users/chenqiyue/Documents/Codex/2026-10-12/https-chatgpt-com-share-6acd35f5-5168/outputs/task16_geant4')
BIN=W.parent/'air_vacuum_check/vacuum_scan/build/task16_rigid';SPEC=BASE/'inputs/spectra_unique.csv'
ENV=os.environ.copy()
for key,name in [('G4LEDATA','EMLOW'),('G4LEVELGAMMADATA','PhotonEvaporation'),('G4RADIOACTIVEDATA','RadioactiveDecay'),('G4ENSDFSTATEDATA','ENSDFSTATE')]:
 ENV[key]=str(next((BASE.parents[1]/'.runtime/geant4/share/Geant4/data').glob(name+'*')))
validation='--validate' in sys.argv
OUT=W/('validation' if validation else 'runs');OUT.mkdir(parents=True,exist_ok=True)
distances=[.01,.1] if validation else sorted({float(q['distance_m']) for q in csv.DictReader((BASE/'results/book2_dense_comparison/mc_summary_32_distances.csv').open())})
nsource=10000 if validation else 200000;npop=1000 if validation else 5000;R=1 if validation else 12
BH=hashlib.sha256(BIN.read_bytes()).hexdigest();SH=hashlib.sha256(SPEC.read_bytes()).hexdigest()
plan=dict(distances_m=distances,scenarios=['aligned','height5_yaw5'],source_events_per_batch=nsource,replay_population=npop,independent_batches=R,
 binary_sha256=BH,spectrum_sha256=SH,seed_formula='1661000000 + replicate * 100003',
 apparatus_constraints='Rigid upright supports; no horizontal-axis base pitch, no 50mm pivot arm, no extra 5.2mm axial shift. Rail is Z, vertical is Y; yaw is rotation about Y. Active-centre axial separation fixed at d+16mm.',
 scenario_parameters=dict(aligned=dict(height_mm=0,source_yaw_deg=0,detector_yaw_deg=0),height5_yaw5=dict(height_mm=5,source_yaw_deg=-5,detector_yaw_deg=5)),
 interpretation='Height and yaw values are unmeasured sensitivity inputs. Physical rail/posts are not added as particle-scattering volumes; photo constrains kinematics only.',
 pooling='Retain every completed independent batch. Estimate cross-distance/scenario covariance between complete probability vectors; paired ratio controls reduce source-library variance.')
pf=OUT/'plan.json'
if pf.exists():assert json.loads(pf.read_text())==plan
else:pf.write_text(json.dumps(plan,indent=2)+'\n')
def run(rep):
 seed=1661000000+rep*100003;target=OUT/f'batch_{rep:02d}.csv';meta=target.with_suffix('.json')
 cmd=[str(BIN),str(SPEC),str(target),','.join(map(str,distances)),str(nsource),str(npop),str(seed)]
 if meta.exists():
  m=json.loads(meta.read_text());assert m['command']==cmd and m['binary_sha256']==BH
  return
 t=time.time()
 with target.with_suffix('.log').open('w') as f:subprocess.run(cmd,env=ENV,stdout=f,stderr=subprocess.STDOUT,check=True)
 rows=list(csv.DictReader(target.open()));assert len(rows)==len(distances)*2*6
 assert all(float(q['pivot_arm_mm'])==0 for q in rows)
 meta.write_text(json.dumps(dict(command=cmd,replicate=rep,seed=seed,source_events=nsource,npop=npop,binary_sha256=BH,spectrum_sha256=SH,elapsed_s=time.time()-t),indent=2)+'\n')
 print(f'Completed rigid-post batch {rep+1}/{R}; {time.time()-t:.1f}s',flush=True)
if __name__=='__main__':
 with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:list(pool.map(run,range(R)))
