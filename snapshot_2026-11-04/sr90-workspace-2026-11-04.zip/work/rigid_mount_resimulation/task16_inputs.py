"""Read-only Task16 processing and shared metrology; no alignment fitted."""
from pathlib import Path
import csv,json
import numpy as np
from scipy.interpolate import PchipInterpolator

ROOT=Path('/Users/chenqiyue/Documents/Codex/2026-10-29/r')
BASE=Path('/Users/chenqiyue/Documents/Codex/2026-10-12/https-chatgpt-com-share-6acd35f5-5168/outputs/task16_geant4')
def read(p):return list(csv.DictReader(p.open(encoding='utf-8-sig')))

def load():
 fit=json.loads((BASE/'results/book2_dense_comparison/fit_summary.json').read_text())
 tau=fit['effective_recovery_us']*1e-6;stau=fit['recovery_fit_only_se_us']*1e-6
 B=fit['background_rate'];sB=fit['background_rate_se']
 oldA=next(q['normalization'] for q in fit['reports'] if q['threshold_keV']==10)
 source=json.loads((ROOT/'outputs/task16_closest_three/processing_details.json').read_text())
 selected=read(ROOT/'outputs/task16_closest_three/task16_selected_three.csv')
 raw=read(ROOT/'outputs/task16_closest_three/task16_all_measurements.csv')
 d=np.array([float(q['d_m']) for q in selected]);r0=d+.016
 air=[q for q in read(BASE/'results/book2_dense_comparison/mc_summary_32_distances.csv') if float(q['threshold_keV'])==10]
 assert np.array_equal(d,[float(q['distance_m']) for q in air])
 p0=np.array([float(q['probability']) for q in air]);sp0=np.array([float(q['se']) for q in air])
 Vmc=np.diag((sp0/p0)**2)
 g0=PchipInterpolator(np.log(r0),np.log(p0)).derivative()(np.log(r0))/r0
 sd=.0005/np.sqrt(3);soff=np.sqrt(4)*sd
 Vdistance=np.diag((g0*sd)**2)+np.outer(g0*soff,g0*soff)
 def dataset(use_all):
  N=[];T=[];birges=[]
  for i,x in enumerate(d):
   rr=[q for q in raw if float(q['d_m'])==x]
   if use_all:n=sum(float(q['counts']) for q in rr);t=sum(float(q['time_s']) for q in rr)
   else:n=float(selected[i]['counts_total']);t=float(selected[i]['time_total_s'])
   fullrate=sum(float(q['counts']) for q in rr)/sum(float(q['time_s']) for q in rr)
   Q=sum((float(q['counts'])-fullrate*float(q['time_s']))**2/(fullrate*float(q['time_s'])) for q in rr)
   birges.append(max(1.,np.sqrt(Q/(len(rr)-1))));N.append(n);T.append(t)
  N=np.array(N);T=np.array(T);C=N/T;sC=np.sqrt(N)/T
  if use_all:sC*=np.array(birges)
  net=C/(1-tau*C)-B/(1-tau*B)
  vC=(sC/(1-tau*C)**2/net)**2;b=-sB/(1-tau*B)**2/net
  t=stau*(C*C/(1-tau*C)**2-B*B/(1-tau*B)**2)/net
  Vy=np.diag(vC)+np.outer(b,b)+np.outer(t,t);V=Vy+Vmc+Vdistance
  w=np.linalg.solve(V,np.ones(len(d)));w/=w.sum()
  A=np.exp(w@(np.log(net)-np.log(p0)))
  H=np.eye(len(d))-np.outer(np.ones(len(d)),w)
  ratio=net/(A*p0);Vr=H@V@H.T;u=net*r0*r0
  Vu=Vy*np.outer(u,u)+np.diag((2*r0*net*sd)**2)+np.outer(2*r0*net*soff,2*r0*net*soff)
  return dict(N=N,T=T,C=C,net=net,Vy=Vy,V=V,w=w,A=A,ratio=ratio,Vratio=Vr,u=u,Vu=Vu,birge=np.array(birges),slogA=np.sqrt(w@V@w))
 return dict(d=d,r0=r0,p0=p0,sp0=sp0,Vmc=Vmc,g0=g0,sd=sd,soff=soff,source=source,raw=raw,selected=dataset(False),all=dataset(True),oldA=oldA)
