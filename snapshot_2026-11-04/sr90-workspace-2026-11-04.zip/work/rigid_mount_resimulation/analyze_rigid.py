"""Full 32-distance rigid-post controls; preserve the rejected pivot test."""
from pathlib import Path
import csv,json,math,hashlib
import numpy as np
from scipy.interpolate import PchipInterpolator
from task16_inputs import load,read,ROOT

W=Path(__file__).resolve().parent;OUT=ROOT/'outputs/task16_rigid_mount32';OUT.mkdir(parents=True,exist_ok=True)
def write(name,rows):
 with (OUT/name).open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

v=load();d=v['d'];r0=v['r0'];p0=v['p0'];sp0=v['sp0'];sel=v['selected'];all_data=v['all'];M=len(d)
plan=json.loads((W/'runs/plan.json').read_text());metas=sorted((W/'runs').glob('batch_[0-9][0-9].json'))
assert len(metas)==plan['independent_batches'],'Wait until the complete fixed run finishes.'
assert np.array_equal(d,plan['distances_m']) and plan['scenarios']==['aligned','height5_yaw5']
rep=[];records=[];seeds=[];raw_geometry=[]
for p in metas:
 m=json.loads(p.read_text());seeds.append(m['seed'])
 assert m['binary_sha256']==plan['binary_sha256'] and m['spectrum_sha256']==plan['spectrum_sha256']
 rr=[q for q in read(p.with_suffix('.csv')) if float(q['threshold_keV'])==10]
 assert len(rr)==2*M
 vals=[]
 for k,scenario in enumerate(plan['scenarios']):
  for x in d:
   q=next(a for a in rr if a['scenario']==scenario and float(a['distance_m'])==x)
   assert float(q['pivot_arm_mm'])==0
   h=float(q['h_mm']);X=float(q['local_front_x_mm']);Y=float(q['local_front_y_mm']);Z=float(q['local_front_z_mm'])
   assert abs(Y-h)<1e-8 and abs(np.sqrt(X*X+Y*Y+Z*Z)-np.sqrt(((x+.016)*1000)**2+h*h))<1e-8
   vals.append(float(q['probability']))
   records.append(dict(scenario=scenario,d_m=x,replicate=m['replicate'],seed=m['seed'],probability=vals[-1],source_events=m['source_events'],npop=m['npop'],metadata=str(p)))
 rep.append(vals)
assert len(set(seeds))==len(seeds)
rep=np.array(rep);R=len(rep);pm=rep.mean(axis=0);VP=np.cov(rep,rowvar=False,ddof=1)/R
assert (pm>0).all()
F=pm[M:]/pm[:M]
J=np.zeros((M,2*M))
for i in range(M):J[i,i]=-pm[M+i]/pm[i]**2;J[i,M+i]=1/pm[i]
VF=J@VP@J.T
leave=np.array([np.delete(rep,b,axis=0).mean(axis=0) for b in range(R)])
jack=leave[:,M:]/leave[:,:M];Vjack=(R-1)/R*((jack-jack.mean(axis=0)).T@(jack-jack.mean(axis=0)))
gF=PchipInterpolator(np.log(r0),np.log(F)).derivative()(np.log(r0))/r0
pred=p0*F
Vpred=VF*np.outer(p0,p0)+np.diag((F*sp0)**2)
H=np.eye(M)-np.outer(np.ones(M),sel['w'])
D=np.outer(np.ones(M),sel['w']*v['g0'])-np.diag(v['g0']+gF)
VR=H@(sel['Vy']+v['Vmc'])@H.T+VF/np.outer(F,F)
VR+=D@np.diag(np.full(M,v['sd']**2))@D.T+np.outer(D@np.ones(M)*v['soff'],D@np.ones(M)*v['soff'])
ratio=sel['net']/(sel['A']*pred)
ratio_all=all_data['net']/(all_data['A']*pred)
u_pred=sel['A']*pred*r0*r0;u_se=sel['A']*np.sqrt(np.diag(Vpred))*r0*r0
rows=[]
for i,x in enumerate(d):
 rows.append(dict(d_m=x,nominal_r_m=r0[i],selected_corrected_u=sel['u'][i],selected_u_se=np.sqrt(sel['Vu'][i,i]),
  all_corrected_u=all_data['u'][i],all_u_se_overdispersion=np.sqrt(all_data['Vu'][i,i]),all_Birge_factor=all_data['birge'][i],
  normalization=sel['A'],aligned_probability=p0[i],aligned_probability_se=sp0[i],
  aligned_predicted_u=sel['A']*p0[i]*r0[i]**2,aligned_predicted_u_se=sel['A']*sp0[i]*r0[i]**2,
  rerun_aligned_probability=pm[i],rerun_aligned_se=np.sqrt(VP[i,i]),direct_rigid_probability=pm[M+i],direct_rigid_se=np.sqrt(VP[M+i,M+i]),
  rigid_geometry_factor=F[i],geometry_factor_se=np.sqrt(max(0,VF[i,i])),geometry_factor_jackknife_se=np.sqrt(max(0,Vjack[i,i])),
  rigid_predicted_u=u_pred[i],rigid_predicted_u_se=u_se[i],
  selected_over_aligned=sel['ratio'][i],selected_over_aligned_se=sel['ratio'][i]*np.sqrt(max(0,sel['Vratio'][i,i])),
  selected_over_rigid=ratio[i],selected_over_rigid_se=ratio[i]*np.sqrt(max(0,VR[i,i])),all_over_rigid=ratio_all[i],
  rigid_height_mm=5,source_yaw_deg=-5,detector_yaw_deg=5,extra_axial_shift_mm=0))
write('comparison_32_distances.csv',rows);write('independent_batches.csv',records)
np.savez_compressed(OUT/'covariances.npz',distance_m=d,source_control_probability_covariance=VP,geometry_factor_covariance=VF,geometry_factor_jackknife_covariance=Vjack,
 rigid_probability_covariance=Vpred,data_u_covariance=sel['Vu'],data_over_rigid_log_covariance=VR,data_over_aligned_log_covariance=sel['Vratio'])

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'pdf.fonttype':42})
fig,(ax,bx)=plt.subplots(2,1,figsize=(10.6,8.7),sharex=True,gridspec_kw={'height_ratios':[1.2,1]})
fig.subplots_adjust(left=.10,right=.98,top=.875,bottom=.22,hspace=.14)
ax.errorbar(d*100,all_data['u'],yerr=np.sqrt(np.diag(all_data['Vu'])),fmt='o',ms=5.8,mfc='none',mec='#999999',ecolor='#cccccc',capsize=2,label='All repeats (repeat scatter included)',zorder=1)
ax.errorbar(d*100,sel['A']*p0*r0*r0,yerr=sel['A']*sp0*r0*r0,fmt='s',ms=3.5,color='#2b9348',capsize=2,label='Aligned air model',zorder=2)
ax.errorbar(d*100,u_pred,yerr=u_se,fmt='D',ms=4.1,mfc='white',color='#8651a6',capsize=2,label='Rigid-post sensitivity scenario',zorder=3)
ax.errorbar(d*100,sel['u'],yerr=np.sqrt(np.diag(sel['Vu'])),fmt='o',ms=3.8,color='#202020',capsize=2,label='Requested closest-three measurements',zorder=4)
ax.set_ylabel(r'$C_{\rm corrected}(d+16\,\mathrm{mm})^2$ (m$^2$ s$^{-1}$)');ax.legend(loc='best',fontsize=8.3)
bx.errorbar(d*100,sel['ratio'],yerr=sel['ratio']*np.sqrt(np.maximum(0,np.diag(sel['Vratio']))),fmt='o',ms=3.5,color='#2b9348',capsize=2,label='Measured / aligned model')
bx.errorbar(d*100,ratio,yerr=ratio*np.sqrt(np.maximum(0,np.diag(VR))),fmt='D',ms=4.1,mfc='white',color='#8651a6',capsize=2,label='Measured / rigid-post scenario')
bx.axhline(1,color='#888888',lw=1);bx.set(xlabel='Rail gap d (cm)',ylabel='Measured / predicted rate',xlim=(0,88));bx.legend(fontsize=8.3,loc='best')
for a in [ax,bx]:a.grid(alpha=.15);a.spines['right'].set_visible(False);a.spines['top'].set_visible(False)
fig.suptitle('Task16 resimulation: rigid supports, no base-pitch displacement',fontsize=14,y=.965)
fig.text(.5,.920,'32 actual paired control distances; air transport; 10 keV threshold; one shared Task16 normalization',ha='center',fontsize=9.3)
fig.text(.10,.128,'Purple scenario: height mismatch 5 mm, source yaw -5 deg, detector yaw +5 deg; centres fixed axially.',fontsize=8.1)
fig.text(.10,.091,'No 50 mm pivot arm or extra 5.2 mm gap. Height and yaw are illustrative inputs, not measured or fitted values.',fontsize=8)
fig.text(.10,.054,'Bars: conditional standard errors; common 0.58 mm offset uncertainty retained in data/model covariance.',fontsize=8)
fig.text(.10,.020,'Nominal model x paired Geant4 geometry factor at every distance; no interpolation or curve fit of control points.',fontsize=8)
fig.savefig(OUT/'rigid_mount_comparison.png',dpi=200);fig.savefig(OUT/'rigid_mount_comparison.pdf');plt.close(fig)

fig,ax=plt.subplots(figsize=(10,5.7));fig.subplots_adjust(left=.10,right=.98,top=.86,bottom=.22)
ax.errorbar(d*100,F,yerr=np.sqrt(np.maximum(0,np.diag(VF))),fmt='D',ms=4,mfc='white',color='#8651a6',capsize=2)
ax.axhline(1,color='#888888',lw=1);ax.grid(alpha=.15);ax.set(xlabel='Rail gap d (cm)',ylabel='Rigid-post scenario / aligned prediction',xlim=(0,88))
ax.set_title('Geometry response without the unsupported base-pitch assumption',fontsize=13,pad=16)
fig.text(.10,.125,'Height mismatch 5 mm; source and detector yaw -5 / +5 deg about vertical; zero added axial displacement.',fontsize=8.1)
fig.text(.10,.070,'Paired complete-batch MC standard errors. No statement of actual apparatus alignment is inferred.',fontsize=8.1)
fig.savefig(OUT/'rigid_geometry_response.png',dpi=200);fig.savefig(OUT/'rigid_geometry_response.pdf');plt.close(fig)

baseline_z=(pm[:M]-p0)/np.sqrt(np.diag(VP)[:M]+sp0**2)
summary=dict(plan=plan,source=v['source'],raw_observations=len(v['raw']),distances=M,independent_batches=R,
 original_source_events=sum(json.loads(p.read_text())['source_events'] for p in metas),stage_replays=R*2*M*6*plan['replay_population'],
 normalization=float(sel['A']),normalization_all_repeats=float(all_data['A']),normalization_refitted_to_current_geometry=False,
 normalization_definition='One Task16 normalization calibrated to aligned nominal model, shared unchanged with every geometry control; no geometry fitted.',
 metrology=dict(rail_standard_uncertainty_mm=1000*v['sd'],shared_offset_standard_uncertainty_mm=1000*v['soff'],combined_distance_standard_uncertainty_mm=1000*np.hypot(v['sd'],v['soff'])),
 baseline_validation_max_abs_scaled_difference=float(max(abs(baseline_z))),baseline_validation_scaled_differences=baseline_z.tolist(),
 geometry_factor_relative_se_range=[float(min(np.sqrt(np.diag(VF))/F)),float(max(np.sqrt(np.diag(VF))/F))],
 prediction_relative_MC_se_range=[float(min(u_se/u_pred)),float(max(u_se/u_pred))],
 jackknife_to_delta_se_range=[float(min(np.sqrt(np.diag(Vjack))/np.sqrt(np.diag(VF)))),float(max(np.sqrt(np.diag(Vjack))/np.sqrt(np.diag(VF))))],
 descriptive_log_ratio_RMS=dict(aligned_all=float(np.sqrt(np.mean(np.log(sel['ratio'])**2))),rigid_all=float(np.sqrt(np.mean(np.log(ratio)**2))),aligned_near=float(np.sqrt(np.mean(np.log(sel['ratio'][d<=.1])**2))),rigid_near=float(np.sqrt(np.mean(np.log(ratio[d<=.1])**2)))),
 selected_rows=[q for q in rows if q['d_m'] in [.01,.025,.05,.1,.3,.5,.85]],
 limitations=['Rigid mounting constrains the assumed kinematics; unmeasured steel posts/rail are not introduced as scattering volumes.','5mm centre-height and +/-5deg yaw are illustrative sensitivity inputs, not apparatus measurements or a model uncertainty prior.','Source active-layer absorption, actual source assembly and detector entrance/threshold response remain uncalibrated.','The lab manual p7-8 specifies black tape over detector windows, a metal case and ceramic support, and instrument-dependent electronic thresholds. These are not established by the present bare-Si 10keV scoring assumption.','Primary closest-three selection remains user-specified. Full repeats with Birge scatter are a descriptive sensitivity check; no formal goodness-of-fit p-value.','Probability ratios use means of independent complete-batch vectors. Their full covariance, and leave-one-batch-out SE diagnostics, are retained.'])
(OUT/'analysis_summary.json').write_text(json.dumps(summary,indent=2)+'\n')
notes='''# 按刚性支架重新模拟：32距离

新装置照片显示源和探测器由圆杆、套筒和锁紧螺钉支承。照片不支持此前“绕底部水平轴向外倒3°、50 mm转轴臂”的几何情景。本轮完全去掉该转轴臂和额外5.2 mm轴向间距，旧情景只保留为归档灵敏度测试。

## 本轮实际计算

全部32个距离均有新的Geant4计算，含理想对准和刚性支架对照两组，每组12个完整独立批次。每批200,000个原始源事件，源库在64个情景-距离组合之间共享；总新增2,400,000个原始源事件与23,040,000个分阶段重放事件。每个原始事件及其全部后代一起追踪，最终Si总沉积≥10 keV记一次。所有批次、零值和高权重结果均保留。

轨道为Z轴，竖直杆为Y轴。对照源/探测器中心高差5 mm；源与探测器分别绕竖直轴旋转-5°、+5°，轴向中心间距始终为d+16 mm。转轴用敏感区中心所在竖直线近似，未引入无实测依据的额外偏心力臂。5 mm与5°均非实测、非拟合参数。

计算在源坐标系完成，把探测器位置及朝向变换到该坐标系，源封装保持完整。均匀空气中的这种坐标变换等价于旋转源。刚性支架只约束运动学；没有在不知材料和尺寸的情况下把实际杆/轨道添加为散射体。

紫点为原理想模型概率乘以本轮配对Geant4概率比，每个距离均有实际对照，未插值生成点。采用完整独立批次向量协方差传播配对概率比误差，逐批留一误差另存作为诊断。原理想模型作为精度较高的共同基准，而非将两组独立MC噪声之差当作几何效应。

## 数据和不确定度

黑点仍采用用户指定最近三次数据；灰点是全部141次测量，并用每距离重复计数的Birge因子描述额外散布。16 mm由2+7+2+5 mm组成；单次±0.5 mm按独立均匀分布读数范围处理，轨道标准不确定度0.289 mm、公共偏移0.577 mm、合成距离0.645 mm。公共项保留相关性，并进入模型预测距离；它不是32个独立的2 mm误差。

使用task16重新确定的同一个整体归一化，不为刚性支架情景再次调高度，不拟合角度或错位。上图所有数据/预测统一乘名义(d+16 mm)^2，下图为实测/预测，1代表相符。主数据仍有最近三次选择偏差，模型还有未标定的源材料、入射窗和电子学响应，不报告正式p值或完整模型置信区间。

## 关键结果

'''
for q in summary['selected_rows']:
 notes+=f"- d={q['d_m']*100:g} cm：刚性支架/理想概率比 {q['rigid_geometry_factor']:.3f} ± {q['geometry_factor_se']:.3f}；实测/理想 {q['selected_over_aligned']:.3f}；实测/刚性支架情景 {q['selected_over_rigid']:.3f} ± {q['selected_over_rigid_se']:.3f}。\n"
near=rows[0]
notes+=f'''
## 本轮可以得出的结论

在最近的d=1 cm处，这组未标定高差/方位角使预测降低约{100*(1-near['rigid_geometry_factor']):.1f}%；实际计数仍只有对照预测的{near['selected_over_rigid']:.3f} ± {near['selected_over_rigid_se']:.3f}。因此，这一具体几何情景不足以单独解释近端偏差。不能继续把此前额外5.2 mm间距带来的吻合当作装置证据，也不能据此排除所有其他真实几何误差。

新理想对准重跑与原理想模型在32点的最大标准化差为{summary['baseline_validation_max_abs_scaled_difference']:.2f}，未发现明显程序改动造成的系统偏移。几何概率比的逐批留一与线性传播标准误比范围为{summary['jackknife_to_delta_se_range'][0]:.3f}–{summary['jackknife_to_delta_se_range'][1]:.3f}。完整紫色预测的相对MC标准误为{100*summary['prediction_relative_MC_se_range'][0]:.1f}%–{100*summary['prediction_relative_MC_se_range'][1]:.1f}%；远端若干点仍约10%，不应给相邻模拟点的起伏逐一赋予物理原因，也不能声称精确测定了远端的小角度效应。

几何改变后，全部距离的描述性对数比值均方根仅从{summary['descriptive_log_ratio_RMS']['aligned_all']:.3f}变为{summary['descriptive_log_ratio_RMS']['rigid_all']:.3f}；这是描述指标，不是显著性检验。固定共同归一化是为了比较这一几何变化的效果，未把新的几何情景拟合为最佳模型。
'''
notes+='''
## 已知但未标定的仪器响应

[实验讲义第7–8页](</Users/chenqiyue/Documents/2025-/Imperial College/Physics/Yr2 Lab/1_Radioactivity/RadioactivityScript-2026v1.pdf>)明确说明：硅片装在金属壳及陶瓷支撑内，窗口覆盖黑胶带；计数来自电子学脉冲越过阈值，且不同探测器增益和阈值存在差异。目前模型没有实测胶带材料/厚度、探测器入口层和阈值标定，裸Si沉积10 keV只是模拟计数定义。它们是需要约束的响应因素，但本轮不把它们直接断言为偏差原因，也不擅自指定厚度来拟合数据。

解释剩余偏差时，先区分几何对照是否足够解释，以及完整仪器响应是否已被测量。图中误差不是包含所有未知仪器参数的完整预测区间。此前不受照片支持的底部倾转情景，即使与近端数据吻合，也不能作为实际装置的解释。
'''
(OUT/'analysis_zh.md').write_text(notes)
print(json.dumps({k:v for k,v in summary.items() if k not in ['source','plan','selected_rows','baseline_validation_scaled_differences']},indent=2))
