#define RIGID_MOUNT 1
#include "../alignment_refinement/geant_alignment.cc"
