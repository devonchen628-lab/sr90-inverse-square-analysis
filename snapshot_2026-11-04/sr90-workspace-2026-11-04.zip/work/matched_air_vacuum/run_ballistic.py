from pathlib import Path
import os,json,sys,csv,time,hashlib,subprocess,concurrent.futures
ROOT=Path('/Users/chenqiyue/Documents/Codex/2026-10-29/r');W=ROOT/'work/matched_air_vacuum';OUT=ROOT/'outputs/task16_air_correction';B=W/'ballistic_build/task16_ballistic';BASE=Path('/Users/chenqiyue/Documents/Codex/2026-10-12/https-chatgpt-com-share-6acd35f5-5168');SPEC=BASE/'outputs/task16_geant4/inputs/spectra_unique.csv';G=BASE/'.runtime/geant4/share/Geant4/data'
env=os.environ.copy()
for k,n in [('G4LEDATA','EMLOW'),('G4LEVELGAMMADATA','PhotonEvaporation'),('G4RADIOACTIVEDATA','RadioactiveDecay'),('G4ENSDFSTATEDATA','ENSDFSTATE')]:env[k]=str(next(G.glob(n+'*')))
d=[.01,.025,.05,.075,.1,.3,.5,.85];n=1000000;R=12
plan=dict(geometry='same G2 source and detector solids: offset21mm, x1mm y3mm, detector/source recess3/6mm, aperture11mm, emitter22mm',distances_m=d,nsource=n,independent_batches=R,medium='G4_Galactic everywhere except same solid materials',baseline_air='work/offset21_shift31/production',source_sha256=hashlib.sha256((W/'ballistic_src/ballistic.cc').read_bytes()).hexdigest(),binary_sha256=hashlib.sha256(B.read_bytes()).hexdigest(),seed=1720000000,prefilter='Geant4 source exit; all rays intersecting the 30x30mm detector frame volume or active Si, and all backward rays, receive full transport; other forward rays cannot reach either in vacuum')
(OUT/'vacuum_ballistic_plan.json').write_text(json.dumps(plan,indent=2))
def run(i):
 dr=W/'ballistic';dr.mkdir(exist_ok=True);f=dr/f'batch_{i:02d}.csv';meta=f.with_suffix('.json');seed=plan['seed']+i*100003
 cmd=[str(B),str(SPEC),str(f),','.join(map(str,d)),str(n),str(seed),'1']
 if meta.exists():assert json.loads(meta.read_text())['command']==cmd;return
 start=time.time()
 with f.with_suffix('.log').open('w') as log:subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
 rows=list(csv.DictReader(f.open()));assert len(rows)==48
 log=f.with_suffix('.log').read_text();assert not any(x in log for x in ('G4Exception','Overlap is detected','Fatal','ERROR'))
 meta.write_text(json.dumps(dict(command=cmd,seed=seed,elapsed_s=time.time()-start,binary_sha256=plan['binary_sha256']),indent=2));print('Vacuum batch',i+1,'/',R,'seconds',round(time.time()-start),flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:list(pool.map(run,range(R)))
