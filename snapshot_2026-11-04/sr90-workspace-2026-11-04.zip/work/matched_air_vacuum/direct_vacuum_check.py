from pathlib import Path
import os,csv,json,subprocess,concurrent.futures
import numpy as np
W=Path('/Users/chenqiyue/Documents/Codex/2026-10-29/r/work/matched_air_vacuum');ROOT=W.parents[1];BASE=Path('/Users/chenqiyue/Documents/Codex/2026-10-12/https-chatgpt-com-share-6acd35f5-5168');B=W/'build/task16_sensitivity.app/Contents/MacOS/task16_sensitivity';SPEC=BASE/'outputs/task16_geant4/inputs/spectra_unique.csv';G=BASE/'.runtime/geant4/share/Geant4/data';env=os.environ.copy()
for k,n in [('G4LEDATA','EMLOW'),('G4LEVELGAMMADATA','PhotonEvaporation'),('G4RADIOACTIVEDATA','RadioactiveDecay'),('G4ENSDFSTATEDATA','ENSDFSTATE')]:env[k]=str(next(G.glob(n+'*')))
def run(i):
 dr=W/'direct';dr.mkdir(exist_ok=True);f=dr/f'direct_{i}.csv';cmd=[str(B),str(SPEC),str(f),'.1','200000','1000',str(1760000000+i*100003),'11','5.5','direct','10','10','21','3','1']
 with f.with_suffix('.log').open('w') as log:subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
 row=next(q for q in csv.DictReader(f.open()) if float(q['threshold_keV'])==10);return float(row['probability']),float(row['direct_se'])
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as ex:v=list(ex.map(run,range(2)))
s=json.loads((ROOT/'outputs/task16_air_correction/summary.json').read_text());p0=next(q for q in s['knots'] if q['d_cm']==10);p=np.mean([x[0] for x in v]);se=np.hypot(v[0][1],v[1][1])/2;z=(p-p0['vacuum_probability'])/np.hypot(se,p0['vacuum_MC_se']);out=dict(distance_cm=10,direct_probability=p,direct_se=se,ballistic_probability=p0['vacuum_probability'],ballistic_se=p0['vacuum_MC_se'],difference_combined_se=z)
(ROOT/'outputs/task16_air_correction/direct_validation.json').write_text(json.dumps(out,indent=2));print(json.dumps(out))
