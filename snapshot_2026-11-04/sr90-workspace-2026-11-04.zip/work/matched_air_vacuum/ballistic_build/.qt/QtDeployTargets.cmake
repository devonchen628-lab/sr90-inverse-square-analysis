set(__QT_DEPLOY_TARGETS "task16_ballistic")
set(__QT_DEPLOY_TARGET_task16_ballistic_FILE /Users/chenqiyue/Documents/Codex/2026-10-29/r/work/matched_air_vacuum/ballistic_build/task16_ballistic)
set(__QT_DEPLOY_TARGET_task16_ballistic_TYPE EXECUTABLE)
