from pathlib import Path
import os,sys,json,csv
import numpy as np
ROOT=Path('/Users/chenqiyue/Documents/Codex/2026-10-29/r');OUT=ROOT/'outputs/task16_air_correction';W=ROOT/'work/matched_air_vacuum';air=ROOT/'work/offset21_shift31/production';vac=W/'ballistic'
sys.path.insert(0,str(ROOT/'work/rigid_mount_resimulation'));from task16_inputs import load
v=load(); d=v['d'];cc=v['all']['net'];vy=v['all']['Vy'];sd=v['sd'];r=d+.021;u=cc*r*r;serr=np.sqrt((u*np.sqrt(np.diag(vy)))**2+(2*r*cc*sd)**2)
knots=np.array([.01,.025,.05,.075,.1,.3,.5,.85]);K=len(knots)
def batches(folder):
 files=sorted(folder.glob('batch_[0-9][0-9].json')); assert len(files)==(8 if folder==air else 12), (folder,len(files)); vec=[]
 for f in files:
  with f.with_suffix('.csv').open() as fp:rows=list(csv.DictReader(fp))
  row=[float(next(x['probability'] for x in rows if abs(float(x['distance_m'])-q)<1e-10 and float(x['threshold_keV'])==10)) for q in knots];assert min(row)>=0;vec.append(row)
 return np.array(vec)
a=batches(air);b=batches(vac);pa=a.mean(0);pv=b.mean(0);T=pa/pv
# Shared source histories within each run correlate distances. Resample whole independent runs.
rng=np.random.default_rng(251102);N=10000;ia=rng.integers(0,len(a),(N,len(a)));ib=rng.integers(0,len(b),(N,len(b)));abr=a[ia].mean(axis=1);vbr=b[ib].mean(axis=1);tb=abr/vbr
if not np.all(tb>0):raise ValueError('Non-positive bootstrap probability')
def interp(t):return np.exp(np.interp(np.log(d),np.log(knots),np.log(t)))
tall=interp(T);draw=np.stack([interp(z) for z in tb]);u4=u/tall
# Monte Carlo error, plus characterized experimental errors; fixed material/geometry and interpolation assumptions.
tse=np.std(draw,axis=0,ddof=1);u4err=np.sqrt((serr/tall)**2+(u4*tse/tall)**2)
np.savez_compressed(OUT/'mc_correction_covariance.npz',distances_m=d,log_correction_covariance=np.cov(-np.log(draw),rowvar=False,ddof=1))
kte=np.std(tb,axis=0,ddof=1);ratio_draw=tb[:,-1]/tb[:,5];rel=T[-1]/T[5]
rows=[]
for i,x in enumerate(d):rows.append(dict(d_cm=x*100,active_distance_cm=r[i]*100,raw_rate_cps=v['all']['C'][i],background_deadtime_corrected_rate_cps=cc[i],step3_u=u[i],step3_conditional_se=serr[i],air_vacuum_T=tall[i],T_MC_bootstrap_se=tse[i],vacuum_equivalent_rate_cps=cc[i]/tall[i],vacuum_equivalent_rate_conditional_se=(cc[i]/tall[i])*np.sqrt(vy[i,i]+(tse[i]/tall[i])**2),vacuum_equivalent_u=u4[i],vacuum_equivalent_conditional_se=u4err[i],actual_geant_knot=any(np.isclose(knots,x))))
with (OUT/'air_correction_32.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
kn=[]
for i,x in enumerate(knots):kn.append(dict(d_cm=x*100,air_probability=pa[i],air_MC_se=np.std(a,axis=0,ddof=1)[i]/np.sqrt(8),vacuum_probability=pv[i],vacuum_MC_se=np.std(b,axis=0,ddof=1)[i]/np.sqrt(len(b)),air_over_vacuum=T[i],air_over_vacuum_MC_se=kte[i]))
with (OUT/'geant_air_vacuum_8points.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(kn[0]));w.writeheader();w.writerows(kn)
summary={'air_probability_definition':'probability per emitted beta (air), including energy deposition threshold, finite geometry and source encapsulation','vacuum_counterfactual':'same model and solids, G4_Galactic instead of G4_AIR in all free space; full Geant4 tracking for all source-exit rays intersecting detector housing or Si and all backward rays','fixed_offset_mm':21,'detector_offset_mm':[1,3],'source_detector_recess_mm':[6,3],'threshold_keV':10,'air_source_histories_per_batch':400000,'vacuum_source_histories_per_batch':1000000,'air_batches':8,'vacuum_batches':12,'bootstrap_method':'10000 resamples of whole independent runs per medium; preserves cross-distance dependence, treats air and vacuum as independent','interpolation':'piecewise linear in log T against log recorded rail d across 8 Geant4 knots; 24 points interpolated; bootstrap conditional on interpolation, no interpolation model error','data':'Task16 all 141 observations pooled at 32 distances; corrected for background and effective recovery time','T_at_30cm':float(T[5]),'T_at_85cm':float(T[7]),'T85_div_T30':float(rel),'T85_div_T30_bootstrap_se':float(np.std(ratio_draw,ddof=1)),'step3_u_at_85cm':float(u[-1]),'corrected_u_at_85cm':float(u4[-1]),'fixed_models_caveat':'Does not include common geometry, energy threshold, source materials or detector response and interpolation systematics; alpha is net transport response not purely absorption','knots':kn}
(OUT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
os.environ.setdefault('MPLCONFIGDIR','/private/tmp/radio-mpl');import matplotlib;matplotlib.use('Agg');import matplotlib.pyplot as plt
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10.5,'axes.titlesize':12,'axes.labelsize':10.5,'axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'none'})
fig,(ax,bx)=plt.subplots(2,1,figsize=(9,8.1),gridspec_kw={'height_ratios':[1,1.3]},sharex=True,layout='constrained')
ax.axhline(1,ls='--',lw=1,color='#707d85');ax.plot(d*100,tall,color='#936629',lw=1.2,label='Interpolation between simulated distances');ax.errorbar(knots*100,T,yerr=kte,fmt='o',capsize=2.5,ms=4.5,color='#936629',label='Geant4: air / vacuum');ax.fill_between(d*100,tall-tse,tall+tse,color='#e3cda4',alpha=.35,label='Conditional MC ±1σ');ax.set_ylabel('Air / vacuum probability');ax.legend(frameon=False,fontsize=9);ax.grid(alpha=.18)
bx.errorbar(d*100,u,yerr=serr,fmt='o',ms=3.5,color='#287259',alpha=.75,capsize=1,label=r'Before air correction: $C_{\rm corr}r^2$');bx.errorbar(d*100,u4,yerr=u4err,fmt='s',ms=3.5,mfc='white',color='#b35331',capsize=1.5,label=r'After air correction: $C_{\rm corr}r^2 / T$');bx.set_xscale('log');bx.set_xlim(.8,100);bx.set_xticks([1,2.5,5,10,20,30,50,85],labels=['1','2.5','5','10','20','30','50','85']);bx.set(xlabel='Recorded rail distance $d$ (cm; log scale)',ylabel=r'Rate $\times$ active-plane distance$^2$ (m$^2$ s$^{-1}$)');bx.grid(alpha=.18);bx.legend(frameon=False,fontsize=9)
fig.suptitle('Estimated air-transport correction from matched Geant4 models',fontsize=15,fontweight='bold');
for ext in ('png','svg'):fig.savefig(OUT/f'air_correction.{ext}',dpi=200,bbox_inches='tight')
plt.close(fig)
raw=v['all']['C']; u1=raw*d*d; u2=cc*d*d; se1=np.sqrt((d*d*v['all']['birge']*np.sqrt(v['all']['N'])/v['all']['T'])**2+(2*d*raw*sd)**2);se2=np.sqrt((u2*np.sqrt(np.diag(vy)))**2+(2*d*cc*sd)**2);reference=u1[np.where(np.isclose(d,.3))[0][0]]
fig,axs=plt.subplots(1,4,figsize=(19,5),sharex=True,sharey=True,layout='constrained')
seq=[(u1,se1,'#215c82','1  Original',r'$C_{\rm raw}d^2$'),(u2,se2,'#be632f','2  Count-rate correction',r'$C_{\rm corr}d^2$'),(u,serr,'#327664','3  Distance correction',r'$C_{\rm corr}r^2$'),(u4,u4err,'#873c70','4  Estimated air correction',r'$C_{\rm corr}r^2/T$')]
max_y=max(23,1.07*max(u4+u4err))
for ax,(yy,ee,col,title,formula) in zip(axs,seq):
 ax.errorbar(d*100,yy,yerr=ee,fmt='o',color=col,ms=3.5,capsize=1.5,elinewidth=.7);ax.axhline(reference,ls='--',color='#84909a',lw=.8);ax.set_xscale('log');ax.set_xlim(.8,100);ax.set_ylim(0,max_y);ax.set_xticks([1,2.5,5,10,20,50,85],labels=['1','2.5','5','10','20','50','85']);ax.set_title(title,loc='left',fontweight='bold');ax.text(.02,.97,formula,transform=ax.transAxes,va='top');ax.set_xlabel('Rail distance d (cm; log scale)');ax.grid(alpha=.16)
axs[0].set_ylabel(r'Rate $\times$ distance$^2$ (m$^2$ s$^{-1}$)');fig.suptitle('Four stages of the experimental data analysis',fontsize=16,fontweight='bold');fig.text(.01,-.02,'Stage 4 uses a matched-model air/vacuum ratio, interpolated between 8 simulated distances; errors exclude geometry and interpolation systematics.',fontsize=9)
for ext in ('png','svg'):fig.savefig(OUT/f'four_steps_comparison.{ext}',dpi=200,bbox_inches='tight')
plt.close(fig)
print(json.dumps(summary,indent=2))
