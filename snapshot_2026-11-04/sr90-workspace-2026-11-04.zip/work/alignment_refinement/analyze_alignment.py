"""Task16 alignment review: real paired Geant4 controls, correlated metrology.

No unmeasured alignment is fitted to data, and no interpolated point is
presented as a Geant4 result. The selected-three view is retained as primary;
all observations provide an independent processing-sensitivity view.
"""
from pathlib import Path
import csv,json,math,hashlib,sys
import numpy as np
from scipy.interpolate import PchipInterpolator

ROOT=Path('/Users/chenqiyue/Documents/Codex/2026-10-29/r')
WORK=Path(__file__).resolve().parent
BASE=Path('/Users/chenqiyue/Documents/Codex/2026-10-12/https-chatgpt-com-share-6acd35f5-5168/outputs/task16_geant4')
OUT=ROOT/'outputs/task16_alignment_refinement';OUT.mkdir(parents=True,exist_ok=True)
def read(p):return list(csv.DictReader(p.open(encoding='utf-8-sig')))
def write(name,rows):
 with (OUT/name).open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

fit=json.loads((BASE/'results/book2_dense_comparison/fit_summary.json').read_text())
tau=fit['effective_recovery_us']*1e-6;stau=fit['recovery_fit_only_se_us']*1e-6
B=fit['background_rate'];sB=fit['background_rate_se']
oldA=next(q['normalization'] for q in fit['reports'] if q['threshold_keV']==10)
source=json.loads((ROOT/'outputs/task16_closest_three/processing_details.json').read_text())
selected=read(ROOT/'outputs/task16_closest_three/task16_selected_three.csv')
raw=read(ROOT/'outputs/task16_closest_three/task16_all_measurements.csv')
d=np.array([float(q['d_m']) for q in selected]);r0=d+.016
air=[q for q in read(BASE/'results/book2_dense_comparison/mc_summary_32_distances.csv') if float(q['threshold_keV'])==10]
assert np.array_equal(d,[float(q['distance_m']) for q in air])
p0=np.array([float(q['probability']) for q in air]);sp0=np.array([float(q['se']) for q in air])
Vmc=np.diag((sp0/p0)**2)
g0=PchipInterpolator(np.log(r0),np.log(p0)).derivative()(np.log(r0))/r0
# Each +/-0.5mm is a bound (half a scale division), not 1 sigma.
sd=.0005/np.sqrt(3);soff=np.sqrt(4)*sd
Vdistance=np.diag((g0*sd)**2)+np.outer(g0*soff,g0*soff)

def dataset(use_all):
 N=[];T=[];birges=[]
 for i,x in enumerate(d):
  rr=[q for q in raw if float(q['d_m'])==x]
  if use_all:
   n=sum(float(q['counts']) for q in rr);t=sum(float(q['time_s']) for q in rr)
  else:n=float(selected[i]['counts_total']);t=float(selected[i]['time_total_s'])
  fullrate=sum(float(q['counts']) for q in rr)/sum(float(q['time_s']) for q in rr)
  Q=sum((float(q['counts'])-fullrate*float(q['time_s']))**2/(fullrate*float(q['time_s'])) for q in rr)
  birges.append(max(1.,np.sqrt(Q/(len(rr)-1))))
  N.append(n);T.append(t)
 N=np.array(N);T=np.array(T);C=N/T;sC=np.sqrt(N)/T
 # For the all-observations sensitivity analysis only, acknowledge observed
 # overdispersion with a per-distance Birge factor. This is descriptive,
 # not a complete random-effects model or a correction for selection bias.
 if use_all:sC*=np.array(birges)
 net=C/(1-tau*C)-B/(1-tau*B)
 vC=(sC/(1-tau*C)**2/net)**2
 b=-sB/(1-tau*B)**2/net
 t=stau*(C*C/(1-tau*C)**2-B*B/(1-tau*B)**2)/net
 Vy=np.diag(vC)+np.outer(b,b)+np.outer(t,t)
 V=Vy+Vmc+Vdistance
 w=np.linalg.solve(V,np.ones(len(d)));w/=w.sum()
 logA=float(w@(np.log(net)-np.log(p0)));A=np.exp(logA)
 H=np.eye(len(d))-np.outer(np.ones(len(d)),w)
 ratio=net/(A*p0);Vr=H@V@H.T
 u=net*r0*r0
 Vu=Vy*np.outer(u,u)+np.diag((2*r0*net*sd)**2)+np.outer(2*r0*net*soff,2*r0*net*soff)
 return dict(N=N,T=T,C=C,net=net,Vy=Vy,V=V,w=w,A=A,ratio=ratio,Vratio=Vr,u=u,Vu=Vu,birge=np.array(birges),slogA=np.sqrt(w@V@w))

sel=dataset(False);all_data=dataset(True)
if '--baseline-only' in sys.argv:
 print(json.dumps(dict(previous_normalization=oldA,selected_normalization=float(sel['A']),all_normalization=float(all_data['A']),
  rail_standard_uncertainty_mm=sd*1000,common_offset_standard_uncertainty_mm=soff*1000,
  maximum_full_mean_change=float(np.max(np.abs(all_data['net']/sel['net']-1))),
  first_selected_u=float(sel['u'][0]),first_selected_u_se=float(np.sqrt(sel['Vu'][0,0]))),indent=2))
 sys.exit(0)
metas=sorted((WORK/'controls').glob('batch_[0-9][0-9].json'))
assert len(metas)==8,'Wait until all fixed Geant4 batches complete.'
plan=json.loads((WORK/'controls/plan.json').read_text())
ad=np.array(plan['distances_m']);scenarios=plan['scenarios'];R=len(metas)
indices=np.array([int(np.where(np.isclose(d,x))[0][0]) for x in ad])
rep=[];runrows=[];geometry={};seeds=[]
for path in metas:
 m=json.loads(path.read_text());seeds.append(m['seed'])
 assert m['binary_sha256']==plan['binary_sha256'] and m['spectrum_sha256']==plan['spectrum_sha256']
 rows=[q for q in read(path.with_suffix('.csv')) if float(q['threshold_keV'])==10]
 assert len(rows)==len(ad)*len(scenarios)
 vals=[]
 for scenario in scenarios:
  for x in ad:
   q=next(v for v in rows if v['scenario']==scenario and float(v['distance_m'])==x)
   vals.append(float(q['probability']));geometry[(scenario,x)]=q
   runrows.append(dict(scenario=scenario,d_m=x,replicate=m['replicate'],seed=m['seed'],probability=float(q['probability']),source_events=m['source_events'],replay_population=m['npop'],metadata=str(path)))
 rep.append(vals)
assert len(set(seeds))==R
rep=np.array(rep);M=len(ad);pm=rep.mean(axis=0);VP=np.cov(rep,rowvar=False,ddof=1)/R
assert np.all(pm>0)
control=[];ratios=[];VF=[];details=[]
for k,scenario in enumerate(scenarios):
 js=np.arange(k*M,(k+1)*M)
 F=pm[js]/pm[:M]
 J=np.zeros((M,len(pm)))
 for j in range(M):
  J[j,js[j]]+=1/pm[j];J[j,j]-=pm[js[j]]/pm[j]**2
 covF=J@VP@J.T
 # Leave-one-batch-out ratios diagnose finite-batch delta-method uncertainty.
 leave=np.array([np.delete(rep,b,axis=0).mean(axis=0) for b in range(R)])
 jack=leave[:,js]/leave[:,:M]
 Vjack=(R-1)/R*((jack-jack.mean(axis=0)).T@(jack-jack.mean(axis=0)))
 gF=PchipInterpolator(np.log(ad+.016),np.log(F)).derivative()(np.log(ad+.016))/(ad+.016)
 pred=p0[indices]*F
 Vpred=covF*np.outer(p0[indices],p0[indices])+np.diag((F*sp0[indices])**2)
 # Both the calibrated normalization and all raw measurement covariance are
 # carried into the data/model ratio. Common-offset error moves prediction
 # distances too, rather than merely enlarging the plotted y error bars.
 S=np.eye(len(d))[indices];H=S-np.outer(np.ones(M),sel['w'])
 D=np.outer(np.ones(M),sel['w']*g0)
 for j,i in enumerate(indices):D[j,i]-=g0[i]+gF[j]
 VR=H@(sel['Vy']+Vmc)@H.T+covF/np.outer(F,F)
 VR+=D@np.diag(np.full(len(d),sd*sd))@D.T+np.outer(D@np.ones(len(d))*soff,D@np.ones(len(d))*soff)
 dr=sel['net'][indices]/(sel['A']*pred)
 for j,x in enumerate(ad):
  geom=geometry[(scenario,x)]
  control.append(dict(scenario=scenario,d_m=x,nominal_r_m=x+.016,
   direct_control_probability=pm[js[j]],direct_control_se=np.sqrt(VP[js[j],js[j]]),
   geometry_factor=F[j],geometry_factor_se=np.sqrt(max(0,covF[j,j])),geometry_factor_jackknife_se=np.sqrt(max(0,Vjack[j,j])),
   corrected_probability=pred[j],corrected_probability_se=np.sqrt(max(0,Vpred[j,j])),
   predicted_u=sel['A']*pred[j]*(x+.016)**2,predicted_u_MC_se=sel['A']*np.sqrt(max(0,Vpred[j,j]))*(x+.016)**2,
   data_model_ratio=dr[j],data_model_ratio_se=dr[j]*np.sqrt(max(0,VR[j,j])),
   h_mm=float(geom['h_mm']),source_tilt_deg=float(geom['source_tilt_deg']),detector_tilt_deg=float(geom['detector_tilt_deg']),pivot_arm_mm=float(geom['pivot_arm_mm']),
   local_front_z_mm=float(geom['local_front_z_mm'])))
 ratios.append(dr);VF.append(covF)
 details.append(dict(scenario=scenario,unweighted_log_ratio_RMS=float(np.sqrt(np.mean(np.log(dr)**2))),
  near_log_ratio_RMS=float(np.sqrt(np.mean(np.log(dr[ad<=.1])**2))),geometry_factor_min=float(F.min()),geometry_factor_max=float(F.max()),
  max_jackknife_to_delta_se=float(np.max(np.sqrt(np.maximum(0,np.diag(Vjack)))/np.maximum(1e-15,np.sqrt(np.maximum(0,np.diag(covF))))))))

write('geant4_alignment_controls.csv',control);write('independent_control_batches.csv',runrows)
pointrows=[]
for i,x in enumerate(d):
 pointrows.append(dict(d_m=x,nominal_r_m=r0[i],selected_counts=sel['N'][i],selected_time_s=sel['T'][i],
  selected_corrected_rate=sel['net'][i],selected_corrected_u=sel['u'][i],selected_u_se=np.sqrt(sel['Vu'][i,i]),
  all_corrected_u=all_data['u'][i],all_u_se_overdispersion=np.sqrt(all_data['Vu'][i,i]),all_Birge_factor=all_data['birge'][i],
  nominal_probability=p0[i],nominal_probability_se=sp0[i],normalization_task16=sel['A'],
  nominal_predicted_u=sel['A']*p0[i]*r0[i]**2,nominal_predicted_u_MC_se=sel['A']*sp0[i]*r0[i]**2,
  selected_data_model_ratio=sel['ratio'][i],selected_ratio_se=sel['ratio'][i]*np.sqrt(max(0,sel['Vratio'][i,i])),
  all_data_model_ratio=all_data['ratio'][i]))
write('comparison_32_distances.csv',pointrows)
np.savez_compressed(OUT/'covariances.npz',distance_m=d,selected_u_covariance=sel['Vu'],baseline_ratio_log_covariance=sel['Vratio'],control_probability_covariance=VP,geometry_factor_covariances=np.array(VF),control_distances_m=ad)

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'pdf.fonttype':42})
fig,(ax,bx)=plt.subplots(2,1,figsize=(10.5,8.5),sharex=True,gridspec_kw={'height_ratios':[1.2,1]})
fig.subplots_adjust(left=.10,right=.98,top=.875,bottom=.19,hspace=.14)
ax.errorbar(d*100,all_data['u'],yerr=np.sqrt(np.diag(all_data['Vu'])),fmt='o',mfc='none',mec='#999999',ms=6,ecolor='#cccccc',capsize=2,label='All repeats (repeat scatter included)',zorder=1)
ax.errorbar(d*100,sel['A']*p0*r0*r0,yerr=sel['A']*sp0*r0*r0,fmt='s',ms=3.5,color='#2b9348',capsize=2,label='Aligned Geant4 air: 32 distances',zorder=2)
ax.errorbar(d*100,sel['u'],yerr=np.sqrt(np.diag(sel['Vu'])),fmt='o',ms=3.8,color='#202020',capsize=2,label='Requested closest-three measurements',zorder=3)
chosen=[q for q in control if q['scenario']=='pivot3_offset5']
ax.errorbar(ad*100,[q['predicted_u'] for q in chosen],yerr=[q['predicted_u_MC_se'] for q in chosen],fmt='D',ms=6,mfc='white',color='#8651a6',capsize=3,label='Geant4 pose scenario: 6 distances',zorder=4)
ax.set_ylabel(r'$C_{\rm corrected}(d+16\,\mathrm{mm})^2$ (m$^2$ s$^{-1}$)')
ax.legend(loc='best',fontsize=8.5)
bx.errorbar(d*100,sel['ratio'],yerr=sel['ratio']*np.sqrt(np.maximum(0,np.diag(sel['Vratio']))),fmt='o',ms=3.8,color='#2b9348',capsize=2,label='Measurements / aligned model')
bx.errorbar(ad*100,[q['data_model_ratio'] for q in chosen],yerr=[q['data_model_ratio_se'] for q in chosen],fmt='D',ms=6,mfc='white',color='#8651a6',capsize=3,label='Measurements / pose scenario')
bx.axhline(1,color='#888888',lw=1);bx.set(xlabel='Rail gap d (cm)',ylabel='Measured / predicted rate',xlim=(0,88))
bx.legend(fontsize=8.5,loc='best')
for a in [ax,bx]:a.grid(alpha=.15);a.spines['right'].set_visible(False);a.spines['top'].set_visible(False)
fig.suptitle('Task16: alignment sensitivity and revised distance uncertainty',fontsize=14,y=.965)
fig.text(.5,.920,'Air transport; 10 keV threshold; one Task16 normalization shared by every scenario',ha='center',fontsize=9.5)
fig.text(.10,.130,'Pose scenario: centre offset 5 mm; source -3 deg, detector +3 deg; assumed pivot arms 50 mm.',fontsize=8.3)
fig.text(.10,.095,'Four offset readings 2 + 7 + 2 + 5 mm; standard uncertainties: rail 0.29 mm, common offset 0.58 mm.',fontsize=8.2)
fig.text(.10,.060,'Purple points: paired Geant4 geometry correction x nominal prediction; six real control distances, no interpolation.',fontsize=8.0)
fig.text(.10,.025,'Alignment values are illustrative, not measured or fitted. Error bars exclude unknown apparatus/material errors.',fontsize=8.1)
fig.savefig(OUT/'alignment_comparison.png',dpi=200);fig.savefig(OUT/'alignment_comparison.pdf');plt.close(fig)

fig,ax=plt.subplots(figsize=(9.5,5.9));fig.subplots_adjust(left=.10,right=.98,top=.86,bottom=.22)
colors=['#666666','#d58b20','#3075b5','#8651a6'];labels=['Aligned reference','Centre offset 5 mm','Source -5 deg, detector +5 deg; centres fixed','Offset 5 mm + opposite 3 deg tilt; 50 mm pivots']
for k,scenario in enumerate(scenarios):
 rr=[q for q in control if q['scenario']==scenario]
 ax.errorbar(ad*100,[q['geometry_factor'] for q in rr],yerr=[q['geometry_factor_se'] for q in rr],fmt=['o','s','^','D'][k],color=colors[k],mfc='white',ms=5,capsize=3,label=labels[k])
ax.axhline(1,color='#999999',lw=1);ax.grid(alpha=.15);ax.set(xlabel='Rail gap d (cm)',ylabel='Predicted rate / aligned prediction',xlim=(0,88));ax.legend(fontsize=8.5)
ax.set_title('What do offset, tilt and pivot motion change?',fontsize=13,pad=16)
fig.text(.10,.125,'Same source, materials, air and threshold. Paired complete Geant4 batches retain cross-scenario covariance.',fontsize=8)
fig.text(.10,.065,'Controls are sensitivity scenarios; their values and bounds are not inferred apparatus uncertainties.',fontsize=8)
fig.savefig(OUT/'geometry_controls.png',dpi=200);fig.savefig(OUT/'geometry_controls.pdf');plt.close(fig)

validation=[]
for j,x in enumerate(ad):
 i=indices[j];s=np.hypot(sp0[i],np.sqrt(VP[j,j]));validation.append(dict(d_m=x,new_aligned_probability=pm[j],existing_probability=p0[i],difference_over_combined_se=(pm[j]-p0[i])/s))
summary=dict(source_file=source['source'],source_sha256=source['source_sha256'],primary_selection=source['selection'],
 distances=32,raw_observations=len(raw),new_control_distances=ad.tolist(),control_plan=plan,
 new_original_source_events=sum(json.loads(p.read_text())['source_events'] for p in metas),
 metrology=dict(offset_mm=16,component_lengths_mm=[2,7,2,5],single_reading_half_range_mm=.5,distribution='independent rectangular readout errors; no unknown common scale-calibration error added',rail_reference='User confirmed base/carriage index, not a direct sensitive-centre distance measurement.',rail_standard_uncertainty_mm=sd*1000,common_offset_standard_uncertainty_mm=soff*1000,combined_distance_standard_uncertainty_mm=np.hypot(sd,soff)*1000),
 normalization=dict(previous_Book2=oldA,task16_selected=float(sel['A']),task16_all_with_Birge=float(all_data['A']),conditional_selected_log_se=float(sel['slogA']),fit='One GLS normalization in log corrected-rate space; common offset, independent rail readout, background, recovery and nominal MC covariance included. No alignment parameter fitted.'),
 baseline_validation=validation,scenario_diagnostics=details,
 all_repeats_sensitivity=dict(maximum_fractional_mean_change=float(np.max(np.abs(all_data['net']/sel['net']-1))),normalization_fractional_change=float(all_data['A']/sel['A']-1)),
 limitations=['Only six control distances, eight independent complete source/replay batches; conditional MC SE, not apparatus-model accuracy.','Pivot arms, centre offsets and angles are illustrative and unmeasured. Source active-layer absorption and detector entrance/electronic response remain uncalibrated.','Closest-three selection remains the requested primary view; neither it nor Birge scaling supports formal model-fit p-values.','Pose correction is estimated as paired mean probability ratio and multiplied by existing nominal probability. Ratio uncertainty uses full paired batch covariance; leave-one-out SE is retained as a diagnostic.','Top plot uses nominal (d+16mm)^2 for every hypothesis so observations are not moved to suit a scenario.','Common offset is retained as a correlated parameter in rate-space diagnostics; it is not added as 32 independent 2mm standard errors.'])
(OUT/'analysis_summary.json').write_text(json.dumps(summary,indent=2)+'\n')
near=[q for q in control if q['scenario']=='pivot3_offset5' and q['d_m']<=.1]
notes=f'''# Task16：几何对准与公共距离误差复核

本轮保持最近三次筛选为主视图，另用全部141次观测核对处理敏感性。源文件仍为 {source['source']} 的Sheet1。所有原记录保留；模拟不删除零结果、高权重批次或不利于吻合的结果。

## 改了什么

1. 16 mm由四个独立尺寸2+7+2+5 mm组成。每个±0.5 mm按均匀分布读数范围处理，得到轨道读数标准不确定度0.289 mm、公共偏移标准不确定度0.577 mm，单点合成距离标准不确定度0.645 mm。公共项通过完整协方差处理，不是给每点独立添加2 mm标准误差。
2. 用task16重新估计唯一的整体归一化：{sel['A']:.6g}；旧Book2值{oldA:.6g}，改变{100*(sel['A']/oldA-1):.2f}%。全部观测并考虑过度离散的敏感性结果为{all_data['A']:.6g}。这个参数混合源强与探测响应，不能直接当作已标定活度。
3. 实际Geant4对照：六个距离1、2.5、5、10、50、85 cm，四个预设姿态，每个八个完整独立批次。总新增真实源事件1,600,000个，另有11,520,000个分阶段重放事件；共享源库不能乘以距离或情景数作为独立源事件。每个源事件的所有子粒子一起保留。

## 四个固定情景

- aligned：理想共轴，板面垂直轨道。
- offset5：中心横向错位5 mm，板面保持平行。
- tilt5：中心固定，源板-5°、探测板+5°。
- pivot3_offset5：中心横向错位5 mm，源板-3°、探测板+3°，两者各绕距敏感区50 mm的底部支点转动。

角度、5 mm错位和50 mm转轴臂均是说明性假设，不是实测值，也没有通过数据优化。用户确认d读自底部滑块刻线，因此支架倾斜导致敏感区中心间距改变是可检验机制。50 mm实际转轴臂仍需独立测量；若某个距离校准已经包含姿态位移，则不能再重复加入对应位移。

## 图的含义与统计处理

所有观测和预测都乘同一个名义距离(d+16 mm)的平方，方便直接比较；没有随着模型情景移动黑色实验点。紫点是“同批Geant4姿态/理想计数概率比 × 原32点理想模型对应概率”，不是32个全新Geant4点。六个距离之外未插值生成新模拟点。姿态比的误差采用八个完整批次的配对协方差，另保留逐批留一法误差作诊断。

源保持自己的坐标系，将探测器位置和旋转变换到源坐标系；这在均匀空气、未加入外部轨道/桌面的模型中等价于旋转源封装。几何检查全部开启；每个情景重建几何。入射窗、活性源基质自吸收和实际电子学响应仍未校准，名义计数门槛维持Si内每原始事件总沉积能量≥10 keV。

下图改用实验/模型比值，1表示预测与观测相同，避免再次引入10 cm归一化。比值误差包含整体归一化拟合与数据的相关性、Geant4统计误差、公共偏移、独立读尺、背景及恢复时间误差。主视图仍有最近三次筛选偏差，全部观测中的Birge膨胀也只是重复性敏感性检查，不是完整层级统计模型；不报告正式p值。

## 关键数值

'''
for q in control:
 if q['scenario']=='pivot3_offset5':notes+=f"- d={100*q['d_m']:g} cm：姿态/理想概率比 {q['geometry_factor']:.3f} ± {q['geometry_factor_se']:.3f}；实验/姿态模型 {q['data_model_ratio']:.3f} ± {q['data_model_ratio_se']:.3f}。\n"
notes+='\n这些是条件统计误差，不是未知角度与装置结构的置信区间。某一姿态情景更接近实测，表示机制可能解释相应偏差，并不证明实验时恰好处于该姿态。\n'
(OUT/'analysis_zh.md').write_text(notes)
print(json.dumps({k:v for k,v in summary.items() if k in ['normalization','baseline_validation','scenario_diagnostics','all_repeats_sensitivity','metrology']},indent=2))
