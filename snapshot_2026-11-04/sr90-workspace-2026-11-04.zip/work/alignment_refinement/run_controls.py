from pathlib import Path
import concurrent.futures,csv,hashlib,json,os,subprocess,sys,time
W=Path(__file__).resolve().parent
BASE=Path('/Users/chenqiyue/Documents/Codex/2026-10-12/https-chatgpt-com-share-6acd35f5-5168/outputs/task16_geant4')
BIN=W.parent/'air_vacuum_check/vacuum_scan/build/task16_alignment';SPEC=BASE/'inputs/spectra_unique.csv'
ENV=os.environ.copy()
for key,name in [('G4LEDATA','EMLOW'),('G4LEVELGAMMADATA','PhotonEvaporation'),('G4RADIOACTIVEDATA','RadioactiveDecay'),('G4ENSDFSTATEDATA','ENSDFSTATE')]:
 ENV[key]=str(next((BASE.parents[1]/'.runtime/geant4/share/Geant4/data').glob(name+'*')))
validation='--validate' in sys.argv
OUT=W/('validation' if validation else 'controls');OUT.mkdir(parents=True,exist_ok=True)
distances=[.01,.025,.05,.1,.5,.85] if not validation else [.01,.1]
nsource=200000 if not validation else 10000
npop=10000 if not validation else 1000
BH=hashlib.sha256(BIN.read_bytes()).hexdigest();SH=hashlib.sha256(SPEC.read_bytes()).hexdigest()
plan=dict(distances_m=distances,scenarios=['aligned','offset5','tilt5','pivot3_offset5'],source_events=nsource,replay_events_per_stage=npop,independent_batches=8 if not validation else 1,binary_sha256=BH,spectrum_sha256=SH,
 assumptions='Misalignments are illustrative controls, not measured or fitted apparatus values. Source-coordinate rotation is equivalent to jointly rotating source and detector in homogeneous air. No rail, unknown detector window or source matrix is introduced.',
 shared_source_library_and_random_numbers_across_controls=True)
pf=OUT/'plan.json'
if pf.exists():assert json.loads(pf.read_text())==plan
else:pf.write_text(json.dumps(plan,indent=2)+'\n')
def run(rep):
 seed=1773000000+rep*100003;target=OUT/f'batch_{rep:02d}.csv';meta=target.with_suffix('.json')
 cmd=[str(BIN),str(SPEC),str(target),','.join(map(str,distances)),str(nsource),str(npop),str(seed)]
 if meta.exists():
  m=json.loads(meta.read_text());assert m['command']==cmd and m['binary_sha256']==BH
  return
 t=time.time()
 with target.with_suffix('.log').open('w') as f:subprocess.run(cmd,env=ENV,stdout=f,stderr=subprocess.STDOUT,check=True)
 rows=list(csv.DictReader(target.open()));assert len(rows)==len(distances)*4*6
 meta.write_text(json.dumps(dict(command=cmd,replicate=rep,seed=seed,source_events=nsource,npop=npop,binary_sha256=BH,spectrum_sha256=SH,elapsed_s=time.time()-t),indent=2)+'\n')
 print(f'Complete alignment batch {rep+1}/{plan["independent_batches"]}, {time.time()-t:.1f}s',flush=True)
if __name__=='__main__':
 with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:list(pool.map(run,range(plan['independent_batches'])))
