// Geant4 air-transport alignment controls. All scenarios share a complete
// source-exit library within each independent batch; errors are estimated
// between complete batches, never from conditional replay counts alone.
#include "smc_reuse_base.cc"
#include "G4RotationMatrix.hh"

struct Alignment {
 SMC c;
 G4ThreeVector front{0,0,900*mm};
 G4RotationMatrix rotation;
};

class AlignmentGeometry:public G4VUserDetectorConstruction {
 Alignment& a;
 public:explicit AlignmentGeometry(Alignment& x):a(x){}
 G4VPhysicalVolume* Construct() override {
  auto& c=a.c;auto n=G4NistManager::Instance();
  auto air=n->FindOrBuildMaterial("G4_AIR");double W=c.world_half*m;
  auto world=new G4LogicalVolume(new G4Box("World",W,W,W),air,"World");
  auto pv=new G4PVPlacement(nullptr,{},world,"World",nullptr,false,0,true);
  auto al=n->FindOrBuildMaterial("G4_Al"),pmma=n->FindOrBuildMaterial("G4_PLEXIGLASS");
  auto box=[&](const G4String& name,double t,double z,G4Material* mat){
   auto lv=new G4LogicalVolume(new G4Box(name,25*mm,25*mm,t/2),mat,name);
   new G4PVPlacement(nullptr,{0,0,z},lv,name,world,false,0,true);
  };
  box("SourceAlFoil",.05*mm,.275*mm,al);
  box("SourceAcrylic",1*mm,.8*mm,pmma);
  auto tb=new G4Box("TopPlateBox",25*mm,25*mm,2.5*mm);
  auto hole=new G4Tubs("ExitHole",0,4.875*mm,2.6*mm,0,twopi);
  auto top=new G4LogicalVolume(new G4SubtractionSolid("TopWithHole",tb,hole),al,"SourceTopPlate");
  new G4PVPlacement(nullptr,{0,0,3.8*mm},top,"SourceTopPlate",world,false,0,true);
  box("SourceBacking",1.5*mm,-1*mm,al);
  auto mother=world;double previous=0;
  for(unsigned i=0;i<c.planes.size();++i){
   double z=c.planes[i]*m,centre=(W+z)/2;auto name="Phase_"+std::to_string(i);
   auto lv=new G4LogicalVolume(new G4Box(name,W,W,(W-z)/2),air,name);
   new G4PVPlacement(nullptr,{0,0,centre-previous},lv,name,mother,false,0,true);
   mother=lv;previous=centre;
  }
  auto si=new G4LogicalVolume(new G4Box("Silicon",5*mm,5*mm,.15*mm),n->FindOrBuildMaterial("G4_Si"),"Silicon");
  auto centre=a.front+a.rotation*G4ThreeVector(0,0,.15*mm)-G4ThreeVector(0,0,previous);
  // Transform3D specifies the active rotation of the solid, not the inverse
  // frame-rotation convention of the pointer constructor.
  new G4PVPlacement(G4Transform3D(a.rotation,centre),si,"Silicon",mother,false,0,true);
  return pv;
 }
};

double aligned_importance(const History& h,const Alignment& a){
 double score=0;const auto& c=a.c;
 for(const auto& s:h.particles){
  double L=std::max(1e-6,(a.front.z()-s.pos.z())/m);
  double dx=(a.front.x()-s.pos.x())/m,dy=(a.front.y()-s.pos.y())/m;
  double tail=.0001/(4*pi*(L*L+dx*dx+dy*dy+1e-6));
  double forward=0;
  if(s.dir.z()>.01){
   double sigma=.001;
   if(std::abs(s.pdg)==11){
    double E=s.energy/MeV,p=std::sqrt(E*(E+1.022)),beta=p/(E+.511);
    double X=std::max(1e-12,L*.12048/36.66);
    double theta=std::min(3.,13.6/std::max(.001,p*beta)*std::sqrt(X)*std::max(.1,1+.038*std::log(X)));
    sigma=std::max(.0001,L*theta/std::sqrt(3.));
   }
   double x=s.pos.x()/m+L*s.dir.x()/s.dir.z()-a.front.x()/m;
   double y=s.pos.y()/m+L*s.dir.y()/s.dir.z()-a.front.y()/m;
   double rt=std::sqrt(2.)*sigma;
   forward=.25*(std::erf((.005-x)/rt)-std::erf((-.005-x)/rt))*(std::erf((.005-y)/rt)-std::erf((-.005-y)/rt));
  }
  double response=1;
  if(s.pdg==22){double E=std::max(.001,s.energy/MeV);response=std::clamp(.0002+.5*std::pow(.02/E,3),.001,.95);}
  score+=response*std::max(tail,forward);
 }
 return std::max(1e-12,std::min(1.,score));
}

int main(int argc,char** argv){
 if(argc<7){std::cerr<<"spectrum output distances nsource npop seed [scenario_count=4]\n";return 2;}
 Alignment a;auto& c=a.c;c.nsource=std::stol(argv[4]);c.npop=std::stol(argv[5]);long seed=std::stol(argv[6]);
#ifdef RIGID_MOUNT
 int count=argc>7?std::stoi(argv[7]):2;
#else
 int count=argc>7?std::stoi(argv[7]):4;
#endif
 c.source.source_case=true;c.source.smooth_importance=true;c.source.radius_mm=11;
 c.source.position_mix=.6;c.source.y_importance_cutoff=500;c.source.sr_sampling_fraction=.5;c.source.cut_mm=.01;
 c.planes={.006301};c.r=.9;c.uniform_mix=.1;
 std::ifstream spec(argv[1]);std::string line;std::getline(spec,line);
 while(std::getline(spec,line)){std::replace(line.begin(),line.end(),',',' ');std::istringstream f(line);int b;double E,cdf;f>>b>>E>>cdf;c.source.energy[b].push_back(E);c.source.cdf[b].push_back(cdf);}
 std::vector<double> ds;std::istringstream dl(argv[3]);while(std::getline(dl,line,','))ds.push_back(std::stod(line));
 auto rm=new G4RunManager;G4Random::setTheSeed(seed);
 rm->SetUserInitialization(new AlignmentGeometry(a));rm->SetUserInitialization(new Physics(.01));
 rm->SetUserAction(new SMCGenerator(c));rm->SetUserAction(new SMCEvents(c));rm->SetUserAction(new SMCSteps(c));rm->SetUserAction(new SMCBoundaryBirths(c));
 G4EmParameters::Instance()->SetStepFunction(.1,10*um);rm->Initialize();
 c.stage=0;rm->BeamOn(c.nsource);
 auto bank=std::move(c.next);for(auto& h:bank)h.weight/=c.nsource;
 std::cout<<"SOURCE_BANK "<<bank.size()<<" original_events "<<c.nsource<<std::endl;
 std::ofstream out(argv[2]);out<<std::setprecision(15)
#ifdef RIGID_MOUNT
 <<"scenario,distance_m,threshold_keV,probability,nsource,npop,seed,h_mm,source_yaw_deg,detector_yaw_deg,pivot_arm_mm,local_front_x_mm,local_front_y_mm,local_front_z_mm\n";
 const char* names[]={"aligned","height5_yaw5"};
#else
 <<"scenario,distance_m,threshold_keV,probability,nsource,npop,seed,h_mm,source_tilt_deg,detector_tilt_deg,pivot_arm_mm,local_front_x_mm,local_front_y_mm,local_front_z_mm\n";
 const char* names[]={"aligned","offset5","tilt5","pivot3_offset5"};
#endif
 for(int k=0;k<count;++k)for(unsigned di=0;di<ds.size();++di){
#ifdef RIGID_MOUNT
  double d=ds[di],h=k==1?5:0,ts=k==1?-5:0,td=-ts,H=0;
  G4RotationMatrix rs,rd;rs.rotateY(ts*deg);rd.rotateY(td*deg);
  // Rail is Z, vertical posts are Y. Only yaw and centre-height mismatch
  // vary. The two active centres keep their nominal axial separation.
  auto src=G4ThreeVector(0,0,0);
  auto det=G4ThreeVector(0,h*mm,(d+.016)*m);
#else
  double d=ds[di],h=k==1||k==3?5:0,ts=k==2?-5:(k==3?-3:0),td=-ts,H=k==3?50:0;
  G4RotationMatrix rs,rd;rs.rotateX(ts*deg);rd.rotateX(td*deg);
  auto src=G4ThreeVector(0,H*(std::cos(ts*deg)-1)*mm,H*std::sin(ts*deg)*mm);
  auto det=G4ThreeVector(h*mm,H*(std::cos(td*deg)-1)*mm,(d+.016)*m+H*std::sin(td*deg)*mm);
#endif
  a.front=rs.inverse()*(det-src);a.rotation=rs.inverse()*rd;c.r=a.front.z()/m;
  double z=.006301,last=c.r-.003;c.planes={z};
  for(double f:{.25,.5,.75,.9})c.planes.push_back(z+f*(last-z));c.planes.push_back(last);
  c.population=bank;c.score={};c.score_square={};c.stage=1;
  // A shared random-number stream across scenarios improves paired controls;
  // different complete batches are independent. Geometry is always rebuilt.
  G4Random::setTheSeed(seed+1000000+di*10007);rm->ReinitializeGeometry(true);rm->Initialize();
  for(unsigned stage=1;stage<=c.planes.size();++stage){
   c.stage=stage;c.next.clear();if(c.population.empty())break;
   double total=0,focused=0;std::vector<double> focus;
   for(const auto& b:c.population){double v=aligned_importance(b,a);focus.push_back(v);total+=b.weight;focused+=b.weight*v;}
   c.selection.clear();c.cdf.clear();double sum=0;
   for(unsigned j=0;j<c.population.size();++j){double q=c.uniform_mix*c.population[j].weight/total+(1-c.uniform_mix)*c.population[j].weight*focus[j]/focused;c.selection.push_back(q);sum+=q;c.cdf.push_back(sum);}
   c.cdf.back()=1;rm->BeamOn(c.npop);
   if(stage<c.planes.size()){for(auto& b:c.next)b.weight/=c.npop;c.population=std::move(c.next);}
  }
  for(unsigned j=0;j<c.score.size();++j)out<<names[k]<<','<<d<<','<<c.source.thresholds[j]<<','<<c.score[j]/c.npop<<','<<c.nsource<<','<<c.npop<<','<<seed<<','<<h<<','<<ts<<','<<td<<','<<H<<','<<a.front.x()/mm<<','<<a.front.y()/mm<<','<<a.front.z()/mm<<'\n';
  out.flush();std::cout<<"DONE "<<names[k]<<" d "<<d<<" P10 "<<c.score[2]/c.npop<<std::endl;
 }
 delete rm;return 0;
}
