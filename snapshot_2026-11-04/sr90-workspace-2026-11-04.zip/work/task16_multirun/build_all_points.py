"""Plot the deduplicated Task16 master, preserving unresolved summaries."""
from pathlib import Path
import csv,hashlib,json,math,sys

ROOT=Path('/Users/chenqiyue/Documents/Codex/2026-10-29/r')
SOURCE=ROOT/'outputs/task16_all.csv'
OUT=ROOT/'outputs/task16_all_points'
def read(p):return list(csv.DictReader(p.open(encoding='utf-8-sig',newline='')))
def write(name,rr):
 with (OUT/name).open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rr[0]));w.writeheader();w.writerows(rr)

def extract():
 OUT.mkdir(parents=True,exist_ok=True)
 digest=hashlib.sha256(SOURCE.read_bytes()).hexdigest();rr=read(SOURCE)
 raw=[r for r in rr if r['record_type']=='measurement'];extra=[r for r in rr if r['record_type']=='summary_unresolved'];bg=[r for r in rr if r['record_type']=='background']
 assert (len(rr),len(raw),len(extra),len(bg))==(175,172,2,1)
 fit=json.loads(Path('/Users/chenqiyue/Documents/Codex/2026-10-12/https-chatgpt-com-share-6acd35f5-5168/outputs/task16_geant4/results/book2_dense_comparison/fit_summary.json').read_text())
 tau=fit['effective_recovery_us']*1e-6;stau=fit['recovery_fit_only_se_us']*1e-6
 BN=sum(int(r['counts']) for r in bg);BT=sum(float(r['time_s']) for r in bg);B=BN/BT;sB=math.sqrt(BN)/BT
 off=.016;soff=.0005/math.sqrt(3)*2
 def calc(d,N,T,sd,expand):
  C=N/T;sP=math.sqrt(N)/T;sC=sP*expand;r=d+off
  net=C/(1-tau*C)-B/(1-tau*B)
  stat=sC/(1-tau*C)**2;gb=-sB/(1-tau*B)**2;gt=stau*(C*C/(1-tau*C)**2-B*B/(1-tau*B)**2)
  sn=math.sqrt(stat*stat+gb*gb+gt*gt)
  return dict(d_m=d,nominal_r_m=r,counts_total=N,time_total_s=T,raw_rate_cps=C,raw_rate_poisson_se_cps=sP,
   raw_rate_scatter_adjusted_se_cps=sC,Cd2_m2_per_s=C*d*d,Cd2_se_m2_per_s=math.hypot(sC*d*d,2*C*d*sd),
   corrected_rate_cps=net,corrected_rate_se_cps=sn,corrected_u_m2_per_s=net*r*r,
   corrected_u_se_m2_per_s=math.sqrt((sn*r*r)**2+(2*net*r*sd)**2+(2*net*r*soff)**2),
   d_standard_uncertainty_m=sd,counting_u_se=stat*r*r,background_u_component=gb*r*r,recovery_u_component=gt*r*r,
   offset_u_component=2*net*r*soff,local_distance_u_se=2*net*r*sd)
 singles=[]
 for row in raw+extra:
  q=calc(float(row['d_m']),int(row['counts']),float(row['time_s']),float(row['d_standard_uncertainty_m']),1)
  singles.append(dict(record_id=row['record_id'],record_type=row['record_type'],dataset=row['dataset'],**q))
 write('task16_all_individual_plot_points.csv',singles)
 points=[]
 for d in sorted({float(r['d_m']) for r in raw}):
  obs=[r for r in raw if float(r['d_m'])==d];N=sum(int(r['counts']) for r in obs);T=sum(float(r['time_s']) for r in obs);C=N/T
  Q=sum((int(r['counts'])-C*float(r['time_s']))**2/(C*float(r['time_s'])) for r in obs)
  factor=max(1.,math.sqrt(Q/(len(obs)-1))) if len(obs)>1 else 1.
  q=calc(d,N,T,max(float(r['d_standard_uncertainty_m']) for r in obs),factor)
  points.append(dict(**q,n_measurements=len(obs),scatter_expansion_factor=factor,source_datasets=';'.join(sorted({r['dataset'] for r in obs})),record_ids=';'.join(r['record_id'] for r in obs)))
 assert len(points)==32 and sum(q['n_measurements'] for q in points)==172
 assert sum(q['counts_total'] for q in points)==sum(int(r['counts']) for r in raw)
 assert math.isclose(sum(q['time_total_s'] for q in points),sum(float(r['time_s']) for r in raw))
 write('task16_all_mean_points.csv',points)
 # Common background/recovery/offset terms stay correlated across distances.
 covariance=[]
 for a in points:
  for b in points:
   v=sum(a[k]*b[k] for k in ['background_u_component','recovery_u_component','offset_u_component'])
   if a is b:v+=a['counting_u_se']**2+a['local_distance_u_se']**2
   covariance.append(dict(d_i_m=a['d_m'],d_j_m=b['d_m'],corrected_u_covariance=v))
 write('corrected_u_covariance.csv',covariance)
 model=read(ROOT/'outputs/task16_all_datasets/geant4_reference.csv');assert len(model)==32
 write('previous_geant4_reference.csv',model)
 before={float(q['d_m']):float(q['raw_rate_cps']) for q in read(ROOT/'outputs/task16_all_datasets/all_datasets_processed.csv') if q['dataset']=='new_selected'}
 changes=[dict(d_m=q['d_m'],rate_ratio_to_previous_selected=q['raw_rate_cps']/before[q['d_m']]) for q in points]
 metadata=dict(source=str(SOURCE),source_sha256=digest,input_rows=175,pooled_measurements=172,mean_distance_points=32,
  unresolved_summaries_shown_separately=2,background_counts=BN,background_time_s=BT,background_rate_cps=B,
  offset_m=off,offset_standard_uncertainty_m=soff,effective_recovery_us=tau*1e6,
  rate_estimator='sum(counts)/sum(exposure), using all retained measurement rows; no closest-three selection.',
  uncertainty='Nominal Poisson error multiplied by max(1,sqrt(Pearson Q/(k-1))) to describe extra repeat scatter, then background/recovery/metrology propagation. This is descriptive, not a complete random-effects or cross-session systematic model.',
  historical_geometry='Applying one +16mm offset and one recovery time across source tables is a comparison assumption, not independent instrument calibration.',
  summaries='Two unresolved Book2 aggregates are shown independently of the pooled means, because partial overlap with retained observations cannot be excluded.',
  simulation='Previous conditional Geant4 reference, fixed normalization, unverified source/casing geometry; no new simulation or fit.',
  scatter_factor_range=[min(p['scatter_expansion_factor'] for p in points),max(p['scatter_expansion_factor'] for p in points)],changes_from_previous_selected=changes)
 (OUT/'processing.json').write_text(json.dumps(metadata,indent=2)+'\n')
 assert hashlib.sha256(SOURCE.read_bytes()).hexdigest()==digest
 print(json.dumps({k:metadata[k] for k in ['input_rows','pooled_measurements','mean_distance_points','unresolved_summaries_shown_separately','scatter_factor_range']},indent=2))

def plot():
 import numpy as np
 import matplotlib
 matplotlib.use('Agg')
 import matplotlib.pyplot as plt
 means=read(OUT/'task16_all_mean_points.csv');singles=read(OUT/'task16_all_individual_plot_points.csv');model=read(OUT/'previous_geant4_reference.csv')
 def arr(rr,k):return np.array([float(r[k]) for r in rr])
 obs=[r for r in singles if r['record_type']=='measurement'];ext=[r for r in singles if r['record_type']=='summary_unresolved']
 plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'pdf.fonttype':42,'axes.spines.top':False,'axes.spines.right':False})
 fig,(ax,bx)=plt.subplots(2,1,figsize=(11.5,9),sharex=True,gridspec_kw={'height_ratios':[1.1,1]})
 fig.subplots_adjust(left=.10,right=.98,top=.87,bottom=.16,hspace=.17)
 ax.errorbar(arr(model,'d_m')*100,arr(model,'predicted_u'),yerr=arr(model,'se'),fmt='s',ms=3,color='#438e66',ecolor='#92b8a1',capsize=2,elinewidth=.8,label='Previous Geant4 reference (unverified geometry)',zorder=1)
 for a,key,err in [(ax,'corrected_u_m2_per_s','corrected_u_se_m2_per_s'),(bx,'Cd2_m2_per_s','Cd2_se_m2_per_s')]:
  a.scatter(arr(obs,'d_m')*100,arr(obs,key),s=17,facecolors='none',edgecolors='#a2a9b0',alpha=.7,linewidths=.65,label='All 172 retained measurements',zorder=2)
  a.errorbar(arr(means,'d_m')*100,arr(means,key),yerr=arr(means,err),fmt='o',color='#202020',ms=4.5,capsize=3,elinewidth=1.1,label='32 pooled means (count / exposure)',zorder=4)
  a.errorbar(arr(ext,'d_m')*100,arr(ext,key),yerr=arr(ext,err),fmt='D',mfc='none',color='#d88724',ms=6.5,capsize=2,label='2 unresolved summaries (separate)',zorder=5)
  a.grid(alpha=.16)
 ax.set_ylabel(r'$C_{\rm corrected}(d+16\,\mathrm{mm})^2$ (m$^2$ s$^{-1}$)');ax.legend(loc='upper right',fontsize=8.4)
 bx.set(xlabel='Recorded gap d (cm)',ylabel=r'Raw $C d^2$ (m$^2$ s$^{-1}$)',xlim=(0,88));bx.legend(loc='lower center',fontsize=8.4)
 fig.suptitle('Task16_all: new points from the deduplicated master data',fontsize=15,y=.96)
 fig.text(.5,.915,'All measurements pooled at each distance; no closest-three selection or model rescaling',ha='center',fontsize=10)
 fig.text(.10,.101,'Top: common +16 mm distance offset, effective recovery 2.00 us and recorded background. Bottom: raw rates.',fontsize=8.4)
 fig.text(.10,.061,'Mean bars include nominal counting, extra repeat scatter and distance errors; cross-session systematics remain uncalibrated.',fontsize=8.3)
 fig.text(.10,.023,'Orange summaries are not added to the means. The 1 background row supplies the background rate; no simulation was rerun.',fontsize=8.3)
 for extn in ['png','pdf']:fig.savefig(OUT/f'task16_all_new_points.{extn}',dpi=200)
 plt.close(fig)
 for r in means:
  assert np.isfinite(float(r['corrected_u_se_m2_per_s'])) and float(r['corrected_u_se_m2_per_s'])>0
 print('Saved new 32-point figure, PNG and PDF.')

if __name__=='__main__':{'extract':extract,'plot':plot}[sys.argv[1]]()
