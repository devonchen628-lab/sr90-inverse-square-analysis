"""Compare original Task16 tables without altering them or refitting simulation."""
from pathlib import Path
import ast,csv,hashlib,itertools,json,math,operator,sys

ROOT=Path('/Users/chenqiyue/Documents/Codex/2026-10-29/r')
SRC=Path('/Users/chenqiyue/Library/CloudStorage/OneDrive-ImperialCollegeLondon/Radlab')
OUT=ROOT/'outputs/task16_all_datasets'
def read(p):return list(csv.DictReader(p.open(encoding='utf-8-sig')))
def write(name,rows):
 with (OUT/name).open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

def extract():
 import openpyxl
 OUT.mkdir(parents=True,exist_ok=True)
 files=[SRC/'Task16.csv',SRC/'Book2.xlsx',SRC/'task 16 data.xlsx']
 hashes={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
 base=Path('/Users/chenqiyue/Documents/Codex/2026-10-12/https-chatgpt-com-share-6acd35f5-5168/outputs/task16_geant4')
 fit=json.loads((base/'results/book2_dense_comparison/fit_summary.json').read_text())
 tau=fit['effective_recovery_us']*1e-6;stau=fit['recovery_fit_only_se_us']*1e-6
 B=fit['background_rate'];sB=fit['background_rate_se'];sd=.0005/math.sqrt(3);so=2*sd
 A=json.loads((ROOT/'outputs/task16_rigid_mount32/analysis_summary.json').read_text())['normalization']
 raw=[];d=sdr=None;group=0;blank=True
 ws=openpyxl.load_workbook(files[2],data_only=True,read_only=True)['Sheet1']
 def num(x):return None if x is None else float(str(x).strip())
 for rn,row in enumerate(ws.values,1):
  if rn==1:continue
  if num(row[0]) is not None:d=num(row[0]);sdr=num(row[1]);group=0;blank=True
  N=num(row[2]);T=num(row[4])
  if N is None:blank=True;continue
  if blank:group+=1
  blank=False
  assert N>=0 and N.is_integer() and T>0
  raw.append(dict(source_row=rn,d_m=d,counts=int(N),time_s=T,measurement_group=group))
 assert len(raw)==141
 old=read(ROOT/'outputs/task16_closest_three/task16_all_measurements.csv')
 assert [(r['source_row'],r['counts'],r['time_s']) for r in raw]==[(int(r['source_row']),int(r['counts']),float(r['time_s'])) for r in old]
 by={x:[r for r in raw if r['d_m']==x] for x in sorted({r['d_m'] for r in raw})}
 rows=[]
 def add(ds,d,N,T,source,sheet,source_rows,nobs,role='main'):
  C=N/T;sC=math.sqrt(N)/T;r=d+.016;net=C/(1-tau*C)-B/(1-tau*B)
  s_net=math.sqrt((sC/(1-tau*C)**2)**2+(sB/(1-tau*B)**2)**2+(stau*(C*C/(1-tau*C)**2-B*B/(1-tau*B)**2))**2)
  rows.append(dict(dataset=ds,role=role,d_m=d,nominal_r_m=r,counts=N,time_s=T,observations_combined=nobs,raw_rate_cps=C,
   raw_Cd2=C*d*d,raw_Cd2_se=math.hypot(sC*d*d,2*C*d*sd),corrected_rate_cps=net,
   corrected_u=net*r*r,corrected_u_se=math.sqrt((s_net*r*r)**2+(2*net*r*sd)**2+(2*net*r*so)**2),
   source=str(source),sheet=sheet,source_rows=';'.join(map(str,source_rows))))
 for i,q in enumerate(read(files[0]),2):
  if q['d'].lower()=='background':continue
  add('original_csv',float(q['d']),int(q['n']),float(q['t']),files[0],'',[i],1)
 wc=openpyxl.load_workbook(files[1],data_only=True,read_only=True)['Sheet1']
 wf=openpyxl.load_workbook(files[1],data_only=False,read_only=True)['Sheet1']
 cached=list(wc.values);formula=list(wf.values)
 ops={ast.Add:operator.add,ast.Sub:operator.sub,ast.Mult:operator.mul,ast.Div:operator.truediv}
 def number(x):
  if isinstance(x,(int,float)):return float(x)
  def calc(n):
   if isinstance(n,ast.Constant) and type(n.value) in (int,float):return n.value
   if isinstance(n,ast.BinOp) and type(n.op) in ops:return ops[type(n.op)](calc(n.left),calc(n.right))
   raise ValueError('Unsupported source arithmetic')
  return float(calc(ast.parse(x[1:],mode='eval').body))
 matches=[]
 for lo,hi,ds in [(2,33,'book2_summary'),(39,48,'book2_lower')]:
  for rn in range(lo,hi+1):
   q=cached[rn-1];fq=formula[rn-1]
   for k in [0,2,4]:assert math.isclose(number(fq[k]),float(q[k]),rel_tol=1e-12)
   d,N,T=map(float,[q[0],q[2],q[4]])
   add(ds,d,int(N),T,files[1],'Sheet1',[rn],0)
   if ds=='book2_summary':
    mm=[]
    for k in [3,6]:
     for combo in itertools.combinations(by[d],k):
      if sum(x['counts'] for x in combo)==N and math.isclose(sum(x['time_s'] for x in combo),T):mm.append([x['source_row'] for x in combo])
    matches.append(dict(d_m=d,book2_row=rn,matches_new_table=bool(mm),matching_source_rows=mm))
 for d,rr in by.items():
  assert len(rr) in (3,6) and len({x['time_s'] for x in rr})==1
  def key(q):
   nn=[x['counts'] for x in q];tot=sum(nn)
   return max(nn)-min(nn),sum((3*n-tot)**2 for n in nn),tuple(x['source_row'] for x in q)
  chosen=min(itertools.combinations(rr,3),key=key)
  for ds,records,role in [('new_selected',chosen,'main'),('new_first3',rr[:3],'within_new'),('new_next3',rr[3:],'within_new')]:
   if records:add(ds,d,sum(x['counts'] for x in records),sum(x['time_s'] for x in records),files[2],'Sheet1',[x['source_row'] for x in records],len(records),role)
 saved={float(x['d_m']):x for x in read(ROOT/'outputs/task16_closest_three/task16_selected_three.csv')}
 for q in rows:
  if q['dataset']=='new_selected':assert q['counts']==int(saved[q['d_m']]['counts_total']) and q['time_s']==float(saved[q['d_m']]['time_total_s'])
 mc=[q for q in read(base/'results/book2_dense_comparison/mc_summary_32_distances.csv') if float(q['threshold_keV'])==10]
 model=[dict(d_m=float(q['distance_m']),predicted_u=A*float(q['probability'])*(float(q['distance_m'])+.016)**2,se=A*float(q['se'])*(float(q['distance_m'])+.016)**2) for q in mc]
 write('all_datasets_processed.csv',rows);write('geant4_reference.csv',model)
 provenance=dict(sources_sha256=hashes,raw_records=141,series_sizes={ds:sum(x['dataset']==ds for x in rows) for ds in sorted({x['dataset'] for x in rows})},book2_overlap=matches,
  processing=dict(offset_m=.016,effective_recovery_us=tau*1e6,background_cps=B,rail_standard_uncertainty_m=sd,common_offset_standard_uncertainty_m=so,model_normalization=A,normalization_refitted=False),
  limitations=['Book2 summary is a processing/version comparison, not an independent full scan: 30 of 32 points reconstruct from new raw data.',
   'Historical source positioning and actual dead time are not independently verified; applying the common 16mm and 2us assumptions is for comparison.',
   'Error bars include nominal counting and metrology; closest-three selection and unmeasured repositioning uncertainty are not included.',
   'Next-three means record order: 12 distances have blank-separated groups; the six records at 75,80,85cm are contiguous, so their second triple is not explicitly identified as a return.',
   'Geant4 is the previous conditional geometry reference, with unverified source/casing parameters; no transport rerun or fresh fit.'])
 (OUT/'provenance.json').write_text(json.dumps(provenance,indent=2)+'\n')
 assert all(hashlib.sha256(p.read_bytes()).hexdigest()==hashes[str(p)] for p in files)
 print(json.dumps(dict(series=provenance['series_sizes'],book2_reconstructed=sum(q['matches_new_table'] for q in matches),book2_unmatched=[q['d_m'] for q in matches if not q['matches_new_table']]),indent=2))

def plot():
 import numpy as np
 import matplotlib
 matplotlib.use('Agg')
 import matplotlib.pyplot as plt
 data=read(OUT/'all_datasets_processed.csv');mc=read(OUT/'geant4_reference.csv')
 plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'pdf.fonttype':42,'axes.spines.top':False,'axes.spines.right':False})
 styles={'original_csv':('Original Task16.csv (23 points)','#2674ab','^',5.2,True),
  'book2_lower':('Book2 lower block (10 points)','#218d78','D',6.0,False),
  'book2_summary':('Book2 summary (32 points; overlapping data)','#d28524','s',6.5,False),
  'new_selected':('New table: closest three (32 points)','#202020','o',3.8,True)}
 def points(ax,ds,key,err,label=None,color=None,marker=None,ms=None,filled=None,line=False):
  rr=[r for r in data if r['dataset']==ds];d=np.array([float(r['d_m']) for r in rr])*100;y=np.array([float(r[key]) for r in rr]);se=np.array([float(r[err]) for r in rr])
  if ds in styles:
   sl,sc,sm,sz,sf=styles[ds];label=label or sl;color=color or sc;marker=marker or sm;ms=ms or sz;filled=sf if filled is None else filled
  ax.errorbar(d,y,yerr=se,fmt=marker,ms=ms,mfc=color if filled else 'none',mec=color,ecolor=color,color=color,capsize=2,elinewidth=.7,label=label,zorder=5 if ds=='new_selected' else 3)
  if line:ax.plot(d,y,color=color,lw=.65,alpha=.45,zorder=1)
  return rr
 fig,ax=plt.subplots(figsize=(11.8,7.5));fig.subplots_adjust(left=.09,right=.98,top=.86,bottom=.24)
 md=np.array([float(q['d_m']) for q in mc])*100;my=np.array([float(q['predicted_u']) for q in mc]);me=np.array([float(q['se']) for q in mc])
 ax.errorbar(md,my,yerr=me,fmt='.',ms=4,color='#9ca3aa',ecolor='#b7bcc1',capsize=2,elinewidth=.8,label='Previous Geant4 reference (unverified geometry)',zorder=1)
 for ds in styles:points(ax,ds,'corrected_u','corrected_u_se',line=True)
 ax.set(xlabel='Recorded gap d (cm)',ylabel=r'$C_{\rm corrected}(d+16\,\mathrm{mm})^2$ (m$^2$ s$^{-1}$)',xlim=(0,88));ax.grid(alpha=.16)
 fig.suptitle('Task16: all available distance-data tables',fontsize=16,y=.96)
 fig.text(.5,.91,'One common processing convention; original count levels preserved; no separate rescaling',ha='center',fontsize=10)
 handles,labels=ax.get_legend_handles_labels();fig.legend(handles,labels,loc='lower center',bbox_to_anchor=(.52,.095),ncol=2,fontsize=9,frameon=False)
 fig.text(.09,.058,'All tables: assumed offset +16 mm, effective recovery 2.00 us, same background. Historical geometry is unverified.',fontsize=8.2)
 fig.text(.09,.026,'Bars: nominal counting + distance errors. Book2 largely reuses new-table data. Connecting lines only guide the eye.',fontsize=8.2)
 for ext in ['png','pdf']:fig.savefig(OUT/f'all_task16_vs_geant4.{ext}',dpi=200)
 plt.close(fig)
 fig,(ax,bx)=plt.subplots(2,1,figsize=(11.8,9),sharex=True);fig.subplots_adjust(left=.09,right=.98,top=.87,bottom=.16,hspace=.23)
 for ds in styles:points(ax,ds,'raw_Cd2','raw_Cd2_se',line=True)
 ax.set(ylabel=r'Raw $C d^2$ (m$^2$ s$^{-1}$)',title='A. Original rates, without distance-offset, dead-time or background corrections');ax.legend(fontsize=8,loc='lower center',framealpha=.9)
 points(bx,'new_first3','corrected_u','corrected_u_se',label='First three records (32 distances)',color='#2674ab',marker='s',ms=6,filled=False)
 points(bx,'new_next3','corrected_u','corrected_u_se',label='Next three records, where available (15 distances)',color='#ce653b',marker='^',ms=5.5,filled=False)
 points(bx,'new_selected','corrected_u','corrected_u_se',label='Closest-three selection (32 distances)')
 bx.set(xlabel='Recorded gap d (cm)',ylabel=r'$C_{\rm corrected}(d+16\,\mathrm{mm})^2$',title='B. Within the new raw table: first / next / selected triples',xlim=(0,88));bx.legend(fontsize=8,loc='upper right',framealpha=.9)
 for a in [ax,bx]:a.grid(alpha=.16)
 fig.suptitle('Task16: raw-data comparison and repeat-group comparison',fontsize=15,y=.96)
 fig.text(.09,.09,'First / next denotes record order. At 75, 80 and 85 cm, the six records have no blank-separated return marker.',fontsize=8.2)
 fig.text(.09,.052,'Nominal bars exclude repositioning scatter and selection bias. No fits; no independent-source interpretation of overlapping records.',fontsize=8.2)
 for ext in ['png','pdf']:fig.savefig(OUT/f'raw_and_repeat_comparison.{ext}',dpi=200)
 plt.close(fig)
 print('Saved both comparison figures (PNG and PDF).')

def plot_latest():
 import numpy as np
 import matplotlib
 matplotlib.use('Agg')
 import matplotlib.pyplot as plt
 provenance=json.loads((OUT/'provenance.json').read_text())
 source=SRC/'task 16 data.xlsx'
 assert hashlib.sha256(source.read_bytes()).hexdigest()==provenance['sources_sha256'][str(source)],'Source changed: extract current table again before plotting.'
 data=[r for r in read(OUT/'all_datasets_processed.csv') if r['dataset']=='new_selected']
 mc={float(r['d_m']):r for r in read(OUT/'geant4_reference.csv')}
 target=ROOT/'outputs/task16_latest_only';target.mkdir(parents=True,exist_ok=True)
 assert len(data)==32
 d=np.array([float(q['d_m']) for q in data])*100
 y=np.array([float(q['corrected_u']) for q in data]);sy=np.array([float(q['corrected_u_se']) for q in data])
 model=np.array([float(mc[float(q['d_m'])]['predicted_u']) for q in data])
 smodel=np.array([float(mc[float(q['d_m'])]['se']) for q in data])
 plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,'pdf.fonttype':42,'axes.spines.top':False,'axes.spines.right':False})
 fig,ax=plt.subplots(figsize=(10.8,6.9));fig.subplots_adjust(left=.10,right=.98,top=.86,bottom=.22)
 ax.errorbar(d,model,yerr=smodel,fmt='s',ms=4,color='#328653',ecolor='#70a886',elinewidth=1,capsize=3,label='Geant4 air reference (conditional geometry)',zorder=2)
 ax.errorbar(d,y,yerr=sy,fmt='o',ms=4.8,color='#202020',elinewidth=1,capsize=3,label='Latest task 16 data.xlsx: closest-three average',zorder=3)
 ax.set(xlabel='Recorded gap d (cm)',ylabel=r'$C_{\rm corrected}(d+16\,\mathrm{mm})^2$ (m$^2$ s$^{-1}$)',xlim=(0,88));ax.grid(alpha=.16);ax.legend(loc='upper right',fontsize=9)
 fig.suptitle('Latest Task16 measurements versus Geant4',fontsize=16,y=.96)
 fig.text(.5,.91,'32 distances; closest three of six, all three otherwise; previous model normalization held fixed',ha='center',fontsize=9.5)
 fig.text(.10,.12,'Same processing: assumed +16 mm offset, effective recovery 2.00 us, background subtraction.',fontsize=8.6)
 fig.text(.10,.078,'Bars: nominal data uncertainties and MC standard errors. Repositioning scatter and selection bias are excluded.',fontsize=8.2)
 fig.text(.10,.038,'Source/casing geometry and actual electronic threshold remain unverified; this is a conditional model comparison.',fontsize=8.2)
 for ext in ['png','pdf']:fig.savefig(target/f'task16_latest_vs_geant4.{ext}',dpi=200)
 plt.close(fig)
 with (target/'task16_latest_vs_geant4.csv').open('w',encoding='utf-8-sig',newline='') as f:
  fields=list(data[0])+['geant4_u','geant4_MC_se'];w=csv.DictWriter(f,fieldnames=fields);w.writeheader()
  for i,q in enumerate(data):w.writerow(dict(q,geant4_u=model[i],geant4_MC_se=smodel[i]))
 (target/'provenance.json').write_text(json.dumps(dict(source=str(source),source_sha256=provenance['sources_sha256'][str(source)],points=32,selection='Closest three rates; all three when only three available.',processing=provenance['processing'],simulation_rerun=False,normalization_refitted=False),indent=2)+'\n')
 print('Saved latest-table-only comparison: 32 points; source hash verified; no new fit or simulation.')

if __name__=='__main__':{'extract':extract,'plot':plot,'plot_latest':plot_latest}[sys.argv[1]]()
