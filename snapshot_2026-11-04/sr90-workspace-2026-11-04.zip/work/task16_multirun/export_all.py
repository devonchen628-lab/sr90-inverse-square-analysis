"""Export original Task16 observations, excluding redundant stored aggregates."""
from pathlib import Path
from collections import Counter
import ast,csv,hashlib,itertools,json,math
import openpyxl

ROOT=Path('/Users/chenqiyue/Documents/Codex/2026-10-29/r')
SRC=Path('/Users/chenqiyue/Library/CloudStorage/OneDrive-ImperialCollegeLondon/Radlab')
OUT=ROOT/'outputs/task16_all.csv'
files=[SRC/'Task16.csv',SRC/'Book2.xlsx',SRC/'task 16 data.xlsx']
hashes={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
rows=[];removed=[]
def add(kind,d,halfwidth,N,T,dataset,path,sheet,rn,group='',formula=''):
 N=int(N);T=float(T);rate=N/T;se=math.sqrt(N)/T
 ds=halfwidth/math.sqrt(3) if halfwidth is not None else None
 u=rate*d*d if d is not None else None
 su=math.hypot(d*d*se,2*rate*d*ds) if d is not None else None
 row=dict(record_id=f'T16-{len(rows)+1:04d}',record_type=kind,d_m=d,d_reading_half_width_m=halfwidth,
  d_standard_uncertainty_m=ds,counts=N,counts_poisson_se=math.sqrt(N),time_s=T,rate_cps=rate,
  rate_poisson_se_cps=se,Cd2_m2_per_s=u,Cd2_standard_uncertainty_m2_per_s=su,
  Cd2_relative_standard_uncertainty_percent=100*su/u if u else None,
  dataset=dataset,repeat_group=group,source_file=str(path),source_sheet=sheet,source_row=rn,
  source_counts_expression=formula,related_source_records='')
 rows.append(row);return row

# Every distinct original measurement row is retained, even equal count values.
ws=openpyxl.load_workbook(files[2],data_only=True,read_only=True)['Sheet1']
new=[];d=halfwidth=None;group=0;after_blank=True
def number(v):return None if v is None else float(str(v).strip())
for rn,rr in enumerate(ws.values,1):
 if rn==1:continue
 if number(rr[0]) is not None:d=number(rr[0]);halfwidth=number(rr[1]);group=0;after_blank=True
 N,T=number(rr[2]),number(rr[4])
 if N is None:after_blank=True;continue
 if after_blank:group+=1
 after_blank=False
 assert N>=0 and N.is_integer() and T>0
 new.append(add('measurement',d,halfwidth,N,T,'new_raw_table',files[2],'Sheet1',rn,group))
assert len(new)==141

with files[0].open(encoding='utf-8-sig',newline='') as f:
 for rn,q in enumerate(csv.DictReader(f),2):
  bg=q['d'].strip().lower()=='background'
  add('background' if bg else 'measurement',None if bg else float(q['d']),None if bg else float(q['d_unc']),
      int(q['n']),float(q['t']),'original_csv',files[0],'',rn)

cache=openpyxl.load_workbook(files[1],data_only=True,read_only=True)['Sheet1']
forms=openpyxl.load_workbook(files[1],data_only=False,read_only=True)['Sheet1']
cached=list(cache.values);formula=list(forms.values)
def terms(expr):
 def flatten(n):
  if isinstance(n,ast.Constant) and type(n.value) in (int,float):return [int(n.value)]
  if isinstance(n,ast.BinOp) and isinstance(n.op,ast.Add):return flatten(n.left)+flatten(n.right)
  raise ValueError('Expected sum of source count observations')
 return flatten(ast.parse(expr[1:],mode='eval').body)
for rn in range(2,34):
 q=cached[rn-1];d,halfwidth,N,T=[float(q[k]) for k in [0,1,2,4]]
 expr=formula[rn-1][2];components=terms(expr);assert sum(components)==N
 candidates=[r for r in new if r['d_m']==d]
 matches=[ss for ss in itertools.combinations(candidates,len(components))
          if Counter(r['counts'] for r in ss)==Counter(components) and math.isclose(sum(r['time_s'] for r in ss),T)]
 ref=f'{files[1]}#Sheet1!A{rn}:H{rn}'
 if matches:
  chosen=matches[0]
  for r in chosen:r['related_source_records']=';'.join(filter(None,[r['related_source_records'],'aggregate:'+ref]))
  removed.append(dict(source=ref,reason='Same component counts and total exposure already retained as original observations',retained_record_ids=[r['record_id'] for r in chosen]))
 else:
  add('summary_unresolved',d,halfwidth,N,T,'book2_unique_summary',files[1],'Sheet1',rn,formula=expr[1:])
for rn in range(39,49):
 q=cached[rn-1]
 add('measurement',float(q[0]),float(q[1]),int(q[2]),float(q[4]),'book2_lower_block',files[1],'Sheet1',rn)

# Identical numerical records across different source tables are merged; within-source rows
# remain distinct observations rather than being merged by coincident count values.
kept=[];by_value={}
for row in rows:
 key=(row['record_type'],row['d_m'],row['counts'],row['time_s'])
 copies=[r for r in by_value.get(key,[]) if r['source_file']!=row['source_file']]
 if copies:
  existing=copies[0];ref=f"{row['source_file']}#{row['source_sheet']}!row{row['source_row']}"
  existing['related_source_records']=';'.join(filter(None,[existing['related_source_records'],'same_values:'+ref]))
  removed.append(dict(source=ref,reason='Identical distance, counts and exposure across input tables; merged by requested value deduplication, with both source locations preserved',retained_record_ids=[existing['record_id']]))
 else:kept.append(row);by_value.setdefault(key,[]).append(row)
rows=sorted(kept,key=lambda r:(r['d_m'] is None,r['d_m'] or 0,r['dataset'],r['source_row']))
assert len(rows)==175 and len(removed)==32
assert Counter(r['record_type'] for r in rows)=={'measurement':172,'summary_unresolved':2,'background':1}
assert len({r['record_id'] for r in rows})==len(rows)
assert sum(r['dataset']=='new_raw_table' for r in rows)==141
assert sum(r['dataset']=='new_raw_table' and r['d_m']==.25 and r['counts']==1916 for r in rows)==2
OUT.parent.mkdir(exist_ok=True,parents=True)
with OUT.open('w',newline='',encoding='utf-8-sig') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
with OUT.open(encoding='utf-8-sig',newline='') as f:check=list(csv.DictReader(f))
assert len(check)==175
assert all(int(r['counts'])>=0 and float(r['time_s'])>0 and math.isclose(float(r['rate_cps']),int(r['counts'])/float(r['time_s']),rel_tol=1e-12) for r in check)
assert all(hashlib.sha256(p.read_bytes()).hexdigest()==hashes[str(p)] for p in files)
audit=dict(output=str(OUT),rows=len(rows),record_types=dict(Counter(r['record_type'] for r in rows)),datasets=dict(Counter(r['dataset'] for r in rows)),
 source_hashes=hashes,removed_redundant_summaries=removed,
 definitions={'distance':'Recorded nominal d, in metres; no 16mm correction applied.',
  'distance_uncertainty':'Original 0.5mm readout half-width retained; standard uncertainty is half-width/sqrt(3), assuming a uniform readout distribution.',
  'Cd2':'Raw counts/time * recorded d squared. Nominal uncertainty from Poisson counting and readout only.',
  'summary_unresolved':'Two original Book2 aggregate points not reconstructable from current raw table; constituents are not invented, and their independence from other records is unestablished.',
  'repeat_group':'Within-distance blocks separated by blank rows in the original new table. Contiguous six-record blocks keep the same group.',
  'deduplication':'Remove aggregates only after component count multiset AND total exposure match retained original records. Merge identical distance/counts/exposure across source tables with both source addresses preserved; timestamps are absent, so these cross-file identities are numerical rather than proven event identities. Preserve independently listed repeated observations within the original raw table.'})
(Path(__file__).parent/'task16_all_export_audit.json').write_text(json.dumps(audit,indent=2)+'\n')
print(json.dumps({k:audit[k] for k in ['output','rows','record_types','datasets']},indent=2))
