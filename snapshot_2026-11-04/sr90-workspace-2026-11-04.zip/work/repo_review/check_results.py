from pathlib import Path
import csv,sys,json
import numpy as np
from scipy.odr import ODR,Model,RealData
from scipy.optimize import curve_fit
from scipy.stats import chi2
from functools import partial
root=Path(__file__).parent
sys.path.insert(0,str(root/'sam'))
from radiation.models import DetectorConfig,m1_offset,m2_solid_angle,m3_dead_time,m4_air_transmission
from radiation.beta_spectrum import logistic

with (root/'sam/data/filtered_data.csv').open() as f:rows=list(csv.DictReader(f))
ds=sorted(set(float(r['distance_cm']) for r in rows))
u=[];su=[]
for x in ds:
    sub=[r for r in rows if float(r['distance_cm'])==x]
    yy=np.array([float(r['u_cps_cm2']) for r in sub]);ss=np.array([float(r['sigma_u_cps_cm2']) for r in sub]);w=1/ss**2
    u.append(sum(w*yy)/sum(w));su.append(1/np.sqrt(sum(w)))
d=np.array(ds);u=np.array(u);su=np.array(su);sd=np.full_like(d,.5/np.sqrt(3))
cfg=DetectorConfig()
data=RealData(d,u,sx=sd,sy=su)
out={}
for name,fn,init in [('M1',m1_offset,[120000,.5]),('M2',partial(m2_solid_angle,cfg=cfg),[120000,.5]),('M3',partial(m3_dead_time,cfg=cfg),[120000,.5]),('M4',partial(m4_air_transmission,cfg=cfg),[120000,.5,-4])]:
    fit=ODR(data,Model(fn),beta0=init).run()
    out[name]={'params':fit.beta.tolist(),'sd':fit.sd_beta.tolist(),'chi2':fit.sum_square,'dof':len(d)-len(init),'p':chi2.sf(fit.sum_square,len(d)-len(init))}
    if name=='M4':out[name]['f_low']=float(logistic(fit.beta[2]))
out['sam_data']={'raw_rows':len(rows),'unique_distances':len(d),'range_cm':[d.min(),d.max()]}

with (root/'zwk/Data/nd2final.csv').open(encoding='utf-8-sig') as f:rows=list(csv.DictReader(f))
x=np.array([float(r['distance_corrected_m']) for r in rows]);n=np.array([float(r['counts']) for r in rows]);t=np.array([float(r['deltat']) for r in rows]);y=n/t*x*x;s=np.sqrt(n)/t*x*x
m=x>=.43
fn=lambda x,A,mu,c:A*np.exp(mu*x)+c
p,cov=curve_fit(fn,x[m],y[m],sigma=s[m],absolute_sigma=True,p0=[y[m][0],-.002,0],maxfev=10000)
ch=np.sum(((y[m]-fn(x[m],*p))/s[m])**2)
out['zwk_far_fit']={'points':int(m.sum()),'params_A_mu_c':p.tolist(),'errors':np.sqrt(np.diag(cov)).tolist(),'chi2':ch,'dof':int(m.sum()-3),'p':chi2.sf(ch,m.sum()-3),'intercept':float(p[0]+p[2]),'sigma_intercept_with_cov':float(np.sqrt(cov[0,0]+cov[2,2]+2*cov[0,2])),'sigma_intercept_without_cov':float(np.sqrt(cov[0,0]+cov[2,2]))}
out['zwk_data']={'points':len(x),'range_m':[x.min(),x.max()],'min_counts':n.min(),'max_counts':n.max()}
# Reproduce the cutoff scan, without running the author's plotting scripts.
z=np.load(root/'zwk/Data/test_montecarlo_efficiency_1.0cm_90.0cm_50steps.npz')
xx=z['distances'];yy=z['efficiencies']*xx*xx;ss=z['uncertainties']*xx*xx
for cutoff in np.linspace(xx.min(),xx.max()*.8,50):
    m=xx>=cutoff
    if m.sum()<10:continue
    w=1/ss[m]**2;mean=np.sum(w*yy[m])/sum(w);ch=np.sum(((yy[m]-mean)/ss[m])**2);pval=chi2.sf(ch,m.sum()-1)
    if pval>.01:
        out['zwk_geometry_cutoff']={'distance_m':cutoff,'p':pval,'points':int(m.sum()),'detector_width_cm':float(2*z['detector_half_width']*100)};break
print(json.dumps(out,indent=2))
(root/'checked_results.json').write_text(json.dumps(out,indent=2))
