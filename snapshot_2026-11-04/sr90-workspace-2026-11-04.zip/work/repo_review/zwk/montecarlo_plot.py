import numpy as np
import matplotlib.pyplot as plt

# Load data from npz file
min_dist_cm = 1.0  # Minimum distance in cm used in montecarlo_run.py\
max_dist_cm = 90.0  # Maximum distance in cm used in montecarlo_run.py
n_steps = 100  # Number of steps used in montecarlo_run.py
data_file = f"Data/montecarlo_efficiency_{min_dist_cm:.1f}cm_{max_dist_cm:.1f}cm_{n_steps}steps.npz"
data = np.load(data_file)

distances = data['distances']
efficiencies = data['efficiencies']
uncertainties = data['uncertainties']
n_samples_used = data['n_samples_used']

print(f"Loaded data from {data_file}")
print(f"Number of distance points: {len(distances)}")
print(f"Distance range: {distances.min():.3f} to {distances.max():.3f} m")

# Calculate efficiency × distance² and its uncertainty
eff_times_d2 = efficiencies * distances**2
eff_times_d2_err = uncertainties * distances**2

# Assume a source activity to convert efficiency to count rate
source_activity = 20000000  # counts per second (adjust as needed)

# The actual measurement time scales with d², so counts = activity × efficiency × time(d)
# where time(d) ∝ d² relative to reference
reference_time = 1.0  # reference measurement time in seconds at reference distance
measurement_times = (distances / distances[0])**2 * reference_time

# Total counts detected = activity × efficiency × measurement_time
total_counts = source_activity * efficiencies * measurement_times
# Poisson uncertainty in counts
count_uncertainties = np.sqrt(total_counts)

# Count rate = counts / time
count_rate = total_counts / measurement_times
count_rate_err = count_uncertainties / measurement_times

# Create subplots
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 5))

# Plot 1: Count rate × distance²
count_rate_times_d2 = count_rate * distances**2
count_rate_times_d2_err = count_rate_err * distances**2

ax1.errorbar(distances*100, count_rate_times_d2, yerr=count_rate_times_d2_err,
             fmt='o-', capsize=5, color='tab:orange', markersize=4)
ax1.set_xlabel('Distance (cm)')
ax1.set_ylabel('Count Rate × Distance² (counts·m²/s)')
ax1.set_title(f'Count Rate × Distance²\n(Time ∝ d², Activity = {source_activity} cps)')
ax1.grid(True, linestyle=':', alpha=0.5)

# Plot 2: Relative uncertainty vs distance
relative_uncertainty = count_rate_err / count_rate
ax2.plot(distances*100, relative_uncertainty, 'o-', color='tab:purple', markersize=4)
ax2.set_xlabel('Distance (cm)')
ax2.set_ylabel('Relative Uncertainty in Count Rate')
ax2.set_title('Relative Uncertainty vs Distance\n(should be roughly constant)')
ax2.grid(True, linestyle=':', alpha=0.5)

plt.tight_layout()
plt.show()

