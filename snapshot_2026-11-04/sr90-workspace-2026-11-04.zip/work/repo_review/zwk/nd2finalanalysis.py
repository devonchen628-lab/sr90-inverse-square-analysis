import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.optimize import curve_fit
import os

def linear_mx_plus_c(x, m, c):
    """Linear function: mx + c"""
    return m * x + c

def exponential_A_exp_mu_x_plus_c(x, A, mu, c):
    """Exponential function: A*exp(mu*x) + c"""
    return A * np.exp(mu * x) + c

# Read the CSV file
data = pd.read_csv('Data/nd2final.csv')

# Extract data
distances_m = data['distance_corrected_m'].values
counts = data['counts'].values
deltat = data['deltat'].values

# Calculate count rate and uncertainty
count_rate = counts / deltat
count_rate_uncertainty = np.sqrt(counts) / deltat

# Define distance uncertainty in SI units
distance_uncertainty_m = 0.001  # 0.1 cm in meters

cd2 = count_rate * distances_m**2  # Now in SI units: counts·m²/s
cd2_uncertainty = count_rate_uncertainty * distances_m**2

# Define cutoff distances for fit in meters
min_cutoff_distance_m = 0.43

# Select data within cutoff range (from min distance to end)
fit_mask = distances_m >= min_cutoff_distance_m
distances_fit = distances_m[fit_mask]
cd2_fit = cd2[fit_mask]
cd2_uncertainty_fit = cd2_uncertainty[fit_mask]

# Detector geometry
detector_area_cm2 = 1  # 1 cm × 1 cm square detector
detector_area_m2 = detector_area_cm2 / 10000  # Convert to m²
detector_area_m2_uncertainty = 2*0.01 / 10000  # 0.1mm uncertainty on each side

# Perform exponential fit with small coefficient guess
print(f"\n=== Exponential Fit ===")
# Initial guess: [A, mu, c] where mu is small (slow exponential decay)
p0_exp = [cd2_fit[0], -0.002, 0]  # Small negative coefficient for slight decay

try:
    popt_exp, pcov_exp = curve_fit(exponential_A_exp_mu_x_plus_c, distances_fit, cd2_fit,
                                    p0=p0_exp,
                                    sigma=cd2_uncertainty_fit, 
                                    absolute_sigma=True,
                                    maxfev=10000)
    A_exp, mu_exp, c_exp = popt_exp
    A_exp_err, mu_exp_err, c_exp_err = np.sqrt(np.diag(pcov_exp))
    
    print(f"Exponential fit: cd² = A·exp(μ·d) + c")
    print(f"  A = {A_exp:.6f} ± {A_exp_err:.6f} counts·m²/s")
    print(f"  μ = {mu_exp:.6f} ± {mu_exp_err:.6f} m⁻¹")
    print(f"  c = {c_exp:.6f} ± {c_exp_err:.6f} counts·m²/s")
    cd2_at_zero = exponential_A_exp_mu_x_plus_c(0, A_exp, mu_exp, c_exp)
    cd2_at_zero_err = np.sqrt(A_exp_err**2 + c_exp_err**2)
    print(f"  Extrapolated value at d=0: {cd2_at_zero:.6f} ± {cd2_at_zero_err:.6f}")
    
    # Calculate activity from exponential fit
    cd2_exp_at_zero = exponential_A_exp_mu_x_plus_c(0, A_exp, mu_exp, c_exp)
    activity_exp = cd2_exp_at_zero * (4 * np.pi) / detector_area_m2
    
    # Propagate uncertainty using the full formula
    cd2_exp_at_zero_err = np.sqrt(A_exp_err**2 + c_exp_err**2)
    activity_exp_err = (4 * np.pi / detector_area_m2) * np.sqrt(
        cd2_exp_at_zero_err**2 + 
        (cd2_exp_at_zero / detector_area_m2 * detector_area_m2_uncertainty)**2
    )
    
    print(f"\nSource activity (from exponential): {activity_exp/1e6:.2f} ± {activity_exp_err/1e6:.2f} MBq")
    
    exp_fit_success = True
except Exception as e:
    print(f"Exponential fit failed: {e}")
    exp_fit_success = False

# Perform exponential fit using log transformation (better method)
print(f"\n=== Exponential Fit (Log-Linear Method) ===")
try:
    # Take natural log of cd2 for linear fit
    # For exponential: cd² = A·exp(μ·d)
    # Taking log: ln(cd²) = ln(A) + μ·d 
    cd2_fit_log = np.log(cd2_fit)
    
    # Transform uncertainties: σ(ln(y)) = σ(y)/y
    cd2_fit_log_err = cd2_uncertainty_fit / cd2_fit
    
    # Fit linear model to log data: ln(cd2) = ln(A) + mu*d
    popt_log, pcov_log = curve_fit(linear_mx_plus_c, distances_fit, cd2_fit_log,
                                    sigma=cd2_fit_log_err,
                                    absolute_sigma=True)
    mu_log, ln_A = popt_log
    mu_log_err, ln_A_err = np.sqrt(np.diag(pcov_log))
    
    # Convert back to exponential parameters
    A_log = np.exp(ln_A)
    A_log_err = A_log * ln_A_err  # Error propagation: dA/d(ln A) = A
    
    print(f"Log-linear fit: ln(cd²) = ln(A) + μ·d")
    print(f"  ln(A) = {ln_A:.6f} ± {ln_A_err:.6f}")
    print(f"  μ = {mu_log:.6f} ± {mu_log_err:.6f} m⁻¹")
    print(f"\nConverted to exponential form: cd² = A·exp(μ·d)")
    print(f"  A = {A_log:.6e} ± {A_log_err:.6e} counts·m²/s")
    print(f"  μ = {mu_log:.6f} ± {mu_log_err:.6f} m⁻¹")
    print(f"  Extrapolated value at d=0: {A_log:.6e} ± {A_log_err:.6e}")

    
    # Calculate activity from log-linear fit
    cd2_log_at_zero = A_log
    activity_log = cd2_log_at_zero * (4 * np.pi) / detector_area_m2
    
    # Propagate uncertainty using the full formula
    activity_log_err = (4 * np.pi / detector_area_m2) * np.sqrt(
        A_log_err**2 + 
        (cd2_log_at_zero / detector_area_m2 * detector_area_m2_uncertainty)**2
    )
    
    print(f"\nSource activity (from log-linear): {activity_log/1e6:.2f} ± {activity_log_err/1e6:.2f} MBq")
    
    exp_log_fit_success = True
except Exception as e:
    print(f"Log-linear fit failed: {e}")
    exp_log_fit_success = False

# Generate fit line for plotting (including extrapolation to zero)
d_plot = np.linspace(0, distances_m.max(), 200)
if exp_fit_success:
    cd2_fitted_exp = exponential_A_exp_mu_x_plus_c(d_plot, A_exp, mu_exp, c_exp)
if exp_log_fit_success:
    cd2_fitted_log = A_log * np.exp(mu_log * d_plot)

# Plot count rate vs distance with error bars (all in SI units)
plt.figure(figsize=(8, 5))

# Plot not fitted data points in blue
not_fit_mask = ~fit_mask
plt.errorbar(distances_m[not_fit_mask], cd2[not_fit_mask], 
             yerr=cd2_uncertainty[not_fit_mask], 
             xerr=distance_uncertainty_m,
             fmt='.', capsize=3, color='cornflowerblue', markersize=4, label='Data (not used in fit)')

# Plot fitted data points in green
plt.errorbar(distances_m[fit_mask], cd2[fit_mask], 
             yerr=cd2_uncertainty[fit_mask], 
             xerr=distance_uncertainty_m,
             fmt='.', capsize=3, color='green', markersize=4, label='Data (used in fit)')

# Plot exponential fitted line
if exp_fit_success:
    plt.plot(d_plot, cd2_fitted_exp, 'g-', linewidth=2,
             label=f'Exponential fit')
    plt.plot(0, exponential_A_exp_mu_x_plus_c(0, A_exp, mu_exp, c_exp), 'gx', markersize=8, markeredgewidth=2,
             label=rf'Fit vertical intercept', clip_on=False)

exp_log_fit_success = 0
# Plot log-linear exponential fitted line
if exp_log_fit_success:
    plt.plot(d_plot, cd2_fitted_log, 'm-.', linewidth=2,
             label=f'Exponential fit (log-linear)')
    plt.plot(0, A_log, 'mx', markersize=8, markeredgewidth=2,
             label=rf'Log-linear intercept', clip_on=False)

# Mark the cutoff distance
plt.axvline(min_cutoff_distance_m, color='gray', linestyle='--', alpha=0.5, 
            label=f'Fit range: d ≥ {min_cutoff_distance_m:.2f} m')

plt.xlabel('d / m', fontsize=16)
plt.ylabel(r'$C d^2\; / \;\mathrm{m^{2}\;s^{-1}}$', fontsize=16)
plt.xlim(0, distances_m.max()*1.05)
plt.ylim(0, (cd2.max()*1.2))
plt.legend(fontsize=14, loc='lower right')
plt.tick_params(axis='both', which='major', labelsize=17)
plt.grid(True, linestyle=':', alpha=0.5)
plt.tight_layout()
save_dir = os.path.join("LabReport")
os.makedirs(save_dir, exist_ok=True)
plt.savefig(os.path.join(save_dir, 'nd2final_exponential_fit.png'), dpi=300)
plt.show()



