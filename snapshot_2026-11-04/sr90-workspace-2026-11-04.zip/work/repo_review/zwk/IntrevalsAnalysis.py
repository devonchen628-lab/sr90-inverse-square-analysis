import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# Read the intervals data
data_file = r'C:\Users\zhaow\OneDrive - Imperial College London\Labs\Y2\Radioactivity\Data\Task11\IntervalsData.csv'
data = pd.read_csv(data_file)

# Extract columns (first column is interval time, second is count)
intervals = data.iloc[:, 0].values  # Interval between events (microseconds)
counts = data.iloc[:, 1].values  # Number of counts

print(f"Loaded data from {data_file}")
print(f"Number of bins: {len(intervals)}")
print(f"Interval range: {intervals.min():.4f} to {intervals.max():.4f} microseconds")
print(f"Total counts: {counts.sum():.0f}")

# Plot as histogram
plt.figure(figsize=(10, 6))
bin_width = intervals[1] - intervals[0]
plt.bar(intervals, counts, width=2*bin_width, edgecolor='black', alpha=0.7, label='Data')
plt.xlabel('Interval between events (μs)', fontsize=12)
plt.ylabel('Number of counts', fontsize=12)
plt.title('Time Intervals Between Radioactive Decay Events', fontsize=14)
plt.grid(True, linestyle=':', alpha=0.5, axis='y')
plt.legend()
plt.tight_layout()
plt.show()
