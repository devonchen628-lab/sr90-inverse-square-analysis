from func import read_txt_mean
import os
import numpy as np
import matplotlib.pyplot as plt

# Set this to True to save generated figures to the `Plots/` folder
save_figs = True
base_dir = os.path.dirname(__file__)
plots_dir = os.path.join(base_dir, "Plots")
if save_figs:
    os.makedirs(plots_dir, exist_ok=True)

apparent_distances = np.concatenate((np.arange(0,9.1,1),np.arange(10,90.1,5)))
counts = np.array([])

for distance in apparent_distances:
    file_path = rf"C:\Users\zhaow\OneDrive - Imperial College London\Labs\Y2\Radioactivity\Data\Task15_changedt\{distance:.0f}cm"
    mean = read_txt_mean(file_path)
    counts = np.append(counts, mean)

deltat = np.concatenate((np.ones(10)*5,np.array([5,11.25,20,31.25,45,61.25,80,101.25,125,151.25,180,211.25,245,281.25,320,361.25,405])))
distances_corrected = (apparent_distances + 0.95)/100 # in meters
cd2 = counts/deltat * distances_corrected**2

# Calculating errors
sig_d = 0.07e-2
sig_n = np.sqrt(counts)
x_err = sig_d
y_err = 1/deltat * np.sqrt(distances_corrected**4 * sig_n**2 + 4 * counts**2 * distances_corrected**2 * sig_d**2) 
rel_yerr = y_err/cd2

print(repr(counts))
print(repr(deltat))
print(repr(deltat))
print(repr(apparent_distances))

plt.figure(num = "Cd2vsdistance", figsize=(10,6))
plt.errorbar(distances_corrected, cd2, yerr=y_err, xerr=x_err, marker='o', label = "Corrected count rate")
plt.xlabel('Corrected Distance (m)')
plt.ylabel('Count Rate × Distance² (counts·m²/s)')
plt.legend()
if save_figs:
    fig_cd2 = plt.gcf()
    fig_cd2.savefig(os.path.join(plots_dir, "Cd2_vs_distance_err_dt.png"), dpi=300)

# Analytical model of error term
rel_err_d = sig_d/distances_corrected
analytical_yerr = np.sqrt(1/counts + 4 * (rel_err_d)**2)

# --- Combined figure: Cd2 vs distance (with errorbars) and relative error (shared x-axis) ---
fig, (ax1, ax2) = plt.subplots(2, 1, sharex=True, figsize=(10, 8))

# top: Cd2 with errorbars
ax1.errorbar(distances_corrected, cd2, yerr=y_err, xerr=x_err, fmt='o', markersize=4,
             elinewidth=2, capsize=4, label='Corrected count rate')
ax1.set_ylabel('Count Rate × Distance² (counts·m²/s)')
ax1.legend()
ax1.grid(True, linestyle=':', alpha=0.5)

# bottom: relative error and analytical model
ax2.plot(distances_corrected, rel_yerr, marker='o', label='relative errors')
ax2.plot(distances_corrected, analytical_yerr, label='relative errors (analytical fit)')
ax2.set_xlabel('Corrected Distance (m)')
ax2.set_ylabel('Relative error')
ax2.legend()
ax2.grid(True, linestyle=':', alpha=0.5)

plt.tight_layout()
if save_figs:
    # save the combined shared-x figure
    fig.savefig(os.path.join(plots_dir, "Cd2_and_relative_errors_shared_x.png"), dpi=300)


# plt.figure(num = "errors", figsize=(10,6))
# plt.plot(distances_corrected, rel_yerr, marker='o', label="relative errors")
# plt.plot(distances_corrected, analytical_yerr, label = "relative errors (analytical fit)")
# plt.xlabel('Corrected Distance (m)')
# plt.ylabel('Error in counts')
# plt.legend()
# plt.show()
# if save_figs:
#     fig_errors = plt.gcf()
#     fig_errors.savefig(os.path.join(plots_dir, "Relative_errors_err_dt.png"), dpi=300)
# plt.show()

