import numpy as np
from montecarlo_functions import geometric_efficiency_vs_distance_variable_time

# Define geometry
source_radius = 0.8 / 2 / 100  # 1.1 cm diameter source -> radius in meters
detector_half_width = 5.0 / 100  # 10 cm x 10 cm detector -> 5 cm half-width in meters
detector_half_height = 5.0 / 100

# Calculate vs distance
print(f"\n=== Efficiency vs Distance (Variable Time) ===")
distances = np.linspace(0.01, 0.9, 50)
distances = distances[::-1]  # Reverse distances

# Use the variable time function where samples scale with d²
efficiencies, uncertainties, n_samples_used = geometric_efficiency_vs_distance_variable_time(
    source_radius, detector_half_width, detector_half_height, distances, 
    base_n_samples=100000000
)

# Save data to npz file with min/max distance and number of steps in filename
min_dist_cm = distances.min() * 100
max_dist_cm = distances.max() * 100
n_steps = len(distances)
output_file = f'Data/test_montecarlo_efficiency_{min_dist_cm:.1f}cm_{max_dist_cm:.1f}cm_{n_steps}steps.npz'
np.savez(output_file, 
         distances=distances,
         efficiencies=efficiencies,
         uncertainties=uncertainties,
         n_samples_used=n_samples_used,
         source_radius=source_radius,
         detector_half_width=detector_half_width,
         detector_half_height=detector_half_height)

print(f"\nData saved to {output_file}")
print(f"Saved arrays: distances, efficiencies, uncertainties, n_samples_used")
print(f"Saved parameters: source_radius, detector_half_width, detector_half_height")

