import os
import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import curve_fit

base_dir = os.path.dirname(__file__)
data_dir = os.path.join(base_dir, "Data", "Angle", "NO")

# Get all files in the directory (excluding .xlsx file)
files = [f for f in os.listdir(data_dir) if not f.endswith('.xlsx')]

# Sort files by numeric angle value
files_sorted = sorted(files, key=lambda x: int(x))

angles = []
counts = []

# Read each file
for filename in files_sorted:
    file_path = os.path.join(data_dir, filename)
    
    # Read the count from the file
    with open(file_path, 'r') as f:
        count = float(f.read().strip())
    
    angle = int(filename)
    angles.append(angle)
    counts.append(count)

# Convert to numpy arrays
angles = np.array(angles)
counts = np.array(counts)

countrates = counts / 10

countrates_err = np.sqrt(counts) / 10  # Poisson uncertainty in counts, then converted to count rate

# Calculate Angle/No
angle_over_count = angles / counts

# Define Gaussian function with mean fixed at 0
def gaussian(x, amplitude, sigma):
    return amplitude * np.exp(-(x**2) / (2 * sigma**2))

# Fit Gaussian to the data with mean fixed at 0
# Initial guess: amplitude=max count, sigma=30 degrees, offset=min count
p0 = [np.max(countrates), 30]
popt, pcov = curve_fit(gaussian, angles, countrates, p0=p0)

amplitude_fit, sigma_fit = popt
print(f"Gaussian Fit Parameters (mean fixed at 0°):")
print(f"  Amplitude: {amplitude_fit:.2f}")
print(f"  Sigma: {sigma_fit:.2f}°")
print(f"  FWHM: {2.355 * sigma_fit:.2f}°")

# Calculate RMS angle from experimental data
# RMS angle = sqrt(sum(angle^2 * count) / sum(count))
rms_angle = np.sqrt(np.sum(angles**2 * countrates) / np.sum(countrates))
print(f"\nRMS Angle from experimental data: {rms_angle:.2f}°")

# RMS angle from Gaussian fit (for Gaussian centered at 0, RMS = sigma)
print(f"RMS Angle from Gaussian fit: {sigma_fit:.2f}°")

# Generate fitted curve
angles_fit = np.linspace(angles.min(), angles.max(), 1000)
counts_fit = gaussian(angles_fit, *popt)

# Create theoretical cos^2(theta) curve
# Normalize it to match the scale of experimental data
angles_theory = np.linspace(0, 90, 1000)
cos2_theory = np.cos(np.radians(angles_theory))**2

# Scale to match experimental data - use maximum count as scaling factor
scale_factor = np.max(countrates)
cos2_theory_scaled = cos2_theory * scale_factor

# Also plot just the counts vs angle
fig2, ax2 = plt.subplots(figsize=(10, 6))
ax2.errorbar(angles, countrates, yerr=countrates_err, fmt='o', markersize=8, capsize=5, 
             elinewidth=1.5, color='tab:red', label='Experimental Data')
ax2.plot(angles_fit, counts_fit, '-', linewidth=2, color='tab:green', label=f'Gaussian Fit (σ={sigma_fit:.1f}°)')
ax2.plot(angles_theory, cos2_theory_scaled, '--', linewidth=2, color='tab:blue', label='Theoretical cos²(θ)')
ax2.set_xlabel('Angle (degrees)')
ax2.set_ylabel('Count Rate (counts/s)')
ax2.set_title('Count Rate vs Angle with Gaussian Fit and Theoretical cos²(θ) Curve')
ax2.legend()
ax2.grid(True, linestyle=':', alpha=0.5)
plt.tight_layout()
plt.show()


