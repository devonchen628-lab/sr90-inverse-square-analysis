import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.optimize import curve_fit
from scipy import stats
import os

# Read the Monte Carlo data
data_file = 'Data/test_montecarlo_efficiency_1.0cm_90.0cm_50steps.npz'
data = np.load(data_file)

distances_m = data['distances']
efficiencies = data['efficiencies']
uncertainties = data['uncertainties']

print(f"Loaded Monte Carlo data from {data_file}")
print(f"Number of distance points: {len(distances_m)}")
print(f"Distance range: {distances_m.min():.4f} to {distances_m.max():.4f} m")

# Assume a source activity (e.g., 1 MBq = 1e6 decays/s)
# You can adjust this to match your experimental source
source_activity_Bq = 1e6  # 1 MBq
print(f"\nUsing source activity: {source_activity_Bq/1e6:.2f} MBq")

# Calculate count rate = efficiency × source activity
count_rate = efficiencies * source_activity_Bq
count_rate_uncertainty = uncertainties * source_activity_Bq

# Calculate count rate × d²
cd2 = count_rate * distances_m**2
cd2_uncertainty = count_rate_uncertainty * distances_m**2

# Define horizontal line function
def horizontal(x, c):
    """Horizontal line: y = c (geometric effects negligible)"""
    return np.full_like(x, c)

# Function to fit and calculate chi-squared test
def fit_and_test_geometric(distances, cd2_data, cd2_err, min_distance):
    """
    Fit horizontal line to data beyond min_distance and calculate chi-squared test.
    Tests hypothesis: geometric effects are negligible (cd² = constant)
    
    Returns: c, c_err, p_value, chi2, dof, n_points
    """
    mask = distances >= min_distance
    d_fit = distances[mask]
    y_fit = cd2_data[mask]
    y_err_fit = cd2_err[mask]
    
    if len(d_fit) < 10:
        return None, None, 0, np.inf, 0, 0
    
    # Weighted fit for horizontal line
    popt, pcov = curve_fit(horizontal, d_fit, y_fit, sigma=y_err_fit, absolute_sigma=True)
    c = popt[0]
    c_err = np.sqrt(pcov[0, 0])
    
    # Calculate chi-squared statistic
    y_predicted = horizontal(d_fit, c)
    chi2 = np.sum(((y_fit - y_predicted) / y_err_fit)**2)
    dof = len(d_fit) - 1  # degrees of freedom = n_points - 1 parameter
    
    # Calculate p-value (probability that chi2 would be this large by chance)
    # High p-value (>0.05) means data is consistent with horizontal line
    p_value = 1 - stats.chi2.cdf(chi2, dof)
    
    return c, c_err, p_value, chi2, dof, len(d_fit)

# Test different minimum cutoff distances
print("\n=== Testing for negligible geometric effects ===")
print("Hypothesis: cd² = constant (geometric effects negligible)")
print("p > 0.05: data consistent with constant (geometric effects negligible)")
print("p < 0.05: data NOT consistent with constant (geometric effects present)")
print()

# Test range of cutoff distances
cutoff_distances = np.linspace(distances_m.min(), distances_m.max() * 0.8, 50)

# Set p-value threshold (standard significance level)
p_value_threshold = 0.01

best_cutoff = None
best_p_value = None

results = []

for cutoff in cutoff_distances:
    c, c_err, p_value, chi2, dof, n_points = fit_and_test_geometric(
        distances_m, cd2, cd2_uncertainty, cutoff
    )
    
    if n_points < 2:
        continue
    
    results.append({
        'cutoff': cutoff,
        'n_points': n_points,
        'chi2': chi2,
        'dof': dof,
        'p_value': p_value,
        'reduced_chi2': chi2/dof if dof > 0 else np.inf,
        'c': c,
        'c_err': c_err
    })
    
    print(f"Cutoff: {cutoff:.4f} m, n={n_points:2d}, χ²={chi2:6.2f}, dof={dof:2d}, "
          f"χ²/dof={chi2/dof:5.2f}, p={p_value:.4f}", end="")
    
    # Find first cutoff where p-value exceeds threshold (geometric effects negligible)
    if p_value > p_value_threshold and best_cutoff is None:
        best_cutoff = cutoff
        best_p_value = p_value
        print(f"  <-- First p > {p_value_threshold} (geometric effects negligible beyond here!)")
    else:
        print()

# Summary
if best_cutoff is not None:
    print(f"\n{'='*70}")
    print(f"RESULT: Geometric effects become negligible beyond d = {best_cutoff:.4f} m")
    print(f"        (p-value = {best_p_value:.4f} > {p_value_threshold})")
    print(f"{'='*70}")
    
    # Perform final fit with best cutoff
    c_final, c_err_final, p_final, chi2_final, dof_final, n_final = fit_and_test_geometric(
        distances_m, cd2, cd2_uncertainty, best_cutoff
    )
    
    print(f"\nFinal fit for d ≥ {best_cutoff:.4f} m:")
    print(f"  (count rate)·d² = {c_final:.6e} ± {c_err_final:.6e} counts·m²/s")
    print(f"  χ² = {chi2_final:.2f}, dof = {dof_final}, χ²/dof = {chi2_final/dof_final:.2f}")
    print(f"  p-value = {p_final:.4f}")
else:
    print(f"\nWARNING: No region found where geometric effects are negligible (p > {p_value_threshold})")
    print("This suggests geometric effects are significant across all measured distances.")
    best_cutoff = cutoff_distances[-1]
    c_final, c_err_final, p_final, chi2_final, dof_final, n_final = fit_and_test_geometric(
        distances_m, cd2, cd2_uncertainty, best_cutoff
    )

# Create plots
fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(8, 7))

# Plot 1: Data with fit
fit_mask = distances_m >= best_cutoff
d_plot = np.linspace(distances_m.min(), distances_m.max(), 200)
y_fit = horizontal(d_plot, c_final)

ax1.errorbar(distances_m[~fit_mask], cd2[~fit_mask],
             yerr=cd2_uncertainty[~fit_mask],
             fmt='o', capsize=3, color='cornflowerblue', markersize=4, 
             label='With geometric effects')
ax1.errorbar(distances_m[fit_mask], cd2[fit_mask],
             yerr=cd2_uncertainty[fit_mask],
             fmt='o', capsize=3, color='green', markersize=4, 
             label='Negligible geometric effects')
ax1.plot(d_plot, y_fit, 'r-', linewidth=2,
         label=f'Horizontal fit: cd² = {c_final:.3e}')
ax1.axvline(best_cutoff, color='gray', linestyle='--', alpha=0.5,
            label=f'Cutoff: d = {best_cutoff:.2f} m')
ax1.set_xlabel('d / m', fontsize=17)
ax1.set_ylabel(r'$C d^2\; / \;\mathrm{m^{2}\;s^{-1}}$', fontsize=17)
ax1.set_xlim(0, distances_m.max())
ax1.text(-0.16, 1.1, '(a)', transform=ax1.transAxes, fontsize=16,
         verticalalignment='top')
ax1.legend(fontsize=13)
ax1.tick_params(axis='both', which='major', labelsize=17)
ax1.grid(True, linestyle=':', alpha=0.5)

# Plot 2: p-value vs cutoff distance
results_array = np.array([(r['cutoff'], r['p_value'], r['reduced_chi2']) for r in results])
ax2.plot(results_array[:, 0], results_array[:, 1], 'b-', linewidth=2, label='p-value')
ax2.axhline(p_value_threshold, color='red', linestyle='--', linewidth=2, 
            label=f'Threshold (p = {p_value_threshold})')
if best_cutoff is not None:
    ax2.axvline(best_cutoff, color='gray', linestyle='--', alpha=0.5)
ax2.set_xlabel(r'$d_{\mathrm{cutoff}}$ / m', fontsize=17)
ax2.set_ylabel('p-value', fontsize=17)
ax2.set_xlim(0, distances_m.max())
ax2.text(-0.16, 1.1, '(b)', transform=ax2.transAxes, fontsize=16,
         verticalalignment='top')
ax2.legend(fontsize=13)
ax2.tick_params(axis='both', which='major', labelsize=17)
ax2.grid(True, linestyle=':', alpha=0.5)
ax2.set_ylim(0, 1)

plt.tight_layout(pad=2.0)

save_dir = os.path.join("LabReport")
os.makedirs(save_dir, exist_ok=True)
fig.savefig(os.path.join(save_dir, 'geometric_effects_test2.png'), dpi=300)

# fig3, ax3 = plt.subplots(figsize=(8, 5))
# fit_mask = distances_m >= best_cutoff
# d_plot = np.linspace(distances_m.min(), distances_m.max(), 200)
# y_fit = horizontal(d_plot, c_final)

# ax3.errorbar(distances_m[~fit_mask], cd2[~fit_mask],
#              yerr=cd2_uncertainty[~fit_mask],
#              fmt='o', capsize=3, color='tab:blue', markersize=4, 
#              label='Data (geometric effects present)')
# ax3.errorbar(distances_m[fit_mask], cd2[fit_mask],
#              yerr=cd2_uncertainty[fit_mask],
#              fmt='o', capsize=3, color='green', markersize=4, 
#              label='Data (geometric effects negligible)')
# ax3.plot(d_plot, y_fit, 'r-', linewidth=2,
#          label=f'Horizontal fit: cd² = {c_final:.2e}, p = {p_final:.2f}')
# ax3.axvline(best_cutoff, color='gray', linestyle='--', alpha=0.5,
#             label=f'Cutoff: d = {best_cutoff:.4f} m')
# ax3.set_xlabel('Distance (m)', fontsize=12)
# ax3.set_ylabel('Count Rate × d² (counts·m²/s)', fontsize=12)
# ax3.legend(fontsize=10)
# ax3.grid(True, linestyle=':', alpha=0.5)

# plt.tight_layout()

# save_dir = os.path.join("LabReport")
# os.makedirs(save_dir, exist_ok=True)
# fig3.savefig(os.path.join(save_dir, 'geometric_effects_test.png'), dpi=300)

plt.show()

# Print interpretation
print("\n" + "="*70)
print("INTERPRETATION:")
print("="*70)
print("The chi-squared test checks if (count rate)·d² is constant (geometric effects negligible).")
print(f"- p > {p_value_threshold}: Data is consistent with constant cd² → geometric effects negligible")
print(f"- p < {p_value_threshold}: Data is NOT consistent with constant → geometric effects present")
print()
if best_cutoff is not None:
    print(f"Beyond d = {best_cutoff:.4f} m, the inverse square law holds well,")
    print("and geometric corrections (source size, detector size) are negligible.")
else:
    print("Geometric effects appear significant across all measured distances.")
    print("This could be due to finite source/detector size effects.")

